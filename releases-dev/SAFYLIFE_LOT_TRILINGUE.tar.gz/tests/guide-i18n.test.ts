import { test } from 'node:test';
import assert from 'node:assert/strict';
import { preparednessCards } from '../src/app/guide.js';
import { FICHES, AID_TRANSLATION_DRAFTS } from '../src/app/fr-secours.js';
import { FRENCH_ONLY_ROUTES } from '../src/app/home-i18n.js';
test('all nine preparedness cards have localized text and unchanged source URLs',()=>{
 const fr=preparednessCards('fr'); assert.equal(fr.length,9);
 for(const lang of ['en','es'] as const) {
  const localized=preparednessCards(lang); assert.equal(localized.length,fr.length);
  for(let i=0;i<fr.length;i++) {
   assert.equal(localized[i]!.id,fr[i]!.id);assert.equal(localized[i]!.url,fr[i]!.url);
   assert.notEqual(localized[i]!.title,fr[i]!.title);assert.equal(localized[i]!.points.length,fr[i]!.points.length);
   assert.ok(localized[i]!.points.every((x,j)=>x!==fr[i]!.points[j]&&x.length>10));
  }
 }
 assert.equal(FRENCH_ONLY_ROUTES.has('guide'),false);
});
test('seven clinical translation candidates preserve structure; clinical review gate remains',()=>{
 for(const lang of ['en','es'] as const) {
  const drafts=AID_TRANSLATION_DRAFTS[lang];assert.deepEqual(Object.keys(drafts).sort(),FICHES.map(x=>x.id).sort());
  for(const f of FICHES){const d=drafts[f.id as keyof typeof drafts];assert.equal(d.steps.length,f.steps.length);assert.ok(d.attention.length>30);assert.notEqual(d.title,f.title);}
 }
 assert.ok(FRENCH_ONLY_ROUTES.has('secours'));
});
