import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { countryAtPoint, decodeWorld, decodeWorldRing, type WorldData } from "../src/app/world-core.js";
import { additionalEmergencyNumbersFor, chooseCountry, countryOptions, emergencyFor, emergencyCoverageNote, selectedCountry } from "../src/app/fr-world.js";

const atlas = decodeWorld(JSON.parse(readFileSync("public/world-shapes.json", "utf8")) as WorldData);

test("the self-contained atlas covers more than 200 territories", () => {
  assert.ok(atlas.length >= 200);
  assert.ok(atlas.some(c => c.code === "fr"));
  assert.ok(atlas.some(c => c.code === "jp"));
});

test("country detection works for inland reference points", () => {
  for (const [lat, lon, expected] of [
    [48.8566, 2.3522, "fr"],
    [40.7829, -73.9650, "us"], // Central Park, away from the simplified coastline
    [-23.5505, -46.6333, "br"],
    [35.6762, 139.6503, "jp"],
    [28.6139, 77.2090, "in"],
  ] as const) assert.equal(countryAtPoint(atlas, { lat, lon }), expected);
  assert.equal(countryAtPoint(atlas, { lat: 0, lon: -130 }), null, "open ocean");
});

test("malformed, incomplete or out-of-range atlas data fails safely", () => {
  assert.throws(() => decodeWorldRing("?", 1000));
  assert.throws(() => decodeWorldRing("!@", 1000));
  assert.throws(() => decodeWorldRing("??", 0));
  assert.equal(countryAtPoint(atlas, { lat: 120, lon: 0 }), null);
  assert.equal(countryAtPoint(atlas, { lat: Number.NaN, lon: 0 }), null);
});

test("emergency calls are shown only where a verified country number is available", () => {
  assert.equal(emergencyFor("FR")?.number, "112");
  assert.equal(emergencyFor("US")?.number, "911");
  assert.equal(emergencyFor("NZ")?.number, "111");
  assert.equal(emergencyFor("AU")?.number, "000");
  assert.equal(emergencyFor("IN")?.number, "112");
  assert.equal(emergencyFor("BR")?.kind, "ambulance");
  assert.equal(emergencyFor("JP")?.number, "119");
  assert.equal(emergencyFor("JP")?.kind, "fire-medical");
  assert.equal(emergencyFor("MA")?.number, "150");
  assert.equal(emergencyFor("MA")?.kind, "fire-medical");
  assert.equal(emergencyFor("KR")?.number, "119");
  assert.deepEqual(additionalEmergencyNumbersFor("JP").map(v => v.number), ["110"]);
  assert.deepEqual(additionalEmergencyNumbersFor("KR").map(v => v.number), ["112"]);
  assert.deepEqual(additionalEmergencyNumbersFor("MA").map(v => v.number), ["190", "19"]);
  assert.equal(emergencyFor("ZZ"), null, "never invent a local number");
});

test("country choice keeps a session-only fallback when storage is absent", () => {
  chooseCountry("US");
  assert.equal(selectedCountry(), "US");
  chooseCountry("ZZ");
  assert.equal(selectedCountry(), "US", "reject unknown code");
  chooseCountry("");
  assert.equal(selectedCountry(), "");
});

test("SOS country picker offers more than 200 countries and preserves known options", () => {
  const options = countryOptions();
  assert.ok(options.length >= 200);
  for (const code of ["FR", "JP", "MA", "KR", "US", "GB"]) {
    assert.ok(options.some(option => option.code === code), `missing ${code}`);
  }
});

test("GOV.UK-sourced numbers added on 2026-11-24 keep agencies distinct", () => {
  const expected: Record<string, [string, string]> = { MX: ["911", "all"], TR: ["112", "all"], PH: ["911", "all"], CH: ["112", "all"],
    ZA: ["10177", "fire-medical"], TH: ["1669", "ambulance"], ID: ["118", "ambulance"], NO: ["113", "ambulance"] };
  for (const [code, [number, kind]] of Object.entries(expected)) {
    const e = emergencyFor(code);
    assert.equal(e?.number, number, code);
    assert.equal(e?.kind, kind, code);
    assert.match(e?.url ?? "", /^https:\/\/www\.gov\.uk\/foreign-travel-advice\/[a-z-]+\/getting-help$/);
  }
  assert.deepEqual(additionalEmergencyNumbersFor("ZA").map(n => n.number), ["10111"]);
  assert.deepEqual(additionalEmergencyNumbersFor("TH").map(n => n.number), ["191"]);
  assert.deepEqual(additionalEmergencyNumbersFor("NO").map(n => n.number), ["112"]);
  assert.equal(emergencyFor("AQ"), null, "unverified countries must not show a call button");
});

// Sources: FCDO country-specific Getting help pages, checked 2026-11-24.
test("five newly sourced countries distinguish fire, police and medical services", () => {
  assert.equal(emergencyFor("CN")?.number, "120");
  assert.equal(emergencyFor("CN")?.kind, "ambulance");
  assert.equal(emergencyFor("CN")?.url, "https://www.gov.uk/foreign-travel-advice/china/getting-help");
  assert.deepEqual(additionalEmergencyNumbersFor("CN").map(x => [x.number, x.type]), [["110", "police"], ["119", "fire"]]);
  assert.equal(emergencyFor("PK")?.number, "1122");
  assert.equal(emergencyFor("PK")?.kind, "fire-medical");
  assert.equal(emergencyFor("PK")?.url, "https://www.gov.uk/foreign-travel-advice/pakistan/getting-help");
  assert.deepEqual(additionalEmergencyNumbersFor("PK").map(x => [x.number, x.type]), [["15", "police"]]);
  assert.equal(emergencyFor("BD")?.number, "999");
  assert.equal(emergencyFor("BD")?.kind, "all");
  assert.equal(emergencyFor("BD")?.url, "https://www.gov.uk/foreign-travel-advice/bangladesh/getting-help");
  assert.deepEqual(additionalEmergencyNumbersFor("BD").map(x => [x.number, x.type]), []);
  assert.equal(emergencyFor("EG")?.number, "123");
  assert.equal(emergencyFor("EG")?.kind, "ambulance");
  assert.equal(emergencyFor("EG")?.url, "https://www.gov.uk/foreign-travel-advice/egypt/getting-help");
  assert.deepEqual(additionalEmergencyNumbersFor("EG").map(x => [x.number, x.type]), [["122", "police"], ["180", "fire"]]);
  assert.equal(emergencyFor("VN")?.number, "115");
  assert.equal(emergencyFor("VN")?.kind, "ambulance");
  assert.equal(emergencyFor("VN")?.url, "https://www.gov.uk/foreign-travel-advice/vietnam/getting-help");
  assert.deepEqual(additionalEmergencyNumbersFor("VN").map(x => [x.number, x.type]), [["113", "police"], ["114", "fire"]]);
});


test("five additional countries retain verified agency types and sources", () => {
  const expected = {
    AR: ["107", "ambulance", [["911", "police"], ["100", "fire"]]],
    CL: ["131", "ambulance", [["133", "police"], ["132", "fire"]]],
    CO: ["123", "all", [["119", "fire"]]],
    MY: ["999", "all", []],
    KE: ["999", "all", []],
  } as const;
  for (const [code, [number, kind, extras]] of Object.entries(expected)) {
    const e = emergencyFor(code);
    assert.equal(e?.number, number, code);
    assert.equal(e?.kind, kind, code);
    assert.match(e?.url ?? "", /^https:\/\//);
    assert.deepEqual(additionalEmergencyNumbersFor(code).map(n => [n.number, n.type]), extras);
  }
});

test("new emergency contacts and limited medical coverage are preserved", () => {
  const entries = {"AE": ["998", "ambulance", [["999", "police"], ["997", "fire"]]], "BH": ["999", "all", []], "BO": ["118", "ambulance", [["110", "police"], ["119", "fire"]]], "EC": ["911", "all", []], "OM": ["9999", "all", []], "PE": ["106", "ambulance", [["105", "police"], ["116", "fire"]]], "PY": ["141", "ambulance", [["911", "police"], ["132", "fire"]]], "QA": ["999", "all", []], "UY": ["911", "all", []]} as const;
  for (const [code,[number,kind,extras]] of Object.entries(entries)) {
    assert.equal(emergencyFor(code)?.number, number, code);
    assert.equal(emergencyFor(code)?.kind, kind, code);
    assert.deepEqual(additionalEmergencyNumbersFor(code).map(n => [n.number,n.type]), extras, code);
  }
  for (const lang of ["fr","en","es"] as const) {
    assert.match(emergencyCoverageNote("PE", lang), /106/);
    assert.equal(emergencyCoverageNote("EC", lang), "");
  }
});
test("unknown and prototype-property country codes never return emergency numbers", () => {
  for (const code of ["", "ZZ", "constructor", "__proto__", "toString", "fr"]) {
    assert.equal(emergencyFor(code), null);
    assert.deepEqual(additionalEmergencyNumbersFor(code), []);
  }
});

// Official FCDO emergency numbers checked 2026-11-24.
test("seven additional country entries preserve agency boundaries", () => {
  const expected = {
    GH: ["112", "all", []],
    HK: ["999", "all", []],
    CR: ["911", "all", []],
    JO: ["911", "all", []],
    TW: ["119", "fire-medical", [["110", "police"]]],
    LK: ["1990", "ambulance", [["119", "police"], ["111", "fire"]]],
    RS: ["112", "all", [["192", "police"], ["193", "fire"]]],
  } as const;
  for (const [code, [number, kind, extras]] of Object.entries(expected)) {
    assert.equal(emergencyFor(code)?.number, number, code);
    assert.equal(emergencyFor(code)?.kind, kind, code);
    assert.match(emergencyFor(code)?.url ?? "", /^https:\/\/www\.gov\.uk\/foreign-travel-advice\/[a-z-]+\/getting-help$/);
    assert.deepEqual(additionalEmergencyNumbersFor(code).map(x => [x.number, x.type]), extras);
  }
});

// New FCDO agency-specific numbers checked 2026-11-24.
test("European and Caucasus additions preserve service categories", () => {
  const expected = {
  "AL": [
    "127",
    "ambulance",
    [
      [
        "128",
        "fire"
      ],
      [
        "112",
        "police"
      ]
    ]
  ],
  "AZ": [
    "103",
    "ambulance",
    [
      [
        "101",
        "fire"
      ],
      [
        "102",
        "police"
      ]
    ]
  ],
  "SM": [
    "118",
    "ambulance",
    [
      [
        "115",
        "fire"
      ],
      [
        "113",
        "police"
      ]
    ]
  ],
  "MK": [
    "194",
    "ambulance",
    [
      [
        "192",
        "police"
      ]
    ]
  ],
  "AD": [
    "116",
    "ambulance",
    [
      [
        "118",
        "fire"
      ],
      [
        "110",
        "police"
      ]
    ]
  ],
  "XK": [
    "112",
    "all",
    []
  ],
  "IS": [
    "112",
    "all",
    []
  ],
  "MD": [
    "112",
    "all",
    []
  ],
  "GE": [
    "112",
    "all",
    []
  ],
  "BA": [
    "124",
    "ambulance",
    [
      [
        "123",
        "fire"
      ],
      [
        "122",
        "police"
      ]
    ]
  ]
} as const;
  for (const [code,[number,kind,extras]] of Object.entries(expected)) {
    assert.equal(emergencyFor(code)?.number,number,code);
    assert.equal(emergencyFor(code)?.kind,kind,code);
    assert.deepEqual(additionalEmergencyNumbersFor(code).map(x=>[x.number,x.type]),extras,code);
  }
});
