import { html, mount } from "./ui.js";
import { emergencyFor, selectedCountry } from "./fr-world.js";

/** Aide-mémoire pédagogique : synthèses originales de recommandations françaises.
 * Les sources sont visibles et datées. Ce texte ne remplace pas le 112 ou une formation.
 */
type Fiche = {
  id: string;
  icon: string;
  title: string;
  signal: string;
  audience: string;
  steps: string[];
  attention: string;
  source: string;
  url: string;
};

export const FICHES: Fiche[] = [
  {
    id: "arret-cardiaque", icon: "❤️", title: "Ne respire pas normalement",
    signal: "Une personne adulte ne répond pas et ne respire pas normalement, ou cherche son air par à-coups.",
    audience: "Massage cardiaque de l'adulte uniquement",
    steps: [
      "Vérifie que le lieu ne te met pas en danger. Vérifie si la personne réagit et respire normalement.",
      "Fais appeler le 112 immédiatement et demande un défibrillateur (DAE). Si tu es seul, appelle en haut-parleur.",
      "Commence les compressions : deux mains au centre de la poitrine, bras tendus, 100 à 120 fois par minute, environ 5 à 6 cm de profondeur chez l'adulte. Laisse la poitrine remonter entre deux compressions.",
      "Si tu es formé et peux le faire, alterne 30 compressions et 2 insufflations. Sinon, continue les compressions sans interruption inutile.",
      "Allume le DAE dès qu'il arrive, colle les électrodes comme indiqué et suis ses instructions vocales. Continue jusqu'à la prise en charge par les secours ou la reprise d'une respiration normale.",
    ],
    attention: "Pour un bébé, un enfant, une noyade ou une situation particulière, les gestes peuvent différer : demande immédiatement les consignes du 112.",
    source: "Croix-Rouge française — Arrêt cardiaque",
    url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/arret-cardiaque",
  },
  {
    id: "hemorragie", icon: "🩸", title: "Saignement très important",
    signal: "Le sang coule abondamment ou de manière continue.",
    audience: "Adulte ou enfant — avec protection contre le sang",
    steps: [
      "Protège-toi du danger et évite de toucher directement le sang : utilise des gants, un sac ou un tissu si possible.",
      "Appuie fermement et directement sur la plaie avec un tissu propre ou une protection adaptée. Si possible, demande à la personne de comprimer elle-même.",
      "Fais allonger la personne si c'est possible sans danger et appelle le 112.",
      "Continue à appuyer sans relâcher jusqu'à l'arrivée des secours. Suis les instructions de l'opérateur.",
    ],
    attention: "Si un objet est enfoncé dans la plaie, ne le retire pas. Demande au 112 comment exercer la pression autour. Une hémorragie peut mettre la vie en danger.",
    source: "Croix-Rouge française — L'hémorragie",
    url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/hemorragie",
  },
  {
    id: "inconscience", icon: "🫁", title: "Inconscient, mais respire",
    signal: "La personne ne répond pas, mais sa respiration est normale.",
    audience: "Sans traumatisme évident",
    steps: [
      "Vérifie ta sécurité, puis essaie de parler à la personne et observe sa respiration.",
      "Appelle le 112 et suis les consignes. Si elle respire normalement et qu'aucune blessure grave n'est suspectée, mets-la sur le côté (position latérale de sécurité).",
      "Pour la tourner sur le côté : bras proche à angle droit, main opposée contre sa joue, genou éloigné plié ; tire doucement ce genou vers toi pour la faire rouler.",
      "Stabilise-la sur le côté, bouche orientée vers le sol. Surveille souvent sa respiration jusqu'aux secours.",
    ],
    attention: "Après une chute ou un accident avec possible blessure au dos ou au cou, demande l'avis du 112 avant de déplacer la personne. Si elle ne respire pas normalement, passe à la fiche arrêt cardiaque.",
    source: "Croix-Rouge française — Position latérale de sécurité",
    url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/position-laterale-de-securite-comment-mettre-en-pls",
  },
  {
    id: "etouffement", icon: "😮", title: "Étouffement : adulte ou enfant",
    signal: "Une personne consciente ne peut plus parler, tousser efficacement ou respirer après avoir avalé quelque chose.",
    audience: "Adulte et enfant de plus d'un an — hors grossesse",
    steps: [
      "Si la personne tousse efficacement et respire, encourage-la à tousser. Ne lui donne pas de claques dans le dos.",
      "Si elle ne peut plus tousser ni respirer, fais appeler le 112. Penche-la vers l'avant et donne jusqu'à 5 claques fermes entre les omoplates, en vérifiant après chaque claque.",
      "Si cela ne suffit pas, pratique jusqu'à 5 compressions abdominales : derrière la personne, poing entre nombril et bas du sternum, tire vers toi et vers le haut.",
      "Alterne jusqu'à 5 claques dans le dos et 5 compressions abdominales tant que le blocage persiste. Si la personne perd connaissance, accompagne-la au sol et suis le 112 pour commencer la réanimation.",
    ],
    attention: "JAMAIS de compressions abdominales chez un bébé de moins d'un an. Pour une personne enceinte ou une situation particulière, demande immédiatement au 112 le geste adapté.",
    source: "Croix-Rouge française — L'étouffement",
    url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/etouffement",
  },
  {
    id: "bebe-etouffement", icon: "👶", title: "Bébé qui s'étouffe",
    signal: "Un nourrisson de moins d'un an ne peut plus pleurer, tousser efficacement ou respirer à cause d'un objet.",
    audience: "Nourrisson de moins d'un an",
    steps: [
      "Demande immédiatement de l'aide et fais appeler le 112. Si le bébé tousse efficacement ou pleure, surveille-le et demande un avis médical.",
      "Si l'air ne passe plus : maintiens sa tête et son cou, place-le à plat ventre sur ton avant-bras ou ta cuisse, tête plus basse que le corps, puis donne jusqu'à 5 claques fermes entre les omoplates.",
      "Si l'objet ne sort pas, retourne doucement le bébé sur le dos, toujours tête plus basse. Avec deux doigts sur la moitié basse du sternum, pratique jusqu'à 5 compressions thoraciques.",
      "Alterne ces deux gestes tant que l'obstruction persiste, en suivant les instructions du 112. Même si le bébé va mieux, demande un avis médical.",
    ],
    attention: "Ne secoue jamais le bébé et ne fais jamais de compressions abdominales. Si le bébé perd connaissance, les gestes de réanimation changent : suis immédiatement le 112.",
    source: "Croix-Rouge française — Bébé qui s'étouffe",
    url: "https://www.croix-rouge.fr/mes-infos-bebe/que-faire-si-mon-bebe-setouffe",
  },
  {
    id: "brulure", icon: "🔥", title: "Brûlure par la chaleur",
    signal: "La peau a été brûlée par une flamme, un objet chaud ou un liquide chaud.",
    audience: "Brûlure thermique uniquement",
    steps: [
      "Éloigne la personne de la source de chaleur si tu peux le faire sans danger.",
      "Refroidis rapidement la brûlure sous de l'eau courante tempérée, à faible débit, pendant au moins 10 minutes et idéalement 20 minutes.",
      "Enlève les bijoux et vêtements proches seulement s'ils ne collent pas à la peau. Protège doucement avec un linge propre.",
      "Appelle le 112 pour une brûlure grave, étendue, du visage, ou en cas de doute ; suis les consignes.",
    ],
    attention: "Pas de glace, de beurre ni de crème maison. Ne perce pas les cloques. En cas de brûlure chimique ou électrique, les consignes sont différentes : appelle les secours.",
    source: "Croix-Rouge française — Que faire en cas de brûlure ?",
    url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/que-faire-en-cas-de-brulure",
  },
  {
    id: "avc", icon: "🧠", title: "Signes d'un AVC",
    signal: "Soudain, le visage se déforme, un bras devient faible ou la personne parle bizarrement.",
    audience: "Toute personne présentant ces signes",
    steps: [
      "Observe les signes VITE : Visage qui tombe, Impossible de lever un bras, Trouble de la parole.",
      "Appelle immédiatement le 15 ou le 112, même si les symptômes disparaissent. N'attends pas.",
      "Note l'heure à laquelle les signes ont commencé. Aide la personne à s'asseoir ou s'allonger et rassure-la.",
      "Ne lui donne ni à boire, ni à manger, ni de médicament sans instruction médicale. Suis les consignes du téléphone.",
    ],
    attention: "Un trouble brutal de la vue, de l'équilibre ou un mal de tête inhabituel peut aussi être un signe d'AVC. Appelle sans attendre.",
    source: "Assurance Maladie — AVC : que faire ? (18 juin 2026)",
    url: "https://www.ameli.fr/assure/sante/urgence/pathologies/avc",
  },
];

// Translation candidates for expert review; not a clinical validation.
export const AID_TRANSLATION_DRAFTS = {
  "en": {
    "arret-cardiaque": {
      "title": "Not breathing normally",
      "signal": "An adult is unresponsive and not breathing normally, or is only gasping.",
      "audience": "Adult CPR only",
      "steps": [
        "Make sure the area is safe for you. Check whether the person responds and breathes normally.",
        "Have someone call the local emergency services immediately and ask for an automated external defibrillator (AED). If alone, call on speakerphone.",
        "Start chest compressions: both hands in the centre of the chest, arms straight, 100–120 per minute, about 5–6 cm deep in an adult. Allow the chest to rise between compressions.",
        "If trained and able, alternate 30 compressions and 2 rescue breaths. Otherwise continue compressions without unnecessary interruptions.",
        "Turn on the AED as soon as it arrives, apply the pads as shown and follow its voice prompts. Continue until responders take over or normal breathing returns."
      ],
      "attention": "For an infant, child, drowning or other special situation, the procedure may differ: immediately follow emergency dispatch instructions."
    },
    "hemorragie": {
      "title": "Severe bleeding",
      "signal": "Blood is flowing heavily or continuously.",
      "audience": "Adult or child — protect yourself from blood",
      "steps": [
        "Make sure you are safe and avoid touching blood directly; use gloves, a bag or cloth if possible.",
        "Apply firm direct pressure to the wound using a clean cloth or suitable dressing. If possible, ask the person to apply pressure themselves.",
        "Have the person lie down if safe to do so, and call local emergency services.",
        "Keep pressing without releasing until responders arrive. Follow dispatch instructions."
      ],
      "attention": "If an object is embedded in the wound, do not remove it. Ask emergency dispatch how to apply pressure around it. Severe bleeding can be life-threatening."
    },
    "inconscience": {
      "title": "Unconscious but breathing",
      "signal": "The person does not respond but is breathing normally.",
      "audience": "No obvious trauma",
      "steps": [
        "Check your safety, then try speaking to the person and observe their breathing.",
        "Call local emergency services and follow instructions. If breathing normally and no serious injury is suspected, place them on their side (recovery position).",
        "To roll them onto their side: bend the nearer arm at a right angle, place the far hand against their cheek, bend the far knee, and gently pull that knee towards you.",
        "Stabilize them on their side with their mouth towards the ground. Check breathing frequently until help arrives."
      ],
      "attention": "After a fall or accident with possible back or neck injury, seek dispatch advice before moving them. If not breathing normally, see the cardiac arrest card."
    },
    "etouffement": {
      "title": "Choking: adult or child",
      "signal": "A conscious person can no longer speak, cough effectively or breathe after swallowing something.",
      "audience": "Adult and child over one year — excluding pregnancy",
      "steps": [
        "If the person can cough effectively and breathe, encourage coughing. Do not give back blows.",
        "If they can no longer cough or breathe, have someone call local emergency services. Lean them forward and give up to 5 firm back blows between the shoulder blades, checking after each blow.",
        "If this is not enough, give up to 5 abdominal thrusts: stand behind, place your fist between the navel and lower sternum, pull inward and upward.",
        "Alternate up to 5 back blows and 5 abdominal thrusts while the obstruction remains. If they lose consciousness, lower them to the ground and follow emergency dispatch instructions to start resuscitation."
      ],
      "attention": "NEVER use abdominal thrusts on a baby under one year. For pregnancy or other special situations, ask emergency dispatch immediately for appropriate instructions."
    },
    "bebe-etouffement": {
      "title": "Choking infant",
      "signal": "An infant under one year cannot cry, cough effectively or breathe because of an object.",
      "audience": "Infant under one year",
      "steps": [
        "Ask for help immediately and have someone call local emergency services. If the baby coughs effectively or cries, monitor and seek medical advice.",
        "If air cannot pass: support the head and neck, place the infant face down along your forearm or thigh with the head lower than the body, and give up to 5 firm back blows between the shoulder blades.",
        "If the object does not come out, gently turn the infant face up, keeping the head lower. Using two fingers on the lower half of the sternum, give up to 5 chest thrusts.",
        "Alternate these actions while the blockage remains, following emergency dispatch instructions. Even if the infant improves, seek medical advice."
      ],
      "attention": "Never shake the infant or give abdominal thrusts. If the infant becomes unconscious, resuscitation procedures differ: immediately follow emergency dispatch instructions."
    },
    "brulure": {
      "title": "Thermal burn",
      "signal": "The skin has been burned by flame, a hot object or hot liquid.",
      "audience": "Thermal burns only",
      "steps": [
        "Move the person away from the heat source if safe.",
        "Cool the burn promptly under gently flowing, temperate water for at least 10 minutes, ideally 20 minutes.",
        "Remove nearby jewellery and clothing only if not stuck to the skin. Cover gently with a clean cloth.",
        "Call local emergency services for a serious, extensive or facial burn, or if in doubt; follow instructions."
      ],
      "attention": "No ice, butter or homemade creams. Do not burst blisters. Chemical or electrical burns require different instructions: call emergency services."
    },
    "avc": {
      "title": "Signs of stroke",
      "signal": "Sudden facial droop, arm weakness or unusual speech.",
      "audience": "Anyone with these signs",
      "steps": [
        "Look for a drooping face, inability to lift one arm, or speech difficulties.",
        "Call local emergency services immediately, even if symptoms go away. Do not wait.",
        "Note the time symptoms began. Help the person sit or lie down and reassure them.",
        "Do not give food, drink or medication without medical instructions. Follow dispatch advice."
      ],
      "attention": "Sudden changes in vision or balance, or an unusual headache, can also be signs of stroke. Call without delay."
    }
  },
  "es": {
    "arret-cardiaque": {
      "title": "No respira normalmente",
      "signal": "Una persona adulta no responde y no respira normalmente, o solo jadea.",
      "audience": "Reanimación cardiopulmonar de adultos únicamente",
      "steps": [
        "Comprueba que el lugar sea seguro para ti. Comprueba si la persona responde y respira normalmente.",
        "Pide que llamen inmediatamente a los servicios locales de emergencia y soliciten un desfibrilador externo automático (DEA). Si estás solo, llama con el altavoz activado.",
        "Inicia las compresiones torácicas: ambas manos en el centro del pecho, brazos rectos, de 100 a 120 por minuto, unos 5 a 6 cm de profundidad en adultos. Deja que el pecho se eleve entre compresiones.",
        "Si tienes formación y puedes hacerlo, alterna 30 compresiones y 2 ventilaciones. Si no, continúa las compresiones sin interrupciones innecesarias.",
        "Enciende el DEA cuando llegue, coloca los electrodos según las indicaciones y sigue sus instrucciones de voz. Continúa hasta que lleguen los profesionales o vuelva la respiración normal."
      ],
      "attention": "En bebés, niños, ahogamientos u otras situaciones especiales, los procedimientos pueden variar: sigue inmediatamente las instrucciones de emergencias."
    },
    "hemorragie": {
      "title": "Hemorragia grave",
      "signal": "La sangre fluye de forma abundante o continua.",
      "audience": "Adulto o niño — con protección frente a la sangre",
      "steps": [
        "Protégete del peligro y evita tocar la sangre directamente: usa guantes, una bolsa o un paño si es posible.",
        "Aplica presión firme y directa sobre la herida con un paño limpio o apósito adecuado. Si es posible, pide a la persona que presione ella misma.",
        "Ayuda a la persona a tumbarse si es seguro y llama a los servicios locales de emergencia.",
        "Mantén la presión sin soltar hasta que llegue la ayuda. Sigue las instrucciones del operador."
      ],
      "attention": "Si hay un objeto clavado en la herida, no lo retires. Pregunta a emergencias cómo presionar alrededor. Una hemorragia grave puede poner en peligro la vida."
    },
    "inconscience": {
      "title": "Inconsciente, pero respira",
      "signal": "La persona no responde, pero respira normalmente.",
      "audience": "Sin traumatismo evidente",
      "steps": [
        "Comprueba tu seguridad, intenta hablar con la persona y observa su respiración.",
        "Llama a los servicios locales de emergencia y sigue sus instrucciones. Si respira normalmente y no sospechas una lesión grave, colócala de lado (posición lateral de seguridad).",
        "Para girarla de lado: brazo cercano en ángulo recto, mano opuesta contra su mejilla, rodilla lejana flexionada; tira suavemente de esa rodilla hacia ti.",
        "Estabilízala de lado, con la boca hacia el suelo. Vigila la respiración con frecuencia hasta que llegue la ayuda."
      ],
      "attention": "Tras una caída o accidente con posible lesión de espalda o cuello, consulta a emergencias antes de mover a la persona. Si no respira normalmente, consulta la ficha de parada cardíaca."
    },
    "etouffement": {
      "title": "Atragantamiento: adulto o niño",
      "signal": "Una persona consciente ya no puede hablar, toser eficazmente ni respirar tras tragar algo.",
      "audience": "Adulto y niño mayor de un año — excepto durante el embarazo",
      "steps": [
        "Si puede toser eficazmente y respirar, anímala a toser. No le des golpes en la espalda.",
        "Si ya no puede toser ni respirar, pide que llamen a los servicios locales de emergencia. Inclínala hacia delante y da hasta 5 golpes firmes entre los omóplatos, comprobando después de cada uno.",
        "Si no basta, realiza hasta 5 compresiones abdominales: detrás de la persona, coloca el puño entre el ombligo y la parte inferior del esternón y tira hacia dentro y arriba.",
        "Alterna hasta 5 golpes en la espalda y 5 compresiones abdominales mientras persista la obstrucción. Si pierde el conocimiento, bájala al suelo y sigue las instrucciones de emergencias para iniciar la reanimación."
      ],
      "attention": "NUNCA realices compresiones abdominales a un bebé menor de un año. En caso de embarazo u otra situación especial, pide inmediatamente a emergencias el procedimiento adecuado."
    },
    "bebe-etouffement": {
      "title": "Bebé que se atraganta",
      "signal": "Un bebé menor de un año no puede llorar, toser eficazmente ni respirar debido a un objeto.",
      "audience": "Bebé menor de un año",
      "steps": [
        "Pide ayuda inmediatamente y que llamen a los servicios locales de emergencia. Si el bebé tose eficazmente o llora, vigílalo y solicita consejo médico.",
        "Si no pasa el aire: sostén la cabeza y el cuello, pon al bebé boca abajo sobre el antebrazo o el muslo con la cabeza más baja que el cuerpo y da hasta 5 golpes firmes entre los omóplatos.",
        "Si el objeto no sale, gira al bebé con cuidado boca arriba, manteniendo la cabeza más baja. Con dos dedos sobre la mitad inferior del esternón, realiza hasta 5 compresiones torácicas.",
        "Alterna ambos procedimientos mientras persista la obstrucción, siguiendo las instrucciones de emergencias. Incluso si el bebé mejora, solicita consejo médico."
      ],
      "attention": "Nunca sacudas al bebé ni realices compresiones abdominales. Si pierde el conocimiento, los procedimientos de reanimación cambian: sigue inmediatamente las instrucciones de emergencias."
    },
    "brulure": {
      "title": "Quemadura térmica",
      "signal": "La piel se ha quemado por una llama, un objeto caliente o un líquido caliente.",
      "audience": "Solo quemaduras térmicas",
      "steps": [
        "Aleja a la persona de la fuente de calor si puedes hacerlo sin peligro.",
        "Enfría rápidamente la quemadura con agua corriente templada y un caudal suave durante al menos 10 minutos, idealmente 20 minutos.",
        "Retira las joyas y prendas cercanas solo si no están adheridas a la piel. Cubre suavemente con un paño limpio.",
        "Llama a los servicios locales de emergencia si la quemadura es grave, extensa, afecta a la cara o tienes dudas; sigue sus instrucciones."
      ],
      "attention": "No uses hielo, mantequilla ni cremas caseras. No revientes las ampollas. Las quemaduras químicas o eléctricas requieren instrucciones distintas: llama a emergencias."
    },
    "avc": {
      "title": "Signos de ictus",
      "signal": "De repente, la cara se desvía, un brazo pierde fuerza o la persona habla de forma extraña.",
      "audience": "Cualquier persona con estos signos",
      "steps": [
        "Observa si hay desviación de la cara, imposibilidad de levantar un brazo o dificultad para hablar.",
        "Llama inmediatamente a los servicios locales de emergencia, aunque desaparezcan los síntomas. No esperes.",
        "Anota la hora a la que empezaron los síntomas. Ayuda a la persona a sentarse o tumbarse y tranquilízala.",
        "No le des de comer, beber ni medicamentos sin instrucciones médicas. Sigue las indicaciones telefónicas."
      ],
      "attention": "Una alteración repentina de la visión o del equilibrio, o un dolor de cabeza inusual, también pueden ser signos de ictus. Llama sin demora."
    }
  }
};

function urgence() {
  const country = selectedCountry();
  const verified = emergencyFor(country);
  return html`<div class="rp-aid-callout"><div><strong>Danger immédiat ? Appelle les secours.</strong><small>Ces fiches de premiers secours ont été rédigées pour la France. <a href="#/monde" style="color:#fff;text-decoration:underline">Choisir le pays et vérifier le numéro local</a>. ${verified?.kind === "ambulance" ? "Le numéro indiqué ne contacte que les ambulances." : verified?.kind === "fire-medical" ? "Le numéro indiqué contacte les pompiers et les ambulances, pas la police." : ""}</small></div>${verified ? html`<a class="rp-call-btn" href="tel:${verified.number}" aria-label="Composer le numéro ${verified.number}">📞 ${verified.number}</a>` : html`<a class="rp-call-btn" href="#/monde">🌍 Pays</a>`}</div>`;
}

function notice() {
  return html`<p class="rp-aid-disclaimer">⚠️ Les gestes et numéros cités dans ces fiches sont rédigés pour la France. Hors de France, vérifie les numéros et recommandations locales avant de les utiliser. Aide-mémoire pédagogique pour la France, pas une formation ni une assistance en direct. Commence par te mettre en sécurité et appeler les secours. Les appels téléphoniques nécessitent une couverture mobile ou téléphonique disponible. Synthèses rédigées à partir des pages citées le 22/11/2026, sans validation par un organisme de secourisme ; ces fiches ne se mettent pas à jour toutes seules.</p>`;
}

export function renderSecours(root: HTMLElement, id?: string): void {
  const fiche = FICHES.find(f => f.id === id);
  if (id && !fiche) { location.hash = "#/secours"; return; }
  if (fiche) {
    mount(root, html`
      <section class="rp-aid-top"><a class="rp-back" href="#/secours">← Tous les gestes</a><div class="rp-aid-detail-icon" aria-hidden="true">${fiche.icon}</div><span class="rp-eyebrow">Premiers secours · France</span><h1>${fiche.title}</h1><p class="rp-aid-signal">${fiche.signal}</p><span class="rp-aid-audience">${fiche.audience}</span></section>
      ${urgence()}
      <section class="card rp-aid-steps"><h2>Les gestes à faire</h2><ol>${fiche.steps.map(step => html`<li>${step}</li>`)}</ol></section>
      <section class="rp-aid-warning"><strong>⚠️ Attention</strong><p>${fiche.attention}</p></section>
      ${notice()}
      <p class="rp-aid-source">Source : <a href="${fiche.url}" target="_blank" rel="noopener noreferrer">${fiche.source}</a> (lien nécessitant Internet).</p>
      <div class="btn-row"><a class="btn" href="#/secours">← Choisir un autre geste</a></div>`);
    return;
  }
  mount(root, html`
    <section class="rp-aid-landing"><a class="rp-back" href="#/">← Accueil</a><span class="rp-eyebrow">Aide-mémoire · France</span><h1>Les gestes qui sauvent 🩹</h1><p>Un problème ? Choisis ce que tu vois. Si tu es enfant, appelle aussi un adulte tout de suite.</p></section>
    ${urgence()}
    <section class="rp-aid-first"><span aria-hidden="true">🛡️</span><div><strong>D'abord, protège-toi.</strong><p>Ne t'approche pas d'un feu, d'une route dangereuse ou d'un fil électrique. Donne le lieu et le problème aux secours, puis suis leurs consignes.</p></div></section>
    <section class="rp-aid-grid" aria-label="Choisir une situation">${FICHES.map(f => html`<a class="rp-aid-tile" href="#/secours/${f.id}"><span class="rp-aid-tile-icon" aria-hidden="true">${f.icon}</span><strong>${f.title}</strong><span class="rp-aid-tile-arrow" aria-hidden="true">→</span></a>`)}</section>
    ${notice()}
    <section class="rp-aid-sources"><h2>Sources de confiance</h2><p>Ces résumés ont été rédigés à partir des fiches de la <a href="https://www.croix-rouge.fr/les-gestes-de-premiers-secours" target="_blank" rel="noopener noreferrer">Croix-Rouge française</a>, d'<a href="https://www.ameli.fr/assure/sante/urgence/pathologies/avc" target="_blank" rel="noopener noreferrer">Ameli</a> et de <a href="https://www.service-public.gouv.fr/particuliers/vosdroits/F33954" target="_blank" rel="noopener noreferrer">Service-Public</a>. Une formation de premiers secours reste essentielle.</p></section>`);
}
