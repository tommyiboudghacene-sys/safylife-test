import { html, mount } from "./ui.js";
import { countryAtPoint, decodeWorld, type Country, type Point, type WorldData } from "./world-core.js";
import { WORLD_PRACTICES, WORLD_PRACTICES_REVIEWED } from "./world-practices.js";
import { loadEarthquakes, USGS_HOME, type EarthquakeObservation } from "./live-earthquakes.js";

const CODES = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BR BS BT BW BY BZ CA CD CF CG CH CI CK CL CM CN CO CR CU CV CW CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GG GH GL GM GN GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RO RS RU RW SA SB SC SD SE SG SH SI SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TL TM TN TO TR TT TV TW TZ UA UG US UY UZ VA VC VE VG VI VN VU WF WS XK YE ZA ZM ZW".split(" ");
const CODE_SET = new Set(CODES);
const EU = new Set("AT BE BG HR CY CZ DK EE FI FR DE GR HU IE IT LV LT LU MT NL PL PT RO SK SI ES SE".split(" "));
const STORAGE_COUNTRY = "resilience-pocket:country:1";
const STORAGE_LANG = "resilience-pocket:language:1";

type VerifiedNumber = { number: string; kind: "all" | "ambulance" | "fire-medical"; source: string; url: string };
const VERIFIED: Record<string, VerifiedNumber> = {
  AL: { number: "127", kind: "ambulance", source: "GOV.UK — albania (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/albania/getting-help" },
  AZ: { number: "103", kind: "ambulance", source: "GOV.UK — azerbaijan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/azerbaijan/getting-help" },
  SM: { number: "118", kind: "ambulance", source: "GOV.UK — san-marino (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/san-marino/getting-help" },
  MK: { number: "194", kind: "ambulance", source: "GOV.UK — north-macedonia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/north-macedonia/getting-help" },
  AD: { number: "116", kind: "ambulance", source: "GOV.UK — andorra (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/andorra/getting-help" },
  XK: { number: "112", kind: "all", source: "GOV.UK — kosovo (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/kosovo/getting-help" },
  IS: { number: "112", kind: "all", source: "GOV.UK — iceland (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/iceland/getting-help" },
  MD: { number: "112", kind: "all", source: "GOV.UK — moldova (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/moldova/getting-help" },
  GE: { number: "112", kind: "all", source: "GOV.UK — georgia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/georgia/getting-help" },
  BA: { number: "124", kind: "ambulance", source: "GOV.UK — bosnia-and-herzegovina (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bosnia-and-herzegovina/getting-help" },
  GH: { number: "112", kind: "all", source: "GOV.UK — ghana (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/ghana/getting-help" },
  HK: { number: "999", kind: "all", source: "GOV.UK — hong-kong (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/hong-kong/getting-help" },
  CR: { number: "911", kind: "all", source: "GOV.UK — costa-rica (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/costa-rica/getting-help" },
  JO: { number: "911", kind: "all", source: "GOV.UK — jordan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/jordan/getting-help" },
  TW: { number: "119", kind: "fire-medical", source: "GOV.UK — taiwan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/taiwan/getting-help" },
  LK: { number: "1990", kind: "ambulance", source: "GOV.UK — sri-lanka (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/sri-lanka/getting-help" },
  RS: { number: "112", kind: "all", source: "GOV.UK — serbia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/serbia/getting-help" },
  AE: { number: "998", kind: "ambulance", source: "GOV.UK \u2014 united-arab-emirates (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/united-arab-emirates/getting-help" },
  BH: { number: "999", kind: "all", source: "GOV.UK \u2014 bahrain (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bahrain/getting-help" },
  BO: { number: "118", kind: "ambulance", source: "GOV.UK \u2014 bolivia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bolivia/getting-help" },
  EC: { number: "911", kind: "all", source: "GOV.UK \u2014 ecuador (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/ecuador/getting-help" },
  OM: { number: "9999", kind: "all", source: "GOV.UK \u2014 oman (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/oman/getting-help" },
  PE: { number: "106", kind: "ambulance", source: "GOV.UK \u2014 peru (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/peru/getting-help" },
  PY: { number: "141", kind: "ambulance", source: "GOV.UK \u2014 paraguay (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/paraguay/getting-help" },
  QA: { number: "999", kind: "all", source: "GOV.UK \u2014 qatar (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/qatar/getting-help" },
  UY: { number: "911", kind: "all", source: "GOV.UK \u2014 uruguay (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/uruguay/getting-help" },
  // Local government sources preferred where they differ from foreign travel advice.
  AR: { number: "107", kind: "ambulance", source: "Argentina.gob.ar — Emergencias (checked 2026-11-24)", url: "https://www.argentina.gob.ar/node/9642" },
  CL: { number: "131", kind: "ambulance", source: "Gobierno de Chile — Números de emergencia (checked 2026-11-24)", url: "https://www.gob.cl/noticias/principales-recomendaciones-onemi-chile-preparado-ante-la-emergencia/" },
  CO: { number: "123", kind: "all", source: "Función Pública — Línea única nacional (checked 2026-11-24)", url: "https://www1.funcionpublica.gov.co/preguntas-frecuentes/-/asset_publisher/sqxafjubsrEu/content/linea-unica-de-emergencias-nacional-123/28585938" },
  MY: { number: "999", kind: "all", source: "Government of Malaysia — NG MERS 999 (checked 2026-11-24)", url: "https://www.malaysia.gov.my/en/topics/mers-999-emergency-line" },
  KE: { number: "999", kind: "all", source: "GOV.UK — Kenya (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/kenya/getting-help" },
  CN: { number: "120", kind: "ambulance", source: "GOV.UK — China (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/china/getting-help" },
  PK: { number: "1122", kind: "fire-medical", source: "GOV.UK — Pakistan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/pakistan/getting-help" },
  BD: { number: "999", kind: "all", source: "GOV.UK — Bangladesh (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bangladesh/getting-help" },
  EG: { number: "123", kind: "ambulance", source: "GOV.UK — Egypt (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/egypt/getting-help" },
  VN: { number: "115", kind: "ambulance", source: "GOV.UK — Vietnam (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/vietnam/getting-help" },

  // Source: Japan National Tourism Organization, 119 = fire + ambulance, not police.
  JP: { number: "119", kind: "fire-medical", source: "JNTO — Office national du tourisme du Japon", url: "https://www.jnto.go.jp/emergency/index.html" },
  // Source: Morocco FCDO advice, 150 = fire + ambulance (police has a different line).
  MA: { number: "150", kind: "fire-medical", source: "GOV.UK — Emergency services in Morocco", url: "https://www.gov.uk/foreign-travel-advice/morocco/getting-help" },
  // Source: Korea Tourism Organization, fire/ambulance = 119, police = 112.
  KR: { number: "119", kind: "fire-medical", source: "Korea Tourism Organization", url: "https://english.visitkorea.or.kr/svc/contents/contentsView.do?menuSn=217&vcontsId=248145" },
  GB: { number: "999", kind: "all", source: "GOV.UK", url: "https://www.gov.uk/guidance/999-and-112-the-uks-national-emergency-numbers" },
  US: { number: "911", kind: "all", source: "National 911 Program (États-Unis)", url: "https://www.911.gov/calling-911/" },
  CA: { number: "911", kind: "all", source: "Parcs Canada — numéros d'urgence", url: "https://parks.canada.ca/voyage-travel/securite-safety/urgence-emergency" },
  AU: { number: "000", kind: "all", source: "Gouvernement australien — Triple Zero", url: "https://www.triplezero.gov.au/" },
  NZ: { number: "111", kind: "all", source: "Gouvernement de Nouvelle-Zélande", url: "https://www.govt.nz/browse/law-crime-and-justice/crimes-and-emergencies/111-emergency-service/" },
  IN: { number: "112", kind: "all", source: "Ministère de l'Intérieur de l'Inde", url: "https://www.mha.gov.in/emergency-response-support-system-erss" },
  BR: { number: "192", kind: "ambulance", source: "Ministère de la Santé du Brésil", url: "https://www.gov.br/saude/pt-br/composicao/saes/samu-192" },
  // Added 24/11/2026 from GOV.UK "Getting help" pages (FCDO travel advice), checked live.
  MX: { number: "911", kind: "all", source: "GOV.UK — Emergency services in Mexico (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/mexico/getting-help" },
  TR: { number: "112", kind: "all", source: "GOV.UK — Emergency services in Turkey (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/turkey/getting-help" },
  PH: { number: "911", kind: "all", source: "GOV.UK — Emergency services in the Philippines (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/philippines/getting-help" },
  CH: { number: "112", kind: "all", source: "GOV.UK — Emergency services in Switzerland (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/switzerland/getting-help" },
  ZA: { number: "10177", kind: "fire-medical", source: "GOV.UK — Emergency services in South Africa (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/south-africa/getting-help" },
  TH: { number: "1669", kind: "ambulance", source: "GOV.UK — Emergency services in Thailand (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/thailand/getting-help" },
  ID: { number: "118", kind: "ambulance", source: "GOV.UK — Emergency services in Indonesia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/indonesia/getting-help" },
  NO: { number: "113", kind: "ambulance", source: "GOV.UK — Emergency services in Norway (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/norway/getting-help" },
  SG: { number: "995", kind: "fire-medical", source: "Singapore Civil Defence Force", url: "https://www.scdf.gov.sg/home/about-scdf/emergency-medical-services" },
};
const EU_INFO = { number: "112", kind: "all" as const, source: "Union européenne — Your Europe", url: "https://europa.eu/youreurope/citizens/travel/security-and-emergencies/emergency/index_en.htm" };
export type GlobalNumber = VerifiedNumber;
export type AdditionalEmergencyNumber = { number: string; type: "police" | "police-mobile" | "police-landline" | "fire"; source: string; url: string };
// Keep distinct agencies distinct. These are not unified emergency dispatch numbers.
const ADDITIONAL: Record<string, AdditionalEmergencyNumber[]> = {
  AL: [{ number: "128", type: "fire", source: "GOV.UK — albania (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/albania/getting-help" }, { number: "112", type: "police", source: "GOV.UK — albania (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/albania/getting-help" }],
  AZ: [{ number: "101", type: "fire", source: "GOV.UK — azerbaijan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/azerbaijan/getting-help" }, { number: "102", type: "police", source: "GOV.UK — azerbaijan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/azerbaijan/getting-help" }],
  SM: [{ number: "115", type: "fire", source: "GOV.UK — san-marino (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/san-marino/getting-help" }, { number: "113", type: "police", source: "GOV.UK — san-marino (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/san-marino/getting-help" }],
  MK: [{ number: "192", type: "police", source: "GOV.UK — north-macedonia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/north-macedonia/getting-help" }],
  AD: [{ number: "118", type: "fire", source: "GOV.UK — andorra (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/andorra/getting-help" }, { number: "110", type: "police", source: "GOV.UK — andorra (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/andorra/getting-help" }],
  BA: [{ number: "123", type: "fire", source: "GOV.UK — bosnia-and-herzegovina (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bosnia-and-herzegovina/getting-help" }, { number: "122", type: "police", source: "GOV.UK — bosnia-and-herzegovina (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bosnia-and-herzegovina/getting-help" }],
  TW: [{ number: "110", type: "police", source: "GOV.UK — taiwan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/taiwan/getting-help" }],
  LK: [{ number: "119", type: "police", source: "GOV.UK — sri-lanka (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/sri-lanka/getting-help" }, { number: "111", type: "fire", source: "GOV.UK — sri-lanka (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/sri-lanka/getting-help" }],
  RS: [{ number: "192", type: "police", source: "GOV.UK — serbia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/serbia/getting-help" }, { number: "193", type: "fire", source: "GOV.UK — serbia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/serbia/getting-help" }],
  AE: [{ number: "999", type: "police", source: "GOV.UK \u2014 united-arab-emirates (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/united-arab-emirates/getting-help" }, { number: "997", type: "fire", source: "GOV.UK \u2014 united-arab-emirates (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/united-arab-emirates/getting-help" }],
  BO: [{ number: "110", type: "police", source: "GOV.UK \u2014 bolivia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bolivia/getting-help" }, { number: "119", type: "fire", source: "GOV.UK \u2014 bolivia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/bolivia/getting-help" }],
  PE: [{ number: "105", type: "police", source: "GOV.UK \u2014 peru (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/peru/getting-help" }, { number: "116", type: "fire", source: "GOV.UK \u2014 peru (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/peru/getting-help" }],
  PY: [{ number: "911", type: "police", source: "GOV.UK \u2014 paraguay (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/paraguay/getting-help" }, { number: "132", type: "fire", source: "GOV.UK \u2014 paraguay (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/paraguay/getting-help" }],
  AR: [{ number: "911", type: "police", source: "GOV.UK — Argentina (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/argentina/getting-help" }, { number: "100", type: "fire", source: "Argentina.gob.ar — Emergencias (checked 2026-11-24)", url: "https://www.argentina.gob.ar/node/9642" }],
  CL: [{ number: "133", type: "police", source: "Gobierno de Chile (checked 2026-11-24)", url: "https://www.gob.cl/noticias/principales-recomendaciones-onemi-chile-preparado-ante-la-emergencia/" }, { number: "132", type: "fire", source: "Gobierno de Chile (checked 2026-11-24)", url: "https://www.gob.cl/noticias/principales-recomendaciones-onemi-chile-preparado-ante-la-emergencia/" }],
  CO: [{ number: "119", type: "fire", source: "GOV.UK — Colombia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/colombia/getting-help" }],
  CN: [{ number: "110", type: "police", source: "GOV.UK — China (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/china/getting-help" }, { number: "119", type: "fire", source: "GOV.UK — China (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/china/getting-help" }],
  PK: [{ number: "15", type: "police", source: "GOV.UK — Pakistan (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/pakistan/getting-help" }],
  EG: [{ number: "122", type: "police", source: "GOV.UK — Egypt (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/egypt/getting-help" }, { number: "180", type: "fire", source: "GOV.UK — Egypt (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/egypt/getting-help" }],
  VN: [{ number: "113", type: "police", source: "GOV.UK — Vietnam (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/vietnam/getting-help" }, { number: "114", type: "fire", source: "GOV.UK — Vietnam (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/vietnam/getting-help" }],

  JP: [{ number: "110", type: "police", source: "JNTO — Office national du tourisme du Japon", url: "https://www.jnto.go.jp/emergency/index.html" }],
  KR: [{ number: "112", type: "police", source: "Korea Tourism Organization", url: "https://english.visitkorea.or.kr/svc/contents/contentsView.do?menuSn=217&vcontsId=248145" }],
  ZA: [{ number: "10111", type: "police", source: "GOV.UK — Emergency services in South Africa (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/south-africa/getting-help" }],
  TH: [{ number: "191", type: "police", source: "GOV.UK — Emergency services in Thailand (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/thailand/getting-help" }],
  ID: [{ number: "110", type: "police", source: "GOV.UK — Emergency services in Indonesia (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/indonesia/getting-help" }],
  NO: [{ number: "112", type: "police", source: "GOV.UK — Emergency services in Norway (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/norway/getting-help" }],
  CH: [{ number: "117", type: "police", source: "GOV.UK — Emergency services in Switzerland (checked 2026-11-24)", url: "https://www.gov.uk/foreign-travel-advice/switzerland/getting-help" }],
  MA: [
    { number: "190", type: "police-mobile", source: "U.S. Department of State", url: "https://travel.state.gov/en/international-travel/travel-advisories/morocco.html" },
    { number: "19", type: "police-landline", source: "France Diplomatie", url: "https://www.diplomatie.gouv.fr/fr/information-par-pays/maroc/conseils-aux-voyageurs-contacts-utiles" },
  ],
};
export function additionalEmergencyNumbersFor(code: string): AdditionalEmergencyNumber[] { return CODE_SET.has(code) && Object.hasOwn(ADDITIONAL, code) ? (ADDITIONAL[code] ?? []) : []; }

export function emergencyFor(code: string): GlobalNumber | null {
  if (EU.has(code)) return EU_INFO;
  return CODE_SET.has(code) && Object.hasOwn(VERIFIED, code) ? (VERIFIED[code] ?? null) : null;
}

/** Explicit limits reported by the official sources; no inferred nationwide coverage. */
export function emergencyCoverageNote(code: string, lang: "fr" | "en" | "es"): string {
  if (code === "PE") return {
    fr: "Le SAMU (106) couvre Lima et certaines régions. Vérifie la disponibilité locale ; les numéros de police et de pompiers restent distincts.",
    en: "SAMU (106) covers Lima and certain regions. Check local availability; police and fire have separate numbers.",
    es: "El SAMU (106) cubre Lima y determinadas regiones. Comprueba la disponibilidad local; policía y bomberos tienen números distintos.",
  }[lang];
  return "";
}

/** Official directories are reference links, never substituted for a phone number. */
export function emergencyReferenceLinks(lang: "fr" | "en" | "es") {
  const labels = {fr:["Conseils officiels par pays (France Diplomatie)","Conseils officiels par pays (GOV.UK)","Registre des numéros (UIT, dates variables)"],en:["Official travel advice by country (France)","Official travel advice by country (GOV.UK)","ITU number register (dates vary)"],es:["Consejos oficiales por país (Francia)","Consejos oficiales por país (GOV.UK)","Registro de números de la UIT (fechas variables)"]}[lang];
  return html`<ul class="rp-terrain-linklist">${["https://www.diplomatie.gouv.fr/fr/conseils-aux-voyageurs","https://www.gov.uk/foreign-travel-advice","https://www.itu.int/net/itu-t/inrdb/e129_important_numbers.aspx"].map((url,i)=>html`<li><a href="${url}" target="_blank" rel="noopener noreferrer">${labels[i]} ↗</a></li>`)}</ul>`;
}

export const PERU_COVERAGE_SOURCE = "https://www.gob.pe/547";

export function selectedCountry(): string {
  try {
    const code = localStorage.getItem(STORAGE_COUNTRY) ?? "";
    return CODE_SET.has(code) ? code : ephemeralCountry;
  } catch { return ephemeralCountry; }
}

let ephemeralCountry = "";
export function chooseCountry(code: string): void {
  if (!CODE_SET.has(code) && code !== "") return;
  ephemeralCountry = code;
  try { localStorage.setItem(STORAGE_COUNTRY, code); } catch { /* no persistent storage for some file:// pages */ }
}

type Language = "fr" | "en" | "es";
let ephemeralLanguage: Language = "fr";
export function currentLanguage(): Language {
  try {
    const val = localStorage.getItem(STORAGE_LANG);
    return val === "en" || val === "es" || val === "fr" ? val : ephemeralLanguage;
  } catch { return ephemeralLanguage; }
}

function chooseLanguage(lang: Language) {
  ephemeralLanguage = lang;
  try { localStorage.setItem(STORAGE_LANG, lang); } catch { /* in-memory only */ }
}

export function countryName(code: string, lang: Language): string {
  if (code === "XK") return lang === "fr" ? "Kosovo" : "Kosovo";
  try { return new Intl.DisplayNames([lang], { type: "region" }).of(code) ?? code; }
  catch { return code; }
}

/** All country options are available offline for the SOS and World screens. */
export function countryOptions(lang: Language = "fr"): { code: string; title: string }[] {
  return CODES.map(code => ({ code, title: countryName(code, lang) }))
    .sort((a, b) => a.title.localeCompare(b.title, lang));
}

const UI = {
  fr: { headline: "Le monde dans ta poche", sub: "Choisis un pays pour ses numéros d'urgence. La carte générale fonctionne hors connexion.", choose: "Pays ou territoire", empty: "Sélectionner un pays", emergency: "Secours dans ce pays", verify: "Numéro documenté par une source officielle", only: "Ambulance uniquement — pas un numéro général", police: "Police", policeMobile: "Police (mobile)", policeLandline: "Police (ligne fixe)", fireMedical: "Pompiers et ambulance — pas la police", unknown: "Pas de numéro national suffisamment vérifié pour ce pays. Consulte les autorités locales et prépare ton plan avant le départ.", call: "Appeler", detect: "Détecter mon pays (GPS)", ready: "Carte générale hors connexion", mapHelp: "Contours approximatifs des pays, sans rues ni itinéraires. Elle ne permet pas de choisir une voie d'évacuation.", en: "Certaines informations du reste de l'application sont encore spécifiques à la France.", source: "Vérifier la source", location: "Pays estimé : vérifie la sélection, surtout près des frontières et des côtes.", error: "Position indisponible ou autorisation refusée. Choisis ton pays dans la liste.", alerts: "Alertes mondiales (Internet)", selectFirst: "Choisis un pays pour afficher les informations disponibles.", back: "Accueil", tools: "GPS · Outils", load: "Chargement de la carte locale…", loaded: "pays et zones cartographiés localement · aucune connexion nécessaire", failed: "La carte n'a pas pu être chargée. Les numéros enregistrés restent accessibles.", note: "Carte : Natural Earth (domaine public), frontières simplifiées. La localisation peut être approximative. Les numéros d'urgence doivent être vérifiés auprès des autorités locales ; les appels nécessitent un réseau téléphonique.", unfound: "Localisation obtenue, mais le pays n'a pas pu être identifié. Sélection manuelle conseillée." },
  en: { headline: "The world in your pocket", sub: "Choose a country for its emergency number. The basic world map works offline.", choose: "Country or territory", empty: "Select a country", emergency: "Emergency services in this country", verify: "Number documented by an official source", only: "Ambulance only — not a general emergency line", police: "Police", policeMobile: "Police (mobile)", policeLandline: "Police (landline)", fireMedical: "Fire and ambulance — not the police", unknown: "No sufficiently verified national number for this country. Check local official guidance before travelling.", call: "Call", detect: "Locate my country (GPS)", ready: "Offline overview map", mapHelp: "Approximate country outlines only, no roads or routes. Never use this map to choose an evacuation route.", en: "Other areas of this application are still France-specific.", source: "Check official source", location: "Estimated country: verify your selection near borders or coasts.", error: "Location unavailable or permission denied. Select your country manually.", alerts: "Global alerts (Internet)", selectFirst: "Choose a country to see available information.", back: "Home", tools: "GPS · Tools", load: "Loading local map…", loaded: "countries and areas mapped locally · no connection required", failed: "The offline map could not load. Saved emergency numbers are still available.", note: "Map: Natural Earth (public domain), simplified borders. Location may be inaccurate. Verify emergency numbers with local authorities; phone calls require telephone coverage.", unfound: "Location received but country could not be identified. Please choose manually." },
  es: { headline: "El mundo en tu bolsillo", sub: "Elige un país para conocer su número de emergencia. El mapa general funciona sin conexión.", choose: "País o territorio", empty: "Seleccionar un país", emergency: "Emergencias en este país", verify: "Número comprobado con una fuente oficial", only: "Solo ambulancias — no es un número general", police: "Policía", policeMobile: "Policía (móvil)", policeLandline: "Policía (línea fija)", fireMedical: "Bomberos y ambulancias — no policía", unknown: "No tenemos un número nacional suficientemente verificado para este país. Consulta las autoridades locales antes de viajar.", call: "Llamar", detect: "Detectar mi país (GPS)", ready: "Mapa general sin conexión", mapHelp: "Fronteras aproximadas, sin calles ni rutas. No lo uses para elegir una vía de evacuación.", en: "Otras secciones de la aplicación siguen siendo específicas de Francia.", source: "Ver fuente oficial", location: "País estimado: comprueba la selección cerca de fronteras y costas.", error: "Ubicación no disponible o permiso denegado. Elige un país manualmente.", alerts: "Alertas mundiales (Internet)", selectFirst: "Selecciona un país para ver la información disponible.", back: "Inicio", tools: "GPS · Herramientas", load: "Cargando mapa local…", loaded: "países y zonas cartografiados localmente · sin conexión", failed: "No se pudo cargar el mapa. Los números guardados siguen disponibles.", note: "Mapa: Natural Earth (dominio público), fronteras simplificadas. La ubicación puede ser inexacta. Comprueba los números con las autoridades locales; las llamadas necesitan cobertura telefónica.", unfound: "Ubicación recibida, pero no se pudo identificar el país. Selecciónalo manualmente." },
};

let worldPromise: Promise<Country[]> | null = null;
async function loadAtlas(): Promise<Country[]> {
  if (!worldPromise) worldPromise = (async () => {
    const embedded = document.getElementById("rp-world-data")?.textContent;
    const data = embedded ? JSON.parse(embedded) as WorldData : await fetch("./world-shapes.json").then(r => {
      if (!r.ok) throw new Error("Atlas indisponible");
      return r.json() as Promise<WorldData>;
    });
    return decodeWorld(data);
  })().catch(error => { worldPromise = null; throw error; });
  return worldPromise;
}

function paintMap(canvas: HTMLCanvasElement, countries: Country[], selected: string, pin: Point | null): void {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const w = canvas.width;
  const h = canvas.height;
  const x = (lon: number) => (lon + 180) / 360 * (w - 30) + 15;
  const y = (lat: number) => (90 - lat) / 180 * (h - 30) + 15;
  ctx.fillStyle = "#e5f4f7";
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = "#d3e8e5";
  ctx.lineWidth = 1;
  for (let lon = -150; lon <= 150; lon += 30) {
    ctx.beginPath(); ctx.moveTo(x(lon), 0); ctx.lineTo(x(lon), h); ctx.stroke();
  }
  for (let lat = -60; lat <= 60; lat += 30) {
    ctx.beginPath(); ctx.moveTo(0, y(lat)); ctx.lineTo(w, y(lat)); ctx.stroke();
  }
  for (const land of countries) {
    for (const ring of land.rings) {
      if (ring.points.length < 3) continue;
      ctx.beginPath();
      let prev: Point | null = null;
      for (const p of ring.points) {
        if (!prev || Math.abs(prev.lon - p.lon) > 180) ctx.moveTo(x(p.lon), y(p.lat));
        else ctx.lineTo(x(p.lon), y(p.lat));
        prev = p;
      }
      ctx.closePath();
      ctx.fillStyle = land.code.toUpperCase() === selected ? "#f7c06e" : "#b6d8be";
      ctx.fill();
      ctx.strokeStyle = land.code.toUpperCase() === selected ? "#b06a29" : "#88b2a7";
      ctx.lineWidth = land.code.toUpperCase() === selected ? 2 : .7;
      ctx.stroke();
    }
  }
  if (pin) {
    ctx.beginPath(); ctx.arc(x(pin.lon), y(pin.lat), 10, 0, Math.PI * 2);
    ctx.fillStyle = "#fb673f"; ctx.fill();
    ctx.lineWidth = 4; ctx.strokeStyle = "#ffffff"; ctx.stroke();
  }
}

let temporaryPin: Point | null = null;

export function renderWorld(root: HTMLElement): void {
  const lang = currentLanguage();
  const ui = UI[lang];
  const country = selectedCountry();
  const info = emergencyFor(country);
  const extraNumbers = additionalEmergencyNumbersFor(country);
  const options = countryOptions(lang);
  const practiceLabel = {
    fr: { head: "🌎 Comment d'autres pays se préparent", sub: "Sélection de conseils officiels conservés hors connexion. Ce ne sont ni des actualités en direct ni des alertes ; vérifie toujours les recommandations locales.", date: "Sélection vérifiée le", source: "Source officielle (Internet)" },
    en: { head: "🌎 How other countries prepare", sub: "Selected official recommendations stored offline. These are not live news or alerts; always check local guidance.", date: "Reviewed on", source: "Official source (online)" },
    es: { head: "🌎 Cómo se preparan otros países", sub: "Selección de recomendaciones oficiales guardadas sin conexión. No son noticias ni alertas en tiempo real; consulta siempre las indicaciones locales.", date: "Revisado el", source: "Fuente oficial (Internet)" },
  }[lang];
  const seismic = {
    fr: {title:"🌐 Séismes récents observés dans le monde",intro:"Données scientifiques USGS chargées uniquement si tu appuies sur Actualiser. Il ne s’agit ni d’alertes, ni de prévisions, ni de consignes d’évacuation.",refresh:"Actualiser depuis l’USGS",offline:"Aucune donnée en direct sans Internet. Les fiches de prévention hors connexion restent disponibles.",loading:"Connexion à l’USGS…",error:"Données momentanément indisponibles. Consulte la source officielle sur Internet.",empty:"Aucun événement récent correspondant aux critères du flux.",date:"Heure locale",mag:"Magnitude",source:"Source USGS — événements observés",privacy:"En actualisant, ton appareil contacte directement l’USGS. SAFYLIFE ne transmet pas ta position GPS."},
    en: {title:"🌐 Recently observed earthquakes worldwide",intro:"USGS scientific data are loaded ONLY when you press Refresh. This is NOT an alert, prediction or evacuation guidance.",refresh:"Refresh from USGS",offline:"No live data without Internet. Offline preparation tips remain available.",loading:"Connecting to USGS…",error:"Data unavailable. Check the official source online.",empty:"No recent events matched the feed criteria.",date:"Local time",mag:"Magnitude",source:"USGS — observed events",privacy:"Refresh contacts USGS directly. SAFYLIFE does not transmit your GPS location."},
    es: {title:"🌐 Terremotos observados recientemente en el mundo",intro:"Los datos científicos del USGS se consultan SOLO si pulsas Actualizar. NO son alertas, predicciones ni instrucciones de evacuación.",refresh:"Actualizar desde USGS",offline:"No hay datos actuales sin Internet. Las recomendaciones guardadas siguen disponibles.",loading:"Conectando a USGS…",error:"Datos no disponibles. Consulta la fuente oficial en Internet.",empty:"No hay eventos recientes en este conjunto de datos.",date:"Hora local",mag:"Magnitud",source:"USGS — eventos observados",privacy:"Al actualizar, tu dispositivo contacta directamente con USGS. SAFYLIFE no envía tu GPS."},
  }[lang];
  mount(root, html`
    <section class="rp-page-lead"><a href="#/" class="rp-back">← ${ui.back}</a><span class="rp-eyebrow">🌍 SAFYLIFE · World</span><h1>${ui.headline}</h1><p>${ui.sub}</p></section>
    <section class="rp-world-preferences card"><label for="rp-world-language">🌐 Langue / Language / Idioma</label>
      <select id="rp-world-language"><option value="fr" ${lang === "fr" ? "selected" : ""}>Français</option><option value="en" ${lang === "en" ? "selected" : ""}>English</option><option value="es" ${lang === "es" ? "selected" : ""}>Español</option></select>
      <label for="rp-world-country">📍 ${ui.choose}</label>
      <select id="rp-world-country"><option value="">${ui.empty}</option>${options.map(v => html`<option value="${v.code}" ${country === v.code ? "selected" : ""}>${v.title}</option>`)}</select>
      <button type="button" class="btn" id="rp-world-gps">🧭 ${ui.detect}</button><p id="rp-world-gps-status" class="hint" role="status"></p>
    </section>
    <section class="rp-world-emergency card"><span class="rp-terrain-emoji">🆘</span><h2>${ui.emergency}</h2>
      ${emergencyCoverageNote(country, lang) ? html`<p class="feature-note" data-emergency-coverage>${emergencyCoverageNote(country, lang)} <a href="${PERU_COVERAGE_SOURCE}" target="_blank" rel="noopener noreferrer">${ui.source}</a></p>` : ""}
      ${country && info ? html`<div class="rp-world-emergency-number"><strong>${info.number}</strong><span>${info.kind === "ambulance" ? ui.only : info.kind === "fire-medical" ? ui.fireMedical : ui.verify}</span></div>
        <a class="rp-call-btn rp-terrain-call" href="tel:${info.number}">📞 ${ui.call} ${info.number}</a>
        <p class="hint">${ui.verify} : <a href="${info.url}" rel="noopener noreferrer" target="_blank">${info.source} · ${ui.source}</a></p>`
      : html`<p class="feature-note">${country ? ui.unknown : ui.selectFirst}</p>${country ? emergencyReferenceLinks(lang) : ""}`}
      ${extraNumbers.length ? html`<div class="rp-terrain-numbers">${extraNumbers.map(v => html`<a href="tel:${v.number}" aria-label="${v.type === "fire" ? ({fr:"Pompiers",en:"Fire service",es:"Bomberos"}[lang]) : v.type === "police-mobile" ? ui.policeMobile : v.type === "police-landline" ? ui.policeLandline : ui.police} ${v.number}">📞 ${v.number} · ${v.type === "fire" ? ({fr:"Pompiers",en:"Fire service",es:"Bomberos"}[lang]) : v.type === "police-mobile" ? ui.policeMobile : v.type === "police-landline" ? ui.policeLandline : ui.police}</a>`)}</div><p class="hint">${extraNumbers.map(v => html`<a href="${v.url}" target="_blank" rel="noopener noreferrer">${v.source} (${v.number})</a>`)}</p>` : ""}
      ${country === "FR" ? html`<div class="rp-terrain-numbers"><a href="tel:15">15 · SAMU</a><a href="tel:17">17 · ${ui.police}</a><a href="tel:18">18 · ${{fr:"Pompiers",en:"Fire service",es:"Bomberos"}[lang]}</a><a href="sms:114">114 · ${{fr:"SMS urgence",en:"Emergency SMS",es:"SMS de emergencia"}[lang]}</a></div>` : ""}
    </section>
    <section class="rp-world-atlas card"><span class="rp-eyebrow">🗺️ ${ui.ready}</span><div class="rp-world-canvas-wrap"><canvas id="rp-world-canvas" width="1200" height="600" role="img" aria-label="${ui.ready}"></canvas></div>
      <p id="rp-world-load-status" class="hint" aria-live="polite">${ui.load}</p><p class="hint">${ui.mapHelp}</p></section>
    <section class="card rp-earthquakes" aria-labelledby="rp-earthquakes-title">
      <h2 id="rp-earthquakes-title">${seismic.title}</h2><p>${seismic.intro}</p>
      <button type="button" id="rp-usgs-refresh" class="btn">↻ ${seismic.refresh}</button>
      <p class="hint">${seismic.privacy}</p>
      <div id="rp-usgs-results" role="status" aria-live="polite"><p class="hint">${seismic.offline}</p></div>
      <a href="${USGS_HOME}" target="_blank" rel="noopener noreferrer">${seismic.source} ↗</a>
    </section>
    <section class="rp-global-practices" aria-labelledby="rp-practices-title">
      <h2 id="rp-practices-title">${practiceLabel.head}</h2>
      <p>${practiceLabel.sub} <small>${practiceLabel.date} ${WORLD_PRACTICES_REVIEWED}.</small></p>
      <div class="rp-practices-grid">${WORLD_PRACTICES.map(p => html`<article class="card rp-practice-card"><span aria-hidden="true">${p.icon}</span><h3>${p.title[lang]}</h3><p>${p.detail[lang]}</p><a href="${p.url}" target="_blank" rel="noopener noreferrer">${practiceLabel.source} — ${p.source} ↗</a></article>`)}</div>
    </section>
    <section class="rp-world-bottom"><a href="https://www.gdacs.org/" target="_blank" rel="noopener noreferrer" class="btn">🔔 ${ui.alerts} ↗</a><a href="#/terrain" class="btn">🧭 ${ui.tools}</a></section>
    <p class="rp-small-print">${ui.en} ${ui.note}</p>`);
  const draw = async () => {
    try {
      const countries = await loadAtlas();
      if (!root.isConnected) return;
      const canvas = root.querySelector<HTMLCanvasElement>("#rp-world-canvas")!;
      paintMap(canvas, countries, selectedCountry(), temporaryPin);
      root.querySelector<HTMLElement>("#rp-world-load-status")!.textContent = `✓ ${countries.length} ${ui.loaded}.`;
    } catch {
      if (root.isConnected) root.querySelector<HTMLElement>("#rp-world-load-status")!.textContent = ui.failed;
    }
  };
  void draw();
  root.querySelector<HTMLButtonElement>("#rp-usgs-refresh")?.addEventListener("click",async()=>{
    const button = root.querySelector<HTMLButtonElement>("#rp-usgs-refresh")!;
    const container = root.querySelector<HTMLElement>("#rp-usgs-results")!;
    if (!navigator.onLine) {container.textContent=seismic.offline;return;}
    button.disabled=true;
    container.textContent=seismic.loading;
    try {
      const earthquakes: EarthquakeObservation[] = await loadEarthquakes();
      if (!root.isConnected) return;
      mount(container,html`${earthquakes.length ? html`<ul class="rp-earthquake-list">${earthquakes.map(e => html`<li><strong>M ${e.magnitude.toFixed(1)}</strong> — ${e.place}<small>${seismic.date}: ${new Date(e.at).toLocaleString(lang)} · <a href="${e.url}" target="_blank" rel="noopener noreferrer">USGS ↗</a></small></li>`)}</ul>` : html`<p>${seismic.empty}</p>`}`);
    } catch {if(root.isConnected) container.textContent=seismic.error;}
    finally {if(root.isConnected) button.disabled=false;}
  });
  root.querySelector<HTMLSelectElement>("#rp-world-language")?.addEventListener("change", event => {
    chooseLanguage((event.target as HTMLSelectElement).value as Language);
    renderWorld(root);
  });
  root.querySelector<HTMLSelectElement>("#rp-world-country")?.addEventListener("change", event => {
    chooseCountry((event.target as HTMLSelectElement).value);
    temporaryPin = null;
    renderWorld(root);
  });
  root.querySelector<HTMLButtonElement>("#rp-world-gps")?.addEventListener("click", async () => {
    const status = root.querySelector<HTMLElement>("#rp-world-gps-status")!;
    if (!navigator.geolocation) { status.textContent = ui.error; return; }
    status.textContent = "GPS…";
    try {
      const countries = await loadAtlas();
      navigator.geolocation.getCurrentPosition(position => {
        if (!root.isConnected) return;
        temporaryPin = { lat: position.coords.latitude, lon: position.coords.longitude };
        const found = countryAtPoint(countries, temporaryPin)?.toUpperCase();
        if (found && CODE_SET.has(found)) {
          chooseCountry(found);
          renderWorld(root);
          const label = root.querySelector<HTMLElement>("#rp-world-gps-status");
          if (label) label.textContent = `${ui.location} ${countryName(found, lang)}.`;
        } else status.textContent = ui.unfound;
      }, () => { if (root.isConnected) status.textContent = ui.error; }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
    } catch { if (root.isConnected) status.textContent = ui.error; }
  });
}
