import { html, mount } from "./ui.js";
import { FICHES } from "./fr-secours.js";
import { currentLanguage } from "./fr-world.js";

/** Short, static preparedness cards; available without any network request. */
const CARDS = [
  {
    id: "before", icon: "🎒", title: "Avant toute crise",
    points: [
      "Conservez un plan familial sur papier : contacts, lieux de rendez-vous et besoins particuliers.",
      "Vérifiez vos réserves, médicaments personnels, lampes et batteries de secours.",
      "Téléchargez les informations nécessaires avant une coupure et mettez-les à jour régulièrement.",
    ],
    source: "Ready.gov — Make a Plan", url: "https://www.ready.gov/plan",
  },
  {
    id: "power", icon: "🔦", title: "Panne électrique",
    points: [
      "Utilisez une lampe à piles ou rechargeable et économisez la batterie du téléphone.",
      "Gardez le réfrigérateur et le congélateur fermés autant que possible.",
      "Ne faites jamais fonctionner un groupe électrogène, barbecue ou réchaud à combustible dans un lieu fermé : danger de monoxyde de carbone.",
    ],
    source: "Ready.gov — Power Outages", url: "https://www.ready.gov/power-outages",
  },
  {
    id: "water", icon: "💧", title: "Eau et hygiène",
    points: [
      "Stockez de l'eau potable avant une coupure. Les besoins varient selon les personnes, le climat et la durée.",
      "En cas d'alerte sur la qualité de l'eau, suivez les consignes des autorités locales.",
      "N'utilisez pas une eau suspecte pour boire ou préparer les aliments sans instructions fiables de traitement.",
    ],
    source: "Ready.gov — Water", url: "https://www.ready.gov/water",
  },
  {
    id: "flood", icon: "🌧️", title: "Inondation ou tempête",
    points: [
      "Écoutez les alertes officielles lorsque les réseaux fonctionnent.",
      "Ne marchez pas et ne conduisez pas dans l'eau de crue.",
      "Si une évacuation est ordonnée, suivez les itinéraires indiqués par les autorités.",
    ],
    source: "Ready.gov — Floods", url: "https://www.ready.gov/floods",
  },
  {
    id: "comms", icon: "📻", title: "Plus de réseau",
    points: [
      "Convenez à l'avance d'un point de rencontre et d'un contact extérieur à votre zone.",
      "Gardez les coordonnées importantes sur papier.",
      "Une radio à piles peut fournir des informations officielles si les autres réseaux sont interrompus.",
    ],
    source: "Ready.gov — Communication Plan", url: "https://www.ready.gov/plan",
  },
  {
    id: "conflict", icon: "🛡️", title: "Conflit armé : protéger les civils",
    points: [
      "Préparez à l'avance vos documents, moyens de communication, médicaments personnels et un lieu de regroupement familial.",
      "En cas d'alerte, les consignes de mise à l'abri ou d'évacuation des autorités compétentes priment sur cette application.",
      "Une simulation de réserves ne permet jamais de déterminer si un lieu est à l'abri des violences ou si un trajet est sûr.",
    ],
    source: "Ministère de l'Intérieur — Guide Tous responsables", url: "https://www.interieur.gouv.fr/documentation/ressources/guide-tous-responsables.html",
  },
  {
    id: "quake", icon: "🏚️", title: "Séisme : les premières secondes",
    points: [
      "À l'intérieur, baissez-vous, protégez votre tête et votre cou et abritez-vous sous un meuble solide si possible. Ne courez pas vers la sortie pendant les secousses.",
      "À l'extérieur, éloignez-vous des bâtiments et des fils électriques si vous pouvez le faire sans danger.",
      "Après les secousses, attendez-vous à des répliques. N'entrez pas dans un bâtiment endommagé et suivez les instructions des autorités.",
    ],
    source: "FEMA / Ready.gov — Earthquakes", url: "https://www.ready.gov/earthquakes",
  },
  {
    id: "wildfire", icon: "🔥", title: "Incendie de forêt : partir à temps",
    points: [
      "Repérez à l'avance les consignes locales, les itinéraires d'évacuation et les moyens de recevoir une alerte.",
      "Si les autorités ordonnent l'évacuation, partez selon leurs indications. N'improvisez pas un trajet à travers la fumée ou les flammes.",
      "Ne revenez qu'après autorisation ; les braises, arbres fragilisés et débris peuvent encore être dangereux.",
    ],
    source: "FEMA / Ready.gov — Wildfires", url: "https://www.ready.gov/wildfires",
  },
  {
    id: "pets", icon: "🐕", title: "Protéger les animaux",
    points: [
      "Prévoyez une cage ou une laisse adaptée, de l'eau, des aliments, les traitements habituels et les coordonnées du vétérinaire.",
      "Ajoutez des photos récentes, l'identification et les documents utiles à votre plan d'urgence.",
      "Pendant une alerte, rentrez les animaux à l'abri sans vous mettre en danger et suivez les consignes officielles.",
    ],
    source: "FEMA / Ready.gov — Prepare your pets", url: "https://www.ready.gov/pets",
  },
];

const TRANSLATIONS: Record<"en" | "es", Record<string, { title: string; points: string[] }>> = {
  "en": {
    "before": {
      "title": "Before a crisis",
      "points": [
        "Keep a family plan on paper: contacts, meeting points and special needs.",
        "Check your supplies, personal medicines, flashlights and backup batteries.",
        "Download essential information before an outage and update it regularly."
      ]
    },
    "power": {
      "title": "Power outage",
      "points": [
        "Use a battery-powered or rechargeable flashlight and conserve your phone battery.",
        "Keep the refrigerator and freezer closed as much as possible.",
        "Never run a generator, barbecue or fuel-burning stove in an enclosed space: carbon monoxide hazard."
      ]
    },
    "water": {
      "title": "Water and hygiene",
      "points": [
        "Store drinking water before an outage. Needs vary with the people, climate and duration.",
        "If there is a water-quality alert, follow local authorities’ instructions.",
        "Do not use suspect water for drinking or preparing food without reliable treatment instructions."
      ]
    },
    "flood": {
      "title": "Flood or storm",
      "points": [
        "Listen to official alerts when networks are working.",
        "Do not walk or drive through floodwater.",
        "If evacuation is ordered, follow the routes specified by authorities."
      ]
    },
    "comms": {
      "title": "Communications outage",
      "points": [
        "Agree in advance on a meeting point and a contact outside your area.",
        "Keep important contact details on paper.",
        "A battery-powered radio may provide official information when other networks are unavailable."
      ]
    },
    "conflict": {
      "title": "Armed conflict: protect civilians",
      "points": [
        "Prepare your documents, means of communication, personal medicines and a family meeting point in advance.",
        "During an alert, shelter or evacuation instructions from the competent authorities take priority over this app.",
        "A supply simulation can never establish whether a place is safe from violence or a route is safe."
      ]
    },
    "quake": {
      "title": "Earthquake: the first seconds",
      "points": [
        "Indoors, drop down, protect your head and neck, and shelter under sturdy furniture if possible. Do not run outside during the shaking.",
        "Outdoors, move away from buildings and power lines if you can do so safely.",
        "After shaking, expect aftershocks. Do not enter damaged buildings; follow authorities’ instructions."
      ]
    },
    "wildfire": {
      "title": "Wildfire: leave in time",
      "points": [
        "Learn local guidance, evacuation routes and how to receive alerts in advance.",
        "If authorities order evacuation, follow their instructions. Do not improvise a route through smoke or flames.",
        "Return only when authorized; embers, weakened trees and debris may remain dangerous."
      ]
    },
    "pets": {
      "title": "Protect pets",
      "points": [
        "Prepare an appropriate carrier or leash, water, food, usual medicines and your vet’s contact details.",
        "Include recent photos, identification and useful documents in your emergency plan.",
        "During an alert, bring animals to shelter without putting yourself at risk, and follow official instructions."
      ]
    }
  },
  "es": {
    "before": {
      "title": "Antes de una crisis",
      "points": [
        "Guarda un plan familiar en papel: contactos, puntos de encuentro y necesidades especiales.",
        "Revisa las reservas, los medicamentos personales, las linternas y las baterías de respaldo.",
        "Descarga la información necesaria antes de un corte y actualízala periódicamente."
      ]
    },
    "power": {
      "title": "Corte eléctrico",
      "points": [
        "Usa una linterna a pilas o recargable y ahorra batería del teléfono.",
        "Mantén el frigorífico y el congelador cerrados en lo posible.",
        "Nunca utilices un generador, una barbacoa o un hornillo de combustible en un espacio cerrado: peligro de monóxido de carbono."
      ]
    },
    "water": {
      "title": "Agua e higiene",
      "points": [
        "Almacena agua potable antes de un corte. Las necesidades dependen de las personas, el clima y la duración.",
        "Si hay una alerta sobre la calidad del agua, sigue las instrucciones de las autoridades locales.",
        "No uses agua sospechosa para beber o preparar alimentos sin instrucciones fiables de tratamiento."
      ]
    },
    "flood": {
      "title": "Inundación o tormenta",
      "points": [
        "Escucha las alertas oficiales cuando funcionen las redes.",
        "No camines ni conduzcas por aguas de inundación.",
        "Si se ordena evacuar, sigue las rutas indicadas por las autoridades."
      ]
    },
    "comms": {
      "title": "Sin comunicaciones",
      "points": [
        "Acuerda de antemano un punto de encuentro y un contacto fuera de tu zona.",
        "Guarda los datos de contacto importantes en papel.",
        "Una radio a pilas puede proporcionar información oficial si fallan otras redes."
      ]
    },
    "conflict": {
      "title": "Conflicto armado: proteger a los civiles",
      "points": [
        "Prepara de antemano los documentos, medios de comunicación, medicamentos personales y un punto de reunión familiar.",
        "En caso de alerta, las instrucciones de refugio o evacuación de las autoridades competentes prevalecen sobre esta aplicación.",
        "Una simulación de reservas nunca permite determinar si un lugar está a salvo de la violencia o si una ruta es segura."
      ]
    },
    "quake": {
      "title": "Terremoto: los primeros segundos",
      "points": [
        "Dentro de un edificio, agáchate, protege la cabeza y el cuello y refúgiate debajo de un mueble resistente si es posible. No corras hacia la salida durante las sacudidas.",
        "En el exterior, aléjate de los edificios y cables eléctricos si puedes hacerlo sin peligro.",
        "Tras las sacudidas, espera réplicas. No entres en edificios dañados y sigue las instrucciones de las autoridades."
      ]
    },
    "wildfire": {
      "title": "Incendio forestal: salir a tiempo",
      "points": [
        "Identifica de antemano las instrucciones locales, las rutas de evacuación y cómo recibir alertas.",
        "Si las autoridades ordenan evacuar, sigue sus instrucciones. No improvises una ruta entre el humo o las llamas.",
        "Regresa solo cuando se autorice; las brasas, los árboles debilitados y los escombros pueden seguir siendo peligrosos."
      ]
    },
    "pets": {
      "title": "Proteger a los animales",
      "points": [
        "Prepara un transportín o correa apropiados, agua, alimentos, medicamentos habituales y los datos del veterinario.",
        "Añade fotos recientes, identificación y documentos útiles al plan de emergencia.",
        "Durante una alerta, lleva a los animales a un lugar protegido sin ponerte en peligro y sigue las instrucciones oficiales."
      ]
    }
  }
};
const GUIDE_UI = {
  "fr": {
    "kicker": "Bibliothèque locale",
    "title": "Les essentiels, même sans réseau",
    "desc": "Ces fiches sont enregistrées localement. Tu peux les lire sans connexion après installation.",
    "notice": "Ce ne sont pas des alertes en temps réel ni un substitut aux consignes locales des secours. Les liens sources nécessitent Internet.",
    "search": "Rechercher un conseil sans Internet",
    "placeholder": "Ex. eau, séisme, brûlure, guerre…",
    "count": "{g} guides de préparation et {a} fiches de secours.",
    "found": "{g} guide(s) et {a} fiche(s) de secours trouvé(s).",
    "offline": "Recherche par mots dans les fiches enregistrées, sans IA ni connexion.",
    "source": "Source",
    "aid": "Fiche de premiers secours →",
    "aidLang": ""
  },
  "en": {
    "kicker": "Local library",
    "title": "The essentials, even offline",
    "desc": "These guides are saved locally. You can read them offline after installation.",
    "notice": "These are not live alerts or a substitute for local emergency instructions. Source links require Internet access.",
    "search": "Search for advice offline",
    "placeholder": "E.g. water, earthquake, wildfire…",
    "count": "{g} preparedness guides and {a} first-aid cards (French).",
    "found": "{g} guide(s) and {a} first-aid card(s) found.",
    "offline": "Search saved guides by keyword, without AI or Internet.",
    "source": "Source",
    "aid": "First-aid card · French →",
    "aidLang": "First-aid cards remain in French and follow French guidance. Contact local emergency services for immediate help."
  },
  "es": {
    "kicker": "Biblioteca local",
    "title": "Lo esencial, incluso sin conexión",
    "desc": "Estas guías se guardan localmente. Puedes leerlas sin conexión después de instalarlas.",
    "notice": "No son alertas en directo ni sustituyen las instrucciones locales de emergencia. Los enlaces de las fuentes requieren Internet.",
    "search": "Buscar consejos sin conexión",
    "placeholder": "Ej. agua, terremoto, incendio…",
    "count": "{g} guías de preparación y {a} fichas de primeros auxilios (francés).",
    "found": "{g} guía(s) y {a} ficha(s) de primeros auxilios encontrada(s).",
    "offline": "Busca por palabras en las fichas guardadas, sin IA ni Internet.",
    "source": "Fuente",
    "aid": "Ficha de primeros auxilios · francés →",
    "aidLang": "Las fichas de primeros auxilios siguen en francés y se basan en recomendaciones francesas. Contacta con los servicios locales de emergencia si necesitas ayuda inmediata."
  }
};

export function preparednessCards(lang: "fr" | "en" | "es") {
  return CARDS.map(card => lang === "fr" ? card : { ...card, ...TRANSLATIONS[lang][card.id]! });
}

const normalize = (value: string): string => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("fr-FR");

export function renderGuide(root: HTMLElement): void {
  const lang = currentLanguage();
  const t = GUIDE_UI[lang];
  const cards = preparednessCards(lang);
  const count = (template: string, g: number, a: number) => template.replace("{g}", String(g)).replace("{a}", String(a));
  mount(root, html`
    <section class="feature-intro">
      <div class="feature-kicker">${t.kicker}</div>
      <h1>${t.title}</h1>
      <p class="muted">${t.desc}</p>
      <p class="feature-note">${t.notice}</p>
    </section>
    <section class="rp-guide-search"><label for="rp-guide-filter">🔎 ${t.search}</label>
      <input type="search" id="rp-guide-filter" placeholder="${t.placeholder}" autocomplete="off" aria-controls="rp-guide-results">
      <p id="rp-guide-count" role="status">${count(t.count, cards.length, FICHES.length)}</p>
      <small>${t.offline}</small></section>
    ${t.aidLang ? html`<p class="feature-note" role="note">${t.aidLang}</p>` : ""}
    <section class="guide-grid" id="rp-guide-results">
      ${cards.map((card) => html`
        <article class="card guide-card" id="guide-${card.id}" data-guide-search="${normalize([card.title, ...card.points].join(" "))}">
          <div class="guide-icon" aria-hidden="true">${card.icon}</div>
          <h2>${card.title}</h2>
          <ul>${card.points.map((point) => html`<li>${point}</li>`)}</ul>
          <p class="hint">${t.source} : <a href="${card.url}" target="_blank" rel="noopener noreferrer">${card.source}</a></p>
        </article>`)}
      ${FICHES.map(f => html`<a lang="fr" class="rp-aid-search-card" href="#/secours/${f.id}" data-guide-search="${normalize(`${f.title} ${f.signal} ${f.audience} ${f.steps.join(" ")}`)}"><span aria-hidden="true">${f.icon}</span><strong>${f.title}</strong><small>${t.aid}</small></a>`)}
    </section>`);
  root.querySelector<HTMLInputElement>("#rp-guide-filter")?.addEventListener("input", event => {
    const query = normalize((event.target as HTMLInputElement).value).trim().split(/\s+/).filter(Boolean);
    let guides = 0;
    let secours = 0;
    root.querySelectorAll<HTMLElement>("[data-guide-search]").forEach(item => {
      const match = query.every(word => (item.dataset.guideSearch ?? "").includes(word));
      item.hidden = !match;
      if (match && item.classList.contains("guide-card")) guides++;
      else if (match) secours++;
    });
    root.querySelector<HTMLElement>("#rp-guide-count")!.textContent = count(t.found, guides, secours);
  });
}
