import { type PracticeLanguage } from "./world-practices.js";

/** International landing page only. Advanced risk simulations/first-aid cards stay French-specific. */
export const HOME_UI: Record<PracticeLanguage, Record<string,string>> = {
  fr: {
    offlineCheck:"Vérifier les guides hors connexion", offlineInitial:"Vérifie que les guides ont été enregistrés avant une catastrophe. Une vérification du cache ne remplace pas un essai réel en mode avion.", offlineChecking:"Vérification des fichiers enregistrés…", offlineReady:"Fichiers locaux vérifiés : {count}/{total}. Il faut encore tester l'ouverture en mode avion sur ce téléphone.", offlinePartial:"Cache incomplet : {count}/{total} fichiers. Reste connecté et recharge SAFYLIFE, puis recommence.", offlineUnavailable:"Impossible de vérifier le cache ici. Ouvre SAFYLIFE depuis son adresse HTTPS et réessaie.", offlineStandalone:"Les guides sont intégrés à ce fichier autonome. Leur ouverture en mode avion doit encore être testée sur ton appareil.", offlineTimeout:"Aucune réponse du stockage hors connexion. Recharge l'application puis réessaie.",
    calendarEyebrow:"Rappels volontaires", calendarTitle:"Garder les bons réflexes", calendarDetail:"Ajoute des rappels à ton calendrier : un contrôle du kit chaque mois et une lecture des conseils officiels du monde chaque semaine.", calendarSupplies:"Rappel mensuel du kit", calendarWorld:"Rappel hebdomadaire monde", calendarNote:"Fichier calendrier facultatif (.ics). Il faut l’ouvrir et confirmer son ajout dans le calendrier du téléphone. SAFYLIFE n’envoie pas de notifications automatiques.", calendarDownloaded:"Fichier calendrier téléchargé : ouvre-le et confirme son ajout. Aucune notification n’est activée tant que tu ne l’as pas importé.", calendarFailed:"Le téléchargement du rappel est indisponible sur ce navigateur.",
    weeklyEyebrow:"À découvrir cette semaine · archivé hors connexion", weeklyLink:"Découvrir d’autres pays", weeklyDisclaimer:"Fiche officielle déjà vérifiée, affichée à tour de rôle. Ce n’est ni une actualité ni une alerte en direct.",
    eyebrow:"PRÉVENTION · GRATUIT · SANS COMPTE", first:"Prêts si une", emphasis:"catastrophe arrive.",
    desc:"Prépare ta famille dès maintenant. Inondation, tempête, séisme, coupure ou conflit : retrouve les bons réflexes, même sans Internet.",
    prepare:"Préparer ma famille", sos:"SOS · Besoin d'aide ?", note:"Le SOS affiche les secours locaux et peut aider à partager ta position. Il n'envoie pas automatiquement d'alerte.",
    essential:"L'essentiel avant une urgence", how:"Comment SAFYLIFE peut t'aider", home:"Préparer mon foyer", homeSub:"Eau, alimentation, kit d'urgence, besoins de chacun", dangers:"Comprendre les risques", dangersSub:"Tempêtes, inondations, évacuation et coupures", aid:"Gestes de premiers secours", aidSub:"Les réflexes essentiels à connaître à l'avance", world:"Voyager et se préparer", worldSub:"Carte générale et numéros d'urgence par pays", loved:"Protégez aussi vos proches ❤️", lovedSub:"Tu peux leur recommander SAFYLIFE avant une catastrophe. Pas de partage automatique, pas de compte à créer.", share:"Partager SAFYLIFE", install:"Installer sur ce téléphone", lang:"Langues / Pays", reviewTitle:"Vérifier ma préparation", reviewDue:"Cela fait longtemps que tes réserves n’ont pas été vérifiées, ou aucune vérification n’est enregistrée.", reviewOk:"Dernière vérification :", reviewNote:"Rappel affiché seulement quand tu ouvres SAFYLIFE : ce n’est pas une notification en arrière-plan.", reviewDone:"J’ai vérifié aujourd’hui", reviewEdit:"Voir mon kit", advanced:"Les fiches de premiers secours et les simulations détaillées sont encore adaptées à la France. Pour l'étranger, suis les consignes officielles locales.",
  },
  en: {
    offlineCheck:"Check offline guides", offlineInitial:"Check that the guides are saved before an emergency. Checking the cache is not the same as a real airplane-mode test.", offlineChecking:"Checking saved files…", offlineReady:"Local files verified: {count}/{total}. You still need to reopen SAFYLIFE in airplane mode on this device.", offlinePartial:"Incomplete cache: {count}/{total} files. Stay connected, reload SAFYLIFE and try again.", offlineUnavailable:"Unable to verify the offline cache here. Open SAFYLIFE from its HTTPS address and retry.", offlineStandalone:"Guides are bundled in this standalone file. Test reopening it in airplane mode on your device.", offlineTimeout:"Offline storage did not respond. Reload the app and try again.",
    calendarEyebrow:"Optional reminders", calendarTitle:"Keep preparedness on your calendar", calendarDetail:"Add calendar reminders: check your kit monthly and explore official preparedness guidance weekly.", calendarSupplies:"Monthly kit reminder", calendarWorld:"Weekly global reminder", calendarNote:"Optional calendar file (.ics). Open and import it in your phone’s calendar. SAFYLIFE does not send automatic notifications.", calendarDownloaded:"Calendar file downloaded. Open it and confirm import. No notification is enabled until you import the event.", calendarFailed:"Calendar download is unavailable in this browser.",
    weeklyEyebrow:"This week’s offline preparedness idea", weeklyLink:"Explore other countries", weeklyDisclaimer:"Previously reviewed official guidance, rotated weekly. This is not live news or an emergency alert.",
    eyebrow:"PREPAREDNESS · FREE · NO ACCOUNT", first:"Be ready before", emphasis:"disaster strikes.",
    desc:"Prepare your family now. Floods, storms, earthquakes, power cuts or conflict: keep essential preparation tools even without Internet after installation.",
    prepare:"Prepare my household", sos:"SOS · Need help?", note:"SOS shows available local emergency numbers and helps you share coordinates. It DOES NOT automatically alert rescuers.",
    essential:"The essentials before an emergency", how:"How SAFYLIFE can help", home:"Prepare my household", homeSub:"Water, food, emergency kit and individual needs", dangers:"Understand risks", dangersSub:"Storms, floods, evacuations and outages · French", aid:"First-aid reference", aidSub:"Important: currently written for France", world:"Prepare for travel", worldSub:"Offline world map and country emergency numbers", loved:"Protect people you love ❤️", lovedSub:"Recommend SAFYLIFE to loved ones before a disaster. No automatic sharing and no account required.", share:"Share SAFYLIFE", install:"Install on this phone", lang:"Languages / Countries", reviewTitle:"Check my emergency supplies", reviewDue:"No review has been recorded, or your supplies may be due for another check.", reviewOk:"Last checked:", reviewNote:"Shown only when you open SAFYLIFE; this is NOT a background push notification.", reviewDone:"I checked today", reviewEdit:"View my kit (French)", advanced:"IMPORTANT: Detailed first-aid cards and simulations are still in French and based on French guidance. Follow local emergency services and official instructions wherever you are.",
  },
  es: {
    offlineCheck:"Comprobar las guías sin conexión", offlineInitial:"Comprueba que las guías estén guardadas antes de una emergencia. Revisar la caché no sustituye una prueba real en modo avión.", offlineChecking:"Comprobando archivos guardados…", offlineReady:"Archivos locales verificados: {count}/{total}. Aún debes abrir SAFYLIFE en modo avión en este teléfono.", offlinePartial:"Caché incompleta: {count}/{total} archivos. Mantén la conexión, recarga SAFYLIFE y vuelve a intentarlo.", offlineUnavailable:"No se puede comprobar la caché aquí. Abre SAFYLIFE desde su dirección HTTPS y vuelve a intentarlo.", offlineStandalone:"Las guías están incluidas en este archivo independiente. Prueba a abrirlo en modo avión en tu dispositivo.", offlineTimeout:"El almacenamiento sin conexión no respondió. Recarga la aplicación y prueba otra vez.",
    calendarEyebrow:"Recordatorios voluntarios", calendarTitle:"Mantén los buenos hábitos", calendarDetail:"Añade recordatorios al calendario: revisa el kit cada mes y las recomendaciones oficiales mundiales cada semana.", calendarSupplies:"Revisión mensual del kit", calendarWorld:"Recordatorio mundial semanal", calendarNote:"Archivo de calendario opcional (.ics). Ábrelo y confírmalo en el calendario del teléfono. SAFYLIFE no envía notificaciones automáticas.", calendarDownloaded:"Archivo descargado: ábrelo y confirma la importación. No habrá avisos hasta que lo importes.", calendarFailed:"La descarga no está disponible en este navegador.",
    weeklyEyebrow:"Idea semanal guardada sin conexión", weeklyLink:"Descubrir otros países", weeklyDisclaimer:"Recomendaciones oficiales revisadas, mostradas por turnos. No son noticias ni alertas en directo.",
    eyebrow:"PREVENCIÓN · GRATIS · SIN CUENTA", first:"Prepárate antes de", emphasis:"una catástrofe.",
    desc:"Prepara a tu familia. Inundaciones, tormentas, terremotos, cortes de luz o conflictos: guarda recursos esenciales sin conexión después de instalar la aplicación.",
    prepare:"Preparar a mi familia", sos:"SOS · ¿Necesitas ayuda?", note:"SOS muestra números de emergencia locales disponibles y ayuda a compartir coordenadas. NO avisa automáticamente a los servicios de rescate.",
    essential:"Lo esencial antes de una emergencia", how:"Cómo puede ayudarte SAFYLIFE", home:"Preparar mi hogar", homeSub:"Agua, alimentos, kit de emergencia y necesidades individuales", dangers:"Comprender los riesgos", dangersSub:"Tormentas, inundaciones, evacuaciones y cortes · en francés", aid:"Guías de primeros auxilios", aidSub:"Importante: escritas para Francia", world:"Prepararse para viajar", worldSub:"Mapa mundial sin conexión y teléfonos de emergencia", loved:"Protege a quienes quieres ❤️", lovedSub:"Recomienda SAFYLIFE antes de una catástrofe. Sin envíos automáticos ni cuentas.", share:"Compartir SAFYLIFE", install:"Instalar en este teléfono", lang:"Idiomas / Países", reviewTitle:"Revisar mis suministros", reviewDue:"No hay ninguna revisión registrada o es momento de volver a revisar tus reservas.", reviewOk:"Última revisión:", reviewNote:"Este recordatorio solo aparece al abrir SAFYLIFE; NO es una notificación en segundo plano.", reviewDone:"He revisado hoy", reviewEdit:"Ver mi kit (francés)", advanced:"IMPORTANTE: Las fichas detalladas de primeros auxilios y las simulaciones todavía están en francés y siguen recomendaciones francesas. Sigue siempre los servicios de emergencia y las instrucciones oficiales locales.",
  },
};

/** Home sections that were previously hard-coded in French. */
export const HOME_EXTRA = {
  fr: {
    shareEyebrow: "Gratuit · Prévention", missionEyebrow: "À faire ensemble", missionTitle: "Les missions de ma famille",
    missionDesc: "Des actions concrètes pour préparer ton foyer en amont.", missionStart: "Commence avec un adulte",
    missionDone: "{done} / {total} missions cochées", discover: "Découvrir →",
    realTitle: "Si un danger arrive réellement…", realDesc: "Protège-toi, contacte les secours si possible et suis les alertes et consignes officielles.",
    more: "Pour aller plus loin", reflexes: "Les bons réflexes", reflexesSub: "9 fiches simples", supplies: "Mes réserves", suppliesSub: "Pour mon foyer",
    list: "Ma liste", listSub: "Ce qu'il reste à faire", center: "Centre d'urgence", centerSub: "Numéros, position, SMS manuel",
    world: "Monde", worldSub: "Pays, carte et secours",
    trainEyebrow: "Entraînement facultatif · hors connexion", trainTitle: "Apprendre en s'exerçant",
    trainDesc: "Jeux, défis et simulations : pour retenir les bons réflexes sans pression.", trainLink: "Essayer →",
    testTitle: "Tester SAFYLIFE en 5 minutes", testSub: "3 activités faciles + ton avis à la fin",
    demoNote: "Pour l'instant, les simulations utilisent un foyer imaginaire.", demoLink: "Renseigner ma maison", demoTail: "avec un adulte.",
    smallPrint: "Prototype de prévention expérimental : pas d'alerte automatique aux secours ni de garantie de sauvetage. Les consignes officielles restent prioritaires.",
  },
  en: {
    shareEyebrow: "Free · Preparedness", missionEyebrow: "Do it together", missionTitle: "My family's missions (French)",
    missionDesc: "Concrete actions to prepare your household in advance.", missionStart: "Start with an adult",
    missionDone: "{done} / {total} missions checked", discover: "Open →",
    realTitle: "If danger really happens…", realDesc: "Protect yourself, contact emergency services if you can, and follow official alerts and instructions.",
    more: "Go further", reflexes: "Key safety habits", reflexesSub: "9 short guides", supplies: "My supplies", suppliesSub: "For my household (French)",
    list: "My list", listSub: "What is left to do (French)", center: "Emergency centre", centerSub: "Numbers, location, manual SMS",
    world: "World", worldSub: "Countries, map and emergency numbers",
    trainEyebrow: "Optional practice · offline", trainTitle: "Learn by practising",
    trainDesc: "Games, challenges and simulations to remember safety habits without pressure (French).", trainLink: "Try →",
    testTitle: "Test SAFYLIFE in 5 minutes", testSub: "3 easy activities + your feedback (French)",
    demoNote: "For now, simulations use an imaginary household.", demoLink: "Describe my home", demoTail: "with an adult.",
    smallPrint: "Experimental preparedness prototype: no automatic alert to emergency services and no rescue guarantee. Official instructions always come first.",
  },
  es: {
    shareEyebrow: "Gratis · Prevención", missionEyebrow: "Para hacer juntos", missionTitle: "Las misiones de mi familia (francés)",
    missionDesc: "Acciones concretas para preparar tu hogar con antelación.", missionStart: "Empieza con un adulto",
    missionDone: "{done} / {total} misiones marcadas", discover: "Abrir →",
    realTitle: "Si de verdad llega un peligro…", realDesc: "Protégete, contacta con emergencias si puedes y sigue las alertas e instrucciones oficiales.",
    more: "Para ir más lejos", reflexes: "Buenos reflejos", reflexesSub: "9 fichas sencillas", supplies: "Mis reservas", suppliesSub: "Para mi hogar (francés)",
    list: "Mi lista", listSub: "Lo que queda por hacer (francés)", center: "Centro de emergencia", centerSub: "Números, ubicación, SMS manual",
    world: "Mundo", worldSub: "Países, mapa y teléfonos de emergencia",
    trainEyebrow: "Práctica opcional · sin conexión", trainTitle: "Aprender practicando",
    trainDesc: "Juegos, retos y simulaciones para recordar los buenos reflejos sin presión (francés).", trainLink: "Probar →",
    testTitle: "Probar SAFYLIFE en 5 minutos", testSub: "3 actividades fáciles + tu opinión (francés)",
    demoNote: "Por ahora, las simulaciones usan un hogar imaginario.", demoLink: "Describir mi casa", demoTail: "con un adulto.",
    smallPrint: "Prototipo experimental de prevención: no hay alerta automática a emergencias ni garantía de rescate. Las instrucciones oficiales siempre tienen prioridad.",
  },
} satisfies Record<PracticeLanguage, Record<string, string>>;

/** Persistent interface (header, tab bar, skip link, first-aid button, offline badge). */
export const CHROME_UI = {
  fr: {
    skip: "Aller au contenu", brand: "SAFYLIFE prototype – Accueil", navLabel: "Rubriques", home: "Accueil", sos: "SOS", prepare: "Se préparer",
    prepareShort: "Préparer", dangers: "Dangers", world: "Monde", drill: "Entraînement", aid: "Secours", aidAria: "Secours – ouvrir les gestes de premiers secours",
    offline: "Hors connexion", badgeCheck: "Hors connexion à vérifier sur cet appareil", badgeBundled: "Guides intégrés au fichier",
    badgeInstalling: "Installation des guides hors connexion…", badgeFailed: "Mode hors connexion non installé", badgeUnverified: "Mode hors connexion non vérifié",
    badgeReadyOnline: "Guides enregistrés pour le hors connexion", badgeReadyOffline: "Hors connexion · guides enregistrés", badgePartial: "Téléchargement hors connexion incomplet",
    frOnly: "", frOnlySos: "", testReturn: "🎯 Retour au test",
  },
  en: {
    skip: "Skip to content", brand: "SAFYLIFE prototype – Home", navLabel: "Sections", home: "Home", sos: "SOS", prepare: "Prepare",
    prepareShort: "Prepare", dangers: "Hazards", world: "World", drill: "Practice", aid: "First aid", aidAria: "First aid – open first-aid guides",
    offline: "Offline", badgeCheck: "Offline mode to be checked on this device", badgeBundled: "Guides bundled in this file",
    badgeInstalling: "Saving guides for offline use…", badgeFailed: "Offline mode not installed", badgeUnverified: "Offline mode not verified",
    badgeReadyOnline: "Guides saved for offline use", badgeReadyOffline: "Offline · guides saved", badgePartial: "Offline download incomplete",
    frOnly: "This section is currently available in French only and is based on French guidance. In an emergency, call your local emergency number.",
    frOnlySos: "Open SOS and local emergency numbers", testReturn: "🎯 Back to the test",
  },
  es: {
    skip: "Ir al contenido", brand: "SAFYLIFE prototipo – Inicio", navLabel: "Secciones", home: "Inicio", sos: "SOS", prepare: "Prepararse",
    prepareShort: "Preparar", dangers: "Riesgos", world: "Mundo", drill: "Práctica", aid: "Auxilios", aidAria: "Auxilios – abrir las guías de primeros auxilios",
    offline: "Sin conexión", badgeCheck: "Modo sin conexión por comprobar en este dispositivo", badgeBundled: "Guías incluidas en el archivo",
    badgeInstalling: "Guardando guías para usar sin conexión…", badgeFailed: "Modo sin conexión no instalado", badgeUnverified: "Modo sin conexión no comprobado",
    badgeReadyOnline: "Guías guardadas para usar sin conexión", badgeReadyOffline: "Sin conexión · guías guardadas", badgePartial: "Descarga sin conexión incompleta",
    frOnly: "Esta sección por ahora solo está disponible en francés y se basa en recomendaciones francesas. En una emergencia, llama al número de emergencias local.",
    frOnlySos: "Abrir SOS y números de emergencia locales", testReturn: "🎯 Volver a la prueba",
  },
} satisfies Record<PracticeLanguage, Record<string, string>>;

/** Routes whose content is still French-only. */
export const FRENCH_ONLY_ROUTES = new Set(["secours", "setup", "checklist", "drill", "game", "simulations", "scenario", "missions", "aventures", "aventure", "data", "print", "essai"]);
