/** Review queue for every territory; never inserts numbers or sends calls. */
import { countryOptions, emergencyFor, additionalEmergencyNumbersFor } from '../public/js/app/fr-world.js';
import { writeFileSync } from 'node:fs';
const rows=countryOptions('fr').map(({code,title})=>{
 const n=emergencyFor(code);const extras=additionalEmergencyNumbersFor(code);
 return {code,territory:title,status:n?'documented-review-periodically':'verification-required',primary:n??null,additional:extras,review:'Confirm service, geographic and network coverage, official source, date and discrepancies before release.'};
});
const out={schema:1,generated:new Date().toISOString(),count:rows.length,documented:rows.filter(r=>r.primary).length,entries:rows};
writeFileSync(process.argv[2]||'emergency-review.json',JSON.stringify(out,null,2)+'\n');
console.log(`${out.documented}/${out.count} documented; ${out.count-out.documented} require verification`);
