"""Browser check of localized preparedness cards, search and language scope."""
from pathlib import Path
from playwright.sync_api import sync_playwright
HTML=(Path(__file__).resolve().parents[2]/'SAFYLIFE_autonome.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for lang,word,expected in [('fr','séisme','Séisme'),('en','earthquake','Earthquake'),('es','terremoto','Terremoto')]:
  page=b.new_page(viewport={'width':360,'height':800});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML,wait_until='load')
  def route(r):
   page.evaluate('(r)=>{location.hash=r;window.dispatchEvent(new Event("hashchange"))}',r)
   page.wait_for_timeout(150)
  route('#/monde');page.locator('#rp-world-language').select_option(lang);route('#/guide')
  assert page.locator('.guide-card').count()==9
  assert not page.locator('#main .rp-fr-only').count()
  assert expected in page.locator('#guide-quake h2').inner_text()
  page.locator('#rp-guide-filter').fill(word)
  assert page.locator('#guide-quake').is_visible()
  assert not page.locator('#guide-pets').is_visible()
  route('#/secours');assert page.locator('.rp-fr-only').count()==(lang!='fr')
  route('#/monde');page.locator('#rp-world-country').select_option('AQ')
  assert page.locator('.rp-world-emergency a[href^="tel:"]').count()==0
  assert page.locator('.rp-world-emergency a[href="https://www.gov.uk/foreign-travel-advice"]').count()==1
  assert not errors, errors
  page.close();print(lang,'PASS',flush=True)
 b.close()
