import assert from "node:assert/strict";
import { test } from "node:test";
import { buildDrill } from "../src/engine/drills.js";
import { emptyPlan, samplePlan } from "../src/engine/sample.js";

test("a drill uses the live household result", () => {
  const plan = samplePlan();
  const drill = buildDrill(plan, "power");
  assert.equal(drill.scenarioId, "power");
  assert.equal(drill.correct, "first-day");
  assert.ok(drill.firstFailureHours !== null);
  assert.ok(drill.firstFailureHours! < 24);
});

test("a drill is deterministic for the same plan", () => {
  const plan = samplePlan();
  assert.deepEqual(buildDrill(plan, "storm"), buildDrill(plan, "storm"));
});

test("an empty inventory is not protected when shops and water are unavailable", () => {
  const plan = emptyPlan();
  plan.household.home.waterSupply = "bottled-only";
  const drill = buildDrill(plan, "storm");
  assert.equal(drill.correct, "first-day");
});
