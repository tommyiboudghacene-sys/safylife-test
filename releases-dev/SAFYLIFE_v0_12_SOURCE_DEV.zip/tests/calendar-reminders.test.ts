import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calendarReminder, escapeCalendarText, foldCalendarLine } from '../src/app/calendar-reminders.js';

test('text calendar escaping protects commas, semicolons and line breaks', () => {
  assert.equal(escapeCalendarText('a,b;c\\d\ne'), 'a\\,b\\;c\\\\d\\ne');
});
test('every folded calendar line has at most 75 UTF-8 octets', () => {
  const long = foldCalendarLine('RÉSUMÉ:'+'à'.repeat(90));
  for (const line of long.split('\r\n')) assert.ok(new TextEncoder().encode(line).length <= 75, line);
});
test('world reminder is weekly and never auto-sends an alert', () => {
  const ics = calendarReminder('world','en', new Date('2026-11-23T12:00:00Z'));
  assert.match(ics, /BEGIN:VCALENDAR\r\n/);
  assert.match(ics, /RRULE:FREQ=WEEKLY/);
  assert.match(ics, /VALARM/);
  assert.match(ics, /NOT provide a real-time warning/i);
  assert.ok(!/ATTENDEE|ORGANIZER|mailto:/.test(ics));
});
test('monthly reminder schedules end-of-month without overstepping February', () => {
  const ics = calendarReminder('supplies','fr', new Date(2027,0,31,13,0,0));
  assert.match(ics, /DTSTART:20270228T090000/);
  assert.match(ics, /RRULE:FREQ=MONTHLY/);
  assert.match(ics, /SUMMARY:SAFYLIFE/);
});
test('calendar data has safe CRLF endings and all supported languages', () => {
  for (const lang of ['fr','en','es'] as const) for (const kind of ['supplies','world'] as const) {
    const i = calendarReminder(kind, lang, new Date('2026-11-23T11:00:00Z'));
    assert.ok(i.endsWith('END:VCALENDAR\r\n'));
    assert.ok(!/(?<!\r)\n/.test(i));
  }
});
