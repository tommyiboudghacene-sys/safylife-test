import { test } from 'node:test';
import assert from 'node:assert/strict';
import { morseSosTones, DISTRESS_UNIT_MS, DISTRESS_MAX_MS } from '../src/app/distress-signal.js';

test('Morse SOS uses three short, three long, three short tones', () => {
  const tones = morseSosTones();
  assert.equal(tones.length, 9);
  assert.deepEqual(tones.map(t=>t.duration / DISTRESS_UNIT_MS), [1,1,1,3,3,3,1,1,1]);
  for (let i=1; i<tones.length; i++) assert.ok(tones[i]!.at >= tones[i-1]!.at+tones[i-1]!.duration);
  assert.ok(tones.at(-1)!.at+tones.at(-1)!.duration < DISTRESS_MAX_MS);
});
test('Morse SOS rejects pathological pulse rates',()=> {
  for (const unit of [0,NaN,Infinity,10,2000]) assert.throws(()=>morseSosTones(unit));
});
