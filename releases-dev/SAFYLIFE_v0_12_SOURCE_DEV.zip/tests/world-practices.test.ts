import { test } from "node:test";
import assert from "node:assert/strict";
import { WORLD_PRACTICES, WORLD_PRACTICES_REVIEWED } from "../src/app/world-practices.js";

test("International practices have dated multilingual offline content and official source links", () => {
  assert.match(WORLD_PRACTICES_REVIEWED, /^\d{4}-\d{2}-\d{2}$/);
  assert.ok(WORLD_PRACTICES.length >= 8);
  assert.equal(new Set(WORLD_PRACTICES.map(p=>p.region)).size, WORLD_PRACTICES.length);
  for (const practice of WORLD_PRACTICES) {
    assert.match(practice.url, /^https:\/\//);
    for (const lang of ["fr", "en", "es"] as const) {
      assert.ok(practice.title[lang].length > 15);
      assert.ok(practice.detail[lang].length > 70);
    }
  }
});
