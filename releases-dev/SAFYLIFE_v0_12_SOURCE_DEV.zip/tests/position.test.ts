import assert from "node:assert/strict";
import { test } from "node:test";
import { fixQuality, fixWarning, positionText, validFix, type Fix } from "../src/app/position-core.js";

const NOW = Date.UTC(2026, 10, 23, 12);
const fix: Fix = { latitude: 43.6082, longitude: 1.4422, accuracy: 25, at: NOW - 60000 };

test("SOS rejects coordinates outside geographic ranges and invalid accuracy", () => {
  assert.equal(validFix(fix, NOW), true);
  assert.equal(validFix({ ...fix, latitude: 95 }, NOW), false);
  assert.equal(validFix({ ...fix, longitude: -181 }, NOW), false);
  assert.equal(validFix({ ...fix, accuracy: -1 }, NOW), false);
  assert.equal(validFix({ ...fix, latitude: Number.NaN }, NOW), false);
  assert.equal(validFix({ ...fix, at: NOW + 120000 }, NOW), false);
});

test("SOS marks older or imprecise coordinates as questionable", () => {
  assert.equal(fixQuality(fix, NOW), "recent");
  assert.equal(fixQuality({ ...fix, at: NOW - 6 * 60000 }, NOW), "review");
  assert.equal(fixQuality({ ...fix, accuracy: 2000 }, NOW), "review");
  assert.equal(fixQuality({ ...fix, at: NOW - 31 * 60000 }, NOW), "stale");
  assert.match(fixWarning({ ...fix, at: NOW - 31 * 60000 }, NOW), /ANCIENNE POSITION/);
});

test("SOS sharing identifies stale position, accuracy and no automated emergency alert", () => {
  const message = positionText({ ...fix, at: NOW - 40 * 60000 }, NOW);
  assert.match(message, /43\.60820, 1\.44220/);
  assert.match(message, /± 25 m/);
  assert.match(message, /ANCIENNE POSITION/);
  assert.match(message, /aucun SOS automatique/);
});
