import assert from "node:assert/strict";
import { test } from "node:test";
import { helpRequestText, normalizeTrustedNumber, smsDraftUrl } from "../src/app/sos-message-core.js";

test("SMS draft requires a human-confirmed trusted contact", () => {
  assert.equal(normalizeTrustedNumber("+33 6 12 34 56 78"), "+33612345678");
  assert.equal(normalizeTrustedNumber("112"), null);
  assert.equal(normalizeTrustedNumber("javascript:alert(1)"), null);
  assert.equal(normalizeTrustedNumber("+33;tel:112"), null);
  assert.equal(smsDraftUrl("112", "Urgent"), null);
  assert.ok(smsDraftUrl("+33 6 12 34 56 78", "Aide\nPosition" )?.includes("body=Aide%0APosition"));
  assert.ok(smsDraftUrl("+33612345678", "Aide", true)?.includes("&body="));
});

test("No position and stale position are explicitly qualified", () => {
  const noFix = helpRequestText(null);
  assert.match(noFix, /n'est pas disponible/);
  assert.match(noFix, /prévenir les secours/);
  const stale = helpRequestText({ latitude: 48.0, longitude: 2.1, accuracy: 1600, at: Date.now() - 40 * 60_000 });
  assert.match(stale, /ANCIENNE POSITION/);
  assert.match(stale, /48\.00000/);
  assert.match(stale, /envoi uniquement après confirmation/);
});

test("International rescue drafts use the selected language and warn about stale coordinates", () => {
  const en = helpRequestText(null, Date.now(), "en");
  const es = helpRequestText(null, Date.now(), "es");
  assert.match(en, /I NEED HELP/);
  assert.match(en, /only be sent if I confirm/);
  assert.match(es, /NECESITO AYUDA/);
  const stale = helpRequestText({ latitude: 43, longitude: 1.4, accuracy: 100, at: Date.now() - 45 * 60_000 }, Date.now(), "es");
  assert.match(stale, /POSICIÓN ANTIGUA/);
});
