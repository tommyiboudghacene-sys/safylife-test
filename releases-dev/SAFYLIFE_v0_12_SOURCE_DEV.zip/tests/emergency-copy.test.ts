import assert from 'node:assert/strict';
import { test } from 'node:test';
import { copyEmergencyText } from '../src/app/emergency-copy.js';

test('the secure clipboard is preferred without leaking emergency contents', async () => {
  let written = '';
  const nav = { clipboard: { writeText: async (s: string) => {written = s;} } };
  assert.equal(await copyEmergencyText('HELP 48.3, 2.1', nav as never, null), true);
  assert.equal(written, 'HELP 48.3, 2.1');
});
test('offline copy fails safely if there is no clipboard or DOM', async () => {
  assert.equal(await copyEmergencyText('HELP', null, null), false);
  assert.equal(await copyEmergencyText(' ', null, null), false);
});
test('blocked Clipboard API falls back to legacy selection and cleans up', async () => {
  let removed = false, selected = false, restored = false;
  const element = {value:'',style:{},setAttribute(){},focus(){},select(){ selected=true; },remove(){removed=true;}};
  const doc = {body:{appendChild(x:unknown){assert.equal(x,element);}},activeElement:{focus(){ restored=true; }},createElement(name:string){assert.equal(name,'textarea');return element;},execCommand(cmd:string){assert.equal(cmd,'copy');return true;}};
  const nav = {clipboard:{writeText:async()=>{throw new Error('denied');}}};
  assert.equal(await copyEmergencyText('COPY ME',nav as never,doc as never),true);
  assert.equal(element.value,'COPY ME');
  assert.equal(selected,true);
  assert.equal(removed,true);
  assert.equal(restored,true);
});
test('legacy copy errors never leave emergency text in a hidden element', async () => {
  let removed = false;
  const element = {value:'',style:{},setAttribute(){},focus(){},select(){},remove(){removed=true;}};
  const doc = {body:{appendChild(){}},activeElement:null,createElement(){return element;},execCommand(){throw new Error('disabled');}};
  assert.equal(await copyEmergencyText('SOS',null,doc as never),false);
  assert.equal(removed,true);
});
