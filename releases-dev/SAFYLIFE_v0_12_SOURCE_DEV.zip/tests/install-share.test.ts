import { test } from "node:test";
import assert from "node:assert/strict";
import { isEligibleInstallOrigin } from "../src/app/install-share.js";

test("install prompt is available on secure HTTPS hosts", () => {
  assert.equal(isEligibleInstallOrigin("https:", "safylife.example", false), true);
});
test("non-HTTPS remote hosting cannot claim installability", () => {
  assert.equal(isEligibleInstallOrigin("http:", "safylife.example", false), false);
});
test("local development hosts are eligible, but standalone files are not", () => {
  assert.equal(isEligibleInstallOrigin("http:", "localhost", false), true);
  assert.equal(isEligibleInstallOrigin("http:", "127.0.0.1", false), true);
  assert.equal(isEligibleInstallOrigin("file:", "", false), false);
  assert.equal(isEligibleInstallOrigin("https:", "safylife.example", true), false);
});
