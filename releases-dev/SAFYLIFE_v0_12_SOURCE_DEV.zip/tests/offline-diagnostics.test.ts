import { test } from "node:test";
import assert from "node:assert/strict";
import { parseOfflineCacheInventory } from "../src/app/offline-diagnostics.js";

test("offline inventory accepts a complete and consistent worker response", () => {
  assert.deepEqual(parseOfflineCacheInventory({ type:"SAFYLIFE_OFFLINE_STATUS", ready:true, count:55, total:55 }), {ready:true,count:55,total:55});
});
test("offline inventory never treats an incomplete cache as ready", () => {
  assert.deepEqual(parseOfflineCacheInventory({ type:"SAFYLIFE_OFFLINE_STATUS", ready:true, count:50, total:55 }), {ready:false,count:50,total:55});
});
test("offline inventory rejects malformed, foreign and fabricated counts", () => {
  for (const item of [null,{}, {type:"OTHER", ready:true,count:55,total:55}, {type:"SAFYLIFE_OFFLINE_STATUS",ready:true,count:-1,total:55},
    {type:"SAFYLIFE_OFFLINE_STATUS",ready:true,count:56,total:55}, {type:"SAFYLIFE_OFFLINE_STATUS",ready:true,count:55.5,total:55},
    {type:"SAFYLIFE_OFFLINE_STATUS",ready:true,count:0,total:0}, {type:"SAFYLIFE_OFFLINE_STATUS",ready:true,count:2000,total:2000}]) {
    assert.equal(parseOfflineCacheInventory(item),null);
  }
});
