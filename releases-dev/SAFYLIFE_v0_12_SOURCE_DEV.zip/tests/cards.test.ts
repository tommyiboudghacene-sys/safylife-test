import assert from "node:assert/strict";
import { test } from "node:test";
import { botAction, createMatch, deckOfCards, drawAndPass, ELEMENTS, isPlayable, playCard, topCard } from "../src/app/card-core.js";

test("offline card deck contains 100 distinct cards and 4 original elements", () => {
  const cards = deckOfCards();
  assert.equal(cards.length, 100);
  assert.equal(new Set(cards.map(card => card.id)).size, cards.length);
  assert.equal(ELEMENTS.length, 4);
  assert.equal(cards.filter(card => card.kind === "wild").length, 8);
});

test("dealing gives nine cards each and a valid opening card", () => {
  const state = createMatch(() => .4);
  assert.equal(state.hands.human.length, 9);
  assert.equal(state.hands.bot.length, 9);
  assert.equal(state.deck.length, 81);
  assert.equal(topCard(state).kind, "number");
  assert.equal(state.turn, "human");
});

test("illegal plays and invalid joker color cannot alter game state", () => {
  const state = createMatch(() => .6);
  const initial = JSON.stringify(state);
  assert.equal(playCard(state, "bot", state.hands.bot[0]!.id), false);
  assert.equal(playCard(state, "human", -1), false);
  const joker = state.hands.human.find(card => card.kind === "wild");
  if (joker) {
    assert.equal(playCard(state, "human", joker.id), false);
    assert.equal(playCard(state, "human", joker.id, "unknown" as never), false);
  }
  assert.equal(JSON.stringify(state), initial);
});

test("a plus-two or pause plays again; a regular number changes player", () => {
  const state = createMatch(() => .21);
  const plus2 = deckOfCards().find(card => card.element === state.activeElement && card.kind === "plus2")!;
  const displaced = state.hands.human.pop()!;
  state.deck.push(displaced);
  state.hands.human.push(plus2);
  assert.equal(playCard(state, "human", plus2.id), true);
  assert.equal(state.turn, "human");
  assert.equal(state.hands.bot.length, 11);
  const pause = deckOfCards().find(card => card.element === state.activeElement && card.kind === "pause")!;
  state.hands.human.push(pause);
  assert.equal(playCard(state, "human", pause.id), true);
  assert.equal(state.turn, "human");
  const sameNumber = deckOfCards().find(card => card.element === state.activeElement && card.kind === "number")!;
  state.hands.human.push(sameNumber);
  assert.ok(isPlayable(state, sameNumber));
  assert.equal(playCard(state, "human", sameNumber.id), true);
  assert.equal(state.turn, "bot");
});

test("50 fully local bot-vs-greedy games terminate without losing cards", () => {
  for (let seed = 1; seed <= 50; seed++) {
    let value = seed;
    const random = () => { value = (value * 16807) % 2147483647; return value / 2147483647; };
    const state = createMatch(random);
    while (!state.winner) {
      if (state.turn === "bot") assert.ok(botAction(state, random));
      else {
        const playable = state.hands.human.find(card => isPlayable(state, card));
        if (playable) assert.ok(playCard(state, "human", playable.id, playable.kind === "wild" ? "water" : undefined, random));
        else assert.ok(drawAndPass(state, "human", random));
      }
      const ids = [...state.deck, ...state.discard, ...state.hands.human, ...state.hands.bot].map(card => card.id);
      assert.equal(ids.length, 100);
      assert.equal(new Set(ids).size, 100);
      assert.ok(state.turns <= 600);
    }
    assert.ok(["human", "bot", "draw"].includes(state.winner));
  }
});
