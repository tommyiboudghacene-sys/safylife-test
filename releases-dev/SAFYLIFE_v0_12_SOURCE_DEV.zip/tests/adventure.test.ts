import assert from "node:assert/strict";
import { test } from "node:test";
import { samplePlan, emptyPlan } from "../src/engine/index.js";
import { ADVENTURES, adventureSignals, chooseAdventure, startAdventure, waterPerDay } from "../src/app/fr-adventure-engine.js";

test("all three adventures have four safe educational checkpoints and three options", () => {
  for (const game of Object.values(ADVENTURES)) {
    assert.equal(game.steps.length, 4);
    assert.deepEqual(game.steps.map(s => s.hour), [0, 12, 36, 60]);
    for (const step of game.steps) {
      assert.equal(step.choices.length, 3);
      assert.ok(step.choices.every(c => c.title && c.consequence && c.points >= 0 && c.points <= 25));
    }
  }
});

test("the 72-hour adventure consumes real entered family supplies across all four choices", () => {
  const plan = samplePlan();
  plan.inventory.waterLiters = 80;
  plan.inventory.foodPersonDays = 9;
  let state = startAdventure(plan, "blackout", false);
  assert.equal(state.people, 2);
  assert.equal(state.water, 80);
  for (let index = 0; index < 4; index++) state = chooseAdventure(state, 0);
  assert.equal(state.finished, true);
  assert.equal(state.hour, 72);
  assert.equal(state.score, 100);
  assert.ok(Math.abs(state.water - (80 - waterPerDay(2) * 3)) < 0.00001);
  assert.equal(state.food, 3);
  assert.deepEqual(state.decisions, [0, 0, 0, 0]);
  assert.equal(chooseAdventure(state, 1), state, "can't replay a completed adventure without restarting");
});

test("unsafe resource usage is reflected and missing resources generate warnings", () => {
  const plan = emptyPlan();
  const first = startAdventure(plan, "conflict", true);
  const second = chooseAdventure(first, 1);
  assert.equal(second.score, 0);
  assert.equal(second.water, 0);
  assert.ok(adventureSignals(second).some(s => s.includes("eau potable épuisée")));
  assert.equal(chooseAdventure(first, -1), first);
  assert.equal(chooseAdventure(first, 3), first);
  assert.equal(chooseAdventure(first, 0.5), first);
});
