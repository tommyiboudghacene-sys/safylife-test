import assert from "node:assert/strict";
import { test } from "node:test";
import { requestGpsFix } from "../src/app/sos-gps.js";

const now = Date.now();
const position = { coords: { latitude: 48.8566, longitude: 2.3522, accuracy: 15 }, timestamp: now } as GeolocationPosition;
function fakeGeo(callback: (success: PositionCallback, error: PositionErrorCallback, options?: PositionOptions) => void): Pick<Geolocation, "getCurrentPosition"> {
  return { getCurrentPosition: callback };
}

test("GPS gracefully handles unavailable and throwing geolocation implementations", async () => {
  assert.deepEqual(await requestGpsFix(null), { ok: false, reason: "unsupported" });
  assert.deepEqual(await requestGpsFix(fakeGeo(() => { throw new Error("Not available"); })), { ok: false, reason: "unavailable" });
});

test("GPS validates coordinates and requests a fresh, high-accuracy fix", async () => {
  const good = await requestGpsFix(fakeGeo((success, _error, options) => {
    assert.equal(options?.enableHighAccuracy, true);
    assert.equal(options?.timeout, 15000);
    assert.equal(options?.maximumAge, 0);
    success(position);
  }));
  assert.equal(good.ok, true);
  if (good.ok) assert.equal(good.fix.latitude, 48.8566);
  const bad = await requestGpsFix(fakeGeo(success => success({ ...position, coords: { ...position.coords, latitude: 200 } } as GeolocationPosition)));
  assert.deepEqual(bad, { ok: false, reason: "unavailable" });
});

test("GPS distinguishes denied, timeout and generic device failure", async () => {
  for (const [code, reason] of [[1, "denied"], [2, "unavailable"], [3, "timeout"]] as const) {
    const result = await requestGpsFix(fakeGeo((_success, error) => error({ code } as GeolocationPositionError)));
    assert.deepEqual(result, { ok: false, reason });
  }
});
