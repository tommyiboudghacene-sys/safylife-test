import assert from "node:assert/strict";
import { test } from "node:test";
import { createMemoryRound, flipMemoryTile, hideMismatched, type MemoryLevel } from "../src/app/memory-core.js";

test("memory provides three complete offline difficulty levels", () => {
  for (const level of [6, 8, 12] as MemoryLevel[]) {
    const round = createMemoryRound(level, () => .7);
    assert.equal(round.tiles.length, level * 2);
    assert.equal(new Set(round.tiles.map(tile => tile.id)).size, level * 2);
    assert.equal(new Set(round.tiles.map(tile => tile.pair)).size, level);
    for (const pair of new Set(round.tiles.map(tile => tile.pair))) {
      assert.equal(round.tiles.filter(tile => tile.pair === pair).length, 2);
    }
  }
});

test("memory keeps mismatches temporarily visible, then hides them", () => {
  const round = createMemoryRound(6, () => .2);
  const first = round.tiles[0]!;
  const second = round.tiles.find(tile => tile.pair !== first.pair)!;
  assert.equal(flipMemoryTile(round, first.id), "first");
  assert.equal(flipMemoryTile(round, first.id), "ignored");
  assert.equal(flipMemoryTile(round, second.id), "miss");
  assert.equal(round.attempts, 1);
  assert.equal(round.open.length, 2);
  assert.equal(flipMemoryTile(round, 1000), "ignored");
  assert.equal(flipMemoryTile(round, 3), "ignored");
  hideMismatched(round);
  assert.equal(round.open.length, 0);
});

test("memory can complete twelve pairs and rejects further moves", () => {
  const round = createMemoryRound(12, () => .5);
  const pairs = new Set(round.tiles.map(tile => tile.pair));
  for (const pair of pairs) {
    const [a, b] = round.tiles.filter(tile => tile.pair === pair);
    assert.equal(flipMemoryTile(round, a!.id), "first");
    const answer = flipMemoryTile(round, b!.id);
    assert.ok(answer === "match" || answer === "finished");
  }
  assert.equal(round.finished, true);
  assert.equal(round.attempts, 12);
  assert.equal(round.matched.length, 24);
  assert.equal(flipMemoryTile(round, 0), "ignored");
});
