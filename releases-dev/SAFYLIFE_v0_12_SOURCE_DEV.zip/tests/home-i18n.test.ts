import { test } from "node:test";
import assert from "node:assert/strict";
import { HOME_UI } from "../src/app/home-i18n.js";
test("Global landing page has clear safety limits in each language", () => {
  for (const lang of ["fr", "en", "es"] as const) {
    const t = HOME_UI[lang];
    for (const key of ["eyebrow", "first", "emphasis", "desc", "sos", "note", "advanced"])
      assert.ok((t[key] ?? "").length > 8, `Missing ${lang}.${key}`);
  }
  assert.match(HOME_UI.en.note!, /DOES NOT automatically/);
  assert.match(HOME_UI.es.note!, /NO avisa automáticamente/);
});
