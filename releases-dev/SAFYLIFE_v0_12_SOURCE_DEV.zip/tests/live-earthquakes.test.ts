import assert from "node:assert/strict";
import { test } from "node:test";
import { parseEarthquakeFeed, USGS_FEED } from "../src/app/live-earthquakes.js";
const now = Date.UTC(2026,10,23,12);
const event = (place: string,mag:number,time:number,url="https://earthquake.usgs.gov/earthquakes/eventpage/us6000test") => ({properties:{type:"earthquake",place,mag,time,url}});
test("reads selected worldwide earthquake observations without inventing warnings",()=>{
  const items=parseEarthquakeFeed({features:[event("A",5.1,now-1000),event("B",4.9,now-500)]},now);
  assert.equal(items.length,2); assert.equal(items[0]?.place,"B"); assert.equal(items[0]?.magnitude,4.9);
  assert.match(USGS_FEED,/4\.5_week\.geojson$/);
});
test("rejects old, wrong-category, unsafe URLs and malformed observations",()=>{
  const hostile=event("<img src=x>",5.2,now-500,"https://evil.example/earthquakes/eventpage/id");
  const sneaky=event("X",5.4,now-500,"https://earthquake.usgs.gov.evil.example/earthquakes/eventpage/id");
  const junk=[event("Old",5,now-12*86400_000),event("Tiny",2,now),event("Future",6,now+800_000),hostile,sneaky,{properties:{...event("Bad",5,now).properties,type:"weather"}}];
  assert.deepEqual(parseEarthquakeFeed({features:junk},now),[]);
  assert.deepEqual(parseEarthquakeFeed({features:"wrong"},now),[]);
  assert.deepEqual(parseEarthquakeFeed(null,now),[]);
});
test("caps quantity and preserves descriptions as untrusted plain text",()=>{
  const items=Array.from({length:40},(_,i)=>event(`<b>Location ${i}</b>`,5.5,now-i*1000));
  const parsed=parseEarthquakeFeed({features:items},now);
  assert.equal(parsed.length,8); assert.equal(parsed[0]?.place,"<b>Location 0</b>");
});
