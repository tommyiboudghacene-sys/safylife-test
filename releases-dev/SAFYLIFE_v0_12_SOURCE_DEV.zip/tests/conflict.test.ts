import { test } from "node:test";
import assert from "node:assert/strict";
import { SCENARIOS, getScenario } from "../src/engine/scenarios.js";
import { runScenario } from "../src/engine/index.js";
import { samplePlan } from "../src/engine/sample.js";

test("all eight scenarios have distinct identifiers and valid durations", () => {
  assert.equal(SCENARIOS.length, 8);
  assert.equal(new Set(SCENARIOS.map(s => s.id)).size, 8);
  assert.ok(SCENARIOS.every(s => s.durationHours >= 24));
});

test("conflict disruption only models service availability", () => {
  const scenario = getScenario("conflict-services");
  assert.ok(scenario.hazards.includes("grid-power"));
  assert.ok(scenario.hazards.includes("tap-water"));
  assert.ok(scenario.hazards.includes("shops-closed"));
  assert.equal(scenario.shelter, "home");
  const report = runScenario(samplePlan(), "conflict-services");
  assert.ok(report.result.unmetNeeds.length > 0);
  assert.equal(report.result.durationHours, 120);
});

test("conflict evacuation does not falsely assume all roads are closed", () => {
  const scenario = getScenario("conflict-evac");
  assert.equal(scenario.shelter, "evacuate");
  assert.equal(scenario.hazards.includes("roads"), false);
  const report = runScenario(samplePlan(), "conflict-evac");
  assert.ok(report.tasks.some(task => task.id === "evacuation:go-bag") || report.tasks.some(task => task.id === "conflict-evac:go-bag"));
});
