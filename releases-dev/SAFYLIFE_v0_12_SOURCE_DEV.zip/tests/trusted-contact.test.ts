import assert from "node:assert/strict";
import { test } from "node:test";
import { TRUSTED_CONTACT_KEY, loadTrustedContact, saveTrustedContact, deleteTrustedContact } from "../src/app/trusted-contact.js";
test("trusted number can only be saved on explicit action",()=>{
  const values=new Map<string,string>(); const storage={getItem:(x:string)=>values.get(x)??null,setItem:(x:string,v:string)=>{values.set(x,v);},removeItem:(x:string)=>{values.delete(x);}};
  assert.equal(loadTrustedContact(storage),null);
  assert.equal(saveTrustedContact("112",storage),false);
  assert.equal(saveTrustedContact("+33 6 12 34 56 78",storage),true);
  assert.equal(values.get(TRUSTED_CONTACT_KEY),"+33612345678");
  assert.equal(loadTrustedContact(storage),"+33612345678");
  assert.equal(deleteTrustedContact(storage),true);
  assert.equal(loadTrustedContact(storage),null);
});
test("safely handles unavailable storage",()=>{
  const reject={getItem:(_:string)=>{throw new Error("blocked");},setItem:(_:string,__:string)=>{throw new Error("blocked");},removeItem:(_:string)=>{throw new Error("blocked");}};
  assert.equal(loadTrustedContact(reject),null);
  assert.equal(saveTrustedContact("+33612345678",reject),false);
  assert.equal(deleteTrustedContact(reject),false);
});
