import { test } from "node:test";
import assert from "node:assert/strict";
import { reviewDue, REVIEW_DAYS } from "../src/app/review-core.js";
test("Local check-in reminder is due when unrecorded or older than 30 days", () => {
  const now = Date.UTC(2026, 10, 23, 12);
  assert.equal(REVIEW_DAYS,30);
  assert.equal(reviewDue(null,now),true);
  assert.equal(reviewDue(now - 29*86400_000,now),false);
  assert.equal(reviewDue(now - 30*86400_000,now),true);
  assert.equal(reviewDue(now + 120000,now),true);
});
