import { test } from "node:test";
import assert from "node:assert/strict";
import { HOME_EXTRA, CHROME_UI, FRENCH_ONLY_ROUTES } from "../src/app/home-i18n.js";

const LANGS = ["fr", "en", "es"] as const;

test("Navigation, badge and home extras define the same keys in FR/EN/ES", () => {
  for (const dict of [HOME_EXTRA, CHROME_UI]) {
    const ref = Object.keys(dict.fr).sort();
    for (const lang of LANGS) assert.deepEqual(Object.keys(dict[lang]).sort(), ref, `key mismatch in ${lang}`);
  }
});

test("Non-French interfaces do not reuse French navigation labels", () => {
  for (const lang of ["en", "es"] as const) {
    for (const key of ["skip", "home", "prepare", "aid", "offline"] as const)
      assert.notEqual(CHROME_UI[lang][key], CHROME_UI.fr[key], `${lang}.${key} still French`);
    assert.ok(CHROME_UI[lang].frOnly.length > 40, `${lang} French-only notice missing`);
  }
  assert.equal(CHROME_UI.fr.frOnly, "", "French users must not see a French-only warning");
});

test("French-only routes keep the SOS reachable and never claim automatic alerts", () => {
  assert.ok(!FRENCH_ONLY_ROUTES.has("terrain"), "SOS must stay translated");
  assert.ok(!FRENCH_ONLY_ROUTES.has("monde"));
  for (const lang of LANGS) {
    const all = Object.values(HOME_EXTRA[lang]).concat(Object.values(CHROME_UI[lang])).join(" ");
    assert.ok(!/secours (sont )?(prévenus|alertés)|rescuers (are )?notified|rescate avisado/i.test(all));
  }
  assert.match(HOME_EXTRA.en.smallPrint, /no automatic alert/);
  assert.match(HOME_EXTRA.es.smallPrint, /no hay alerta automática/);
});
