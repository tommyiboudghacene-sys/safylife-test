import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { countryAtPoint, decodeWorld, decodeWorldRing, type WorldData } from "../src/app/world-core.js";
import { additionalEmergencyNumbersFor, chooseCountry, countryOptions, emergencyFor, selectedCountry } from "../src/app/fr-world.js";

const atlas = decodeWorld(JSON.parse(readFileSync("public/world-shapes.json", "utf8")) as WorldData);

test("the self-contained atlas covers more than 200 territories", () => {
  assert.ok(atlas.length >= 200);
  assert.ok(atlas.some(c => c.code === "fr"));
  assert.ok(atlas.some(c => c.code === "jp"));
});

test("country detection works for inland reference points", () => {
  for (const [lat, lon, expected] of [
    [48.8566, 2.3522, "fr"],
    [40.7829, -73.9650, "us"], // Central Park, away from the simplified coastline
    [-23.5505, -46.6333, "br"],
    [35.6762, 139.6503, "jp"],
    [28.6139, 77.2090, "in"],
  ] as const) assert.equal(countryAtPoint(atlas, { lat, lon }), expected);
  assert.equal(countryAtPoint(atlas, { lat: 0, lon: -130 }), null, "open ocean");
});

test("malformed, incomplete or out-of-range atlas data fails safely", () => {
  assert.throws(() => decodeWorldRing("?", 1000));
  assert.throws(() => decodeWorldRing("!@", 1000));
  assert.throws(() => decodeWorldRing("??", 0));
  assert.equal(countryAtPoint(atlas, { lat: 120, lon: 0 }), null);
  assert.equal(countryAtPoint(atlas, { lat: Number.NaN, lon: 0 }), null);
});

test("emergency calls are shown only where a verified country number is available", () => {
  assert.equal(emergencyFor("FR")?.number, "112");
  assert.equal(emergencyFor("US")?.number, "911");
  assert.equal(emergencyFor("NZ")?.number, "111");
  assert.equal(emergencyFor("AU")?.number, "000");
  assert.equal(emergencyFor("IN")?.number, "112");
  assert.equal(emergencyFor("BR")?.kind, "ambulance");
  assert.equal(emergencyFor("JP")?.number, "119");
  assert.equal(emergencyFor("JP")?.kind, "fire-medical");
  assert.equal(emergencyFor("MA")?.number, "150");
  assert.equal(emergencyFor("MA")?.kind, "fire-medical");
  assert.equal(emergencyFor("KR")?.number, "119");
  assert.deepEqual(additionalEmergencyNumbersFor("JP").map(v => v.number), ["110"]);
  assert.deepEqual(additionalEmergencyNumbersFor("KR").map(v => v.number), ["112"]);
  assert.deepEqual(additionalEmergencyNumbersFor("MA").map(v => v.number), ["190", "19"]);
  assert.equal(emergencyFor("ZZ"), null, "never invent a local number");
});

test("country choice keeps a session-only fallback when storage is absent", () => {
  chooseCountry("US");
  assert.equal(selectedCountry(), "US");
  chooseCountry("ZZ");
  assert.equal(selectedCountry(), "US", "reject unknown code");
  chooseCountry("");
  assert.equal(selectedCountry(), "");
});

test("SOS country picker offers more than 200 countries and preserves known options", () => {
  const options = countryOptions();
  assert.ok(options.length >= 200);
  for (const code of ["FR", "JP", "MA", "KR", "US", "GB"]) {
    assert.ok(options.some(option => option.code === code), `missing ${code}`);
  }
});

test("GOV.UK-sourced numbers added on 2026-11-24 keep agencies distinct", () => {
  const expected: Record<string, [string, string]> = { MX: ["911", "all"], TR: ["112", "all"], PH: ["911", "all"], CH: ["112", "all"],
    ZA: ["10177", "fire-medical"], TH: ["1669", "ambulance"], ID: ["118", "ambulance"], NO: ["113", "ambulance"] };
  for (const [code, [number, kind]] of Object.entries(expected)) {
    const e = emergencyFor(code);
    assert.equal(e?.number, number, code);
    assert.equal(e?.kind, kind, code);
    assert.match(e?.url ?? "", /^https:\/\/www\.gov\.uk\/foreign-travel-advice\/[a-z-]+\/getting-help$/);
  }
  assert.deepEqual(additionalEmergencyNumbersFor("ZA").map(n => n.number), ["10111"]);
  assert.deepEqual(additionalEmergencyNumbersFor("TH").map(n => n.number), ["191"]);
  assert.deepEqual(additionalEmergencyNumbersFor("NO").map(n => n.number), ["112"]);
  assert.equal(emergencyFor("CN"), null, "unverified countries must not show a call button");
});
