import {test} from 'node:test';
import assert from 'node:assert/strict';
import { weeklyPracticeIndex,currentWeeklyPractice } from '../src/app/weekly-practice.js';
import { WORLD_PRACTICES } from '../src/app/world-practices.js';

test('weekly practice is stable within one Monday-to-Sunday UTC week',()=>{
  const monday=weeklyPracticeIndex(new Date('2026-11-23T00:00:01Z'));
  const sunday=weeklyPracticeIndex(new Date('2026-11-29T23:59:59Z'));
  assert.equal(monday,sunday);
  assert.notEqual(monday,weeklyPracticeIndex(new Date('2026-11-30T00:00:00Z')));
});
test('selection uses only reviewed sources, no fabricated live news',()=>{
  for (let i=0;i<12;i++) {
    const p=currentWeeklyPractice(new Date(Date.UTC(2026,10,23+7*i)));
    assert.ok(WORLD_PRACTICES.includes(p));
    assert.ok(p.url.startsWith('https://'));
  }
});
