import assert from "node:assert/strict";
import { test } from "node:test";
import { shareEmergencyText } from "../src/app/sos-share.js";

test("share result means sheet completed, not that an alert reached emergency services", async () => {
  let shared = "";
  const outcome = await shareEmergencyText("Help text", async data => { shared = data.text; }, async () => { throw Error("should not copy"); });
  assert.equal(outcome, "shared");
  assert.equal(shared, "Help text");
});

test("unsupported or rejected sharing falls back to clipboard, then manual text", async () => {
  assert.equal(await shareEmergencyText("Help", undefined, async () => true), "copied");
  assert.equal(await shareEmergencyText("Help", async () => { throw new Error("NotAllowedError"); }, async () => false), "manual");
  assert.equal(await shareEmergencyText("Help", undefined, async () => { throw new Error("No clipboard"); }), "manual");
});

test("explicitly cancelled native share does not copy behind the user's back", async () => {
  let copied = false;
  const abort = new Error("Cancelled"); abort.name = "AbortError";
  const outcome = await shareEmergencyText("My GPS", async () => { throw abort; }, async () => { copied = true; return true; });
  assert.equal(outcome, "cancelled");
  assert.equal(copied, false);
});
