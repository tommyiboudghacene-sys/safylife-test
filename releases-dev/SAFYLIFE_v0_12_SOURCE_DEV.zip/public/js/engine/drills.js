import { runScenario } from "./index.js";
export const ANSWERS = [
    { id: "first-day", label: "Avant 24 heures" },
    { id: "one-to-three", label: "Entre 24 et 72 heures" },
    { id: "later", label: "Après 72 heures" },
    { id: "covered", label: "Pas de rupture critique pendant la simulation" },
];
const NAMES = {
    power: "Panne électrique",
    water: "Coupure d'eau",
    comms: "Réseaux indisponibles",
    "heat-power": "Canicule et panne",
    storm: "Tempête ou inondation",
    evacuation: "Évacuation",
    "conflict-services": "Conflit : services interrompus",
    "conflict-evac": "Conflit : évacuation",
};
export function buildDrill(plan, id) {
    const { result, tasks } = runScenario(plan, id);
    const firstFailureHours = result.holdsFullDuration ? null : result.sustainableHours;
    const correct = firstFailureHours === null ? "covered"
        : firstFailureHours < 24 ? "first-day"
            : firstFailureHours < 72 ? "one-to-three" : "later";
    const first = [...result.unmetNeeds]
        .filter((n) => n.severity >= 4 && n.failsAt !== null)
        .sort((a, b) => a.failsAt - b.failsAt || b.severity - a.severity)[0];
    const explanation = firstFailureHours === null
        ? `Aucune rupture critique calculée sur ${result.durationHours} heures. Cela ne signifie pas que la situation serait sans danger.`
        : `Première rupture critique estimée à ${firstFailureHours} h : ${first?.label ?? "besoin essentiel indisponible"}.`;
    const firstTask = tasks.find((t) => t.phase === "now" || t.phase === "before") ?? tasks[0];
    return {
        scenarioId: id, scenarioName: NAMES[id], durationHours: result.durationHours,
        correct, firstFailureHours, explanation,
        action: firstTask?.title ?? "Mettre votre plan familial à jour.",
    };
}
