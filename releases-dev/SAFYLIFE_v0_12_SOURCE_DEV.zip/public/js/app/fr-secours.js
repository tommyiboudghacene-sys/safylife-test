import { html, mount } from "./ui.js";
import { emergencyFor, selectedCountry } from "./fr-world.js";
export const FICHES = [
    {
        id: "arret-cardiaque", icon: "❤️", title: "Ne respire pas normalement",
        signal: "Une personne adulte ne répond pas et ne respire pas normalement, ou cherche son air par à-coups.",
        audience: "Massage cardiaque de l'adulte uniquement",
        steps: [
            "Vérifie que le lieu ne te met pas en danger. Vérifie si la personne réagit et respire normalement.",
            "Fais appeler le 112 immédiatement et demande un défibrillateur (DAE). Si tu es seul, appelle en haut-parleur.",
            "Commence les compressions : deux mains au centre de la poitrine, bras tendus, 100 à 120 fois par minute, environ 5 à 6 cm de profondeur chez l'adulte. Laisse la poitrine remonter entre deux compressions.",
            "Si tu es formé et peux le faire, alterne 30 compressions et 2 insufflations. Sinon, continue les compressions sans interruption inutile.",
            "Allume le DAE dès qu'il arrive, colle les électrodes comme indiqué et suis ses instructions vocales. Continue jusqu'à la prise en charge par les secours ou la reprise d'une respiration normale.",
        ],
        attention: "Pour un bébé, un enfant, une noyade ou une situation particulière, les gestes peuvent différer : demande immédiatement les consignes du 112.",
        source: "Croix-Rouge française — Arrêt cardiaque",
        url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/arret-cardiaque",
    },
    {
        id: "hemorragie", icon: "🩸", title: "Saignement très important",
        signal: "Le sang coule abondamment ou de manière continue.",
        audience: "Adulte ou enfant — avec protection contre le sang",
        steps: [
            "Protège-toi du danger et évite de toucher directement le sang : utilise des gants, un sac ou un tissu si possible.",
            "Appuie fermement et directement sur la plaie avec un tissu propre ou une protection adaptée. Si possible, demande à la personne de comprimer elle-même.",
            "Fais allonger la personne si c'est possible sans danger et appelle le 112.",
            "Continue à appuyer sans relâcher jusqu'à l'arrivée des secours. Suis les instructions de l'opérateur.",
        ],
        attention: "Si un objet est enfoncé dans la plaie, ne le retire pas. Demande au 112 comment exercer la pression autour. Une hémorragie peut mettre la vie en danger.",
        source: "Croix-Rouge française — L'hémorragie",
        url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/hemorragie",
    },
    {
        id: "inconscience", icon: "🫁", title: "Inconscient, mais respire",
        signal: "La personne ne répond pas, mais sa respiration est normale.",
        audience: "Sans traumatisme évident",
        steps: [
            "Vérifie ta sécurité, puis essaie de parler à la personne et observe sa respiration.",
            "Appelle le 112 et suis les consignes. Si elle respire normalement et qu'aucune blessure grave n'est suspectée, mets-la sur le côté (position latérale de sécurité).",
            "Pour la tourner sur le côté : bras proche à angle droit, main opposée contre sa joue, genou éloigné plié ; tire doucement ce genou vers toi pour la faire rouler.",
            "Stabilise-la sur le côté, bouche orientée vers le sol. Surveille souvent sa respiration jusqu'aux secours.",
        ],
        attention: "Après une chute ou un accident avec possible blessure au dos ou au cou, demande l'avis du 112 avant de déplacer la personne. Si elle ne respire pas normalement, passe à la fiche arrêt cardiaque.",
        source: "Croix-Rouge française — Position latérale de sécurité",
        url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/position-laterale-de-securite-comment-mettre-en-pls",
    },
    {
        id: "etouffement", icon: "😮", title: "Étouffement : adulte ou enfant",
        signal: "Une personne consciente ne peut plus parler, tousser efficacement ou respirer après avoir avalé quelque chose.",
        audience: "Adulte et enfant de plus d'un an — hors grossesse",
        steps: [
            "Si la personne tousse efficacement et respire, encourage-la à tousser. Ne lui donne pas de claques dans le dos.",
            "Si elle ne peut plus tousser ni respirer, fais appeler le 112. Penche-la vers l'avant et donne jusqu'à 5 claques fermes entre les omoplates, en vérifiant après chaque claque.",
            "Si cela ne suffit pas, pratique jusqu'à 5 compressions abdominales : derrière la personne, poing entre nombril et bas du sternum, tire vers toi et vers le haut.",
            "Alterne jusqu'à 5 claques dans le dos et 5 compressions abdominales tant que le blocage persiste. Si la personne perd connaissance, accompagne-la au sol et suis le 112 pour commencer la réanimation.",
        ],
        attention: "JAMAIS de compressions abdominales chez un bébé de moins d'un an. Pour une personne enceinte ou une situation particulière, demande immédiatement au 112 le geste adapté.",
        source: "Croix-Rouge française — L'étouffement",
        url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/etouffement",
    },
    {
        id: "bebe-etouffement", icon: "👶", title: "Bébé qui s'étouffe",
        signal: "Un nourrisson de moins d'un an ne peut plus pleurer, tousser efficacement ou respirer à cause d'un objet.",
        audience: "Nourrisson de moins d'un an",
        steps: [
            "Demande immédiatement de l'aide et fais appeler le 112. Si le bébé tousse efficacement ou pleure, surveille-le et demande un avis médical.",
            "Si l'air ne passe plus : maintiens sa tête et son cou, place-le à plat ventre sur ton avant-bras ou ta cuisse, tête plus basse que le corps, puis donne jusqu'à 5 claques fermes entre les omoplates.",
            "Si l'objet ne sort pas, retourne doucement le bébé sur le dos, toujours tête plus basse. Avec deux doigts sur la moitié basse du sternum, pratique jusqu'à 5 compressions thoraciques.",
            "Alterne ces deux gestes tant que l'obstruction persiste, en suivant les instructions du 112. Même si le bébé va mieux, demande un avis médical.",
        ],
        attention: "Ne secoue jamais le bébé et ne fais jamais de compressions abdominales. Si le bébé perd connaissance, les gestes de réanimation changent : suis immédiatement le 112.",
        source: "Croix-Rouge française — Bébé qui s'étouffe",
        url: "https://www.croix-rouge.fr/mes-infos-bebe/que-faire-si-mon-bebe-setouffe",
    },
    {
        id: "brulure", icon: "🔥", title: "Brûlure par la chaleur",
        signal: "La peau a été brûlée par une flamme, un objet chaud ou un liquide chaud.",
        audience: "Brûlure thermique uniquement",
        steps: [
            "Éloigne la personne de la source de chaleur si tu peux le faire sans danger.",
            "Refroidis rapidement la brûlure sous de l'eau courante tempérée, à faible débit, pendant au moins 10 minutes et idéalement 20 minutes.",
            "Enlève les bijoux et vêtements proches seulement s'ils ne collent pas à la peau. Protège doucement avec un linge propre.",
            "Appelle le 112 pour une brûlure grave, étendue, du visage, ou en cas de doute ; suis les consignes.",
        ],
        attention: "Pas de glace, de beurre ni de crème maison. Ne perce pas les cloques. En cas de brûlure chimique ou électrique, les consignes sont différentes : appelle les secours.",
        source: "Croix-Rouge française — Que faire en cas de brûlure ?",
        url: "https://www.croix-rouge.fr/les-gestes-de-premiers-secours/que-faire-en-cas-de-brulure",
    },
    {
        id: "avc", icon: "🧠", title: "Signes d'un AVC",
        signal: "Soudain, le visage se déforme, un bras devient faible ou la personne parle bizarrement.",
        audience: "Toute personne présentant ces signes",
        steps: [
            "Observe les signes VITE : Visage qui tombe, Impossible de lever un bras, Trouble de la parole.",
            "Appelle immédiatement le 15 ou le 112, même si les symptômes disparaissent. N'attends pas.",
            "Note l'heure à laquelle les signes ont commencé. Aide la personne à s'asseoir ou s'allonger et rassure-la.",
            "Ne lui donne ni à boire, ni à manger, ni de médicament sans instruction médicale. Suis les consignes du téléphone.",
        ],
        attention: "Un trouble brutal de la vue, de l'équilibre ou un mal de tête inhabituel peut aussi être un signe d'AVC. Appelle sans attendre.",
        source: "Assurance Maladie — AVC : que faire ? (18 juin 2026)",
        url: "https://www.ameli.fr/assure/sante/urgence/pathologies/avc",
    },
];
function urgence() {
    const country = selectedCountry();
    const verified = emergencyFor(country);
    return html `<div class="rp-aid-callout"><div><strong>Danger immédiat ? Appelle les secours.</strong><small>Ces fiches de premiers secours ont été rédigées pour la France. <a href="#/monde" style="color:#fff;text-decoration:underline">Choisir le pays et vérifier le numéro local</a>. ${verified?.kind === "ambulance" ? "Le numéro indiqué ne contacte que les ambulances." : verified?.kind === "fire-medical" ? "Le numéro indiqué contacte les pompiers et les ambulances, pas la police." : ""}</small></div>${verified ? html `<a class="rp-call-btn" href="tel:${verified.number}" aria-label="Composer le numéro ${verified.number}">📞 ${verified.number}</a>` : html `<a class="rp-call-btn" href="#/monde">🌍 Pays</a>`}</div>`;
}
function notice() {
    return html `<p class="rp-aid-disclaimer">⚠️ Les gestes et numéros cités dans ces fiches sont rédigés pour la France. Hors de France, vérifie les numéros et recommandations locales avant de les utiliser. Aide-mémoire pédagogique pour la France, pas une formation ni une assistance en direct. Commence par te mettre en sécurité et appeler les secours. Les appels téléphoniques nécessitent une couverture mobile ou téléphonique disponible. Synthèses rédigées à partir des pages citées le 22/11/2026, sans validation par un organisme de secourisme ; ces fiches ne se mettent pas à jour toutes seules.</p>`;
}
export function renderSecours(root, id) {
    const fiche = FICHES.find(f => f.id === id);
    if (id && !fiche) {
        location.hash = "#/secours";
        return;
    }
    if (fiche) {
        mount(root, html `
      <section class="rp-aid-top"><a class="rp-back" href="#/secours">← Tous les gestes</a><div class="rp-aid-detail-icon" aria-hidden="true">${fiche.icon}</div><span class="rp-eyebrow">Premiers secours · France</span><h1>${fiche.title}</h1><p class="rp-aid-signal">${fiche.signal}</p><span class="rp-aid-audience">${fiche.audience}</span></section>
      ${urgence()}
      <section class="card rp-aid-steps"><h2>Les gestes à faire</h2><ol>${fiche.steps.map(step => html `<li>${step}</li>`)}</ol></section>
      <section class="rp-aid-warning"><strong>⚠️ Attention</strong><p>${fiche.attention}</p></section>
      ${notice()}
      <p class="rp-aid-source">Source : <a href="${fiche.url}" target="_blank" rel="noopener noreferrer">${fiche.source}</a> (lien nécessitant Internet).</p>
      <div class="btn-row"><a class="btn" href="#/secours">← Choisir un autre geste</a></div>`);
        return;
    }
    mount(root, html `
    <section class="rp-aid-landing"><a class="rp-back" href="#/">← Accueil</a><span class="rp-eyebrow">Aide-mémoire · France</span><h1>Les gestes qui sauvent 🩹</h1><p>Un problème ? Choisis ce que tu vois. Si tu es enfant, appelle aussi un adulte tout de suite.</p></section>
    ${urgence()}
    <section class="rp-aid-first"><span aria-hidden="true">🛡️</span><div><strong>D'abord, protège-toi.</strong><p>Ne t'approche pas d'un feu, d'une route dangereuse ou d'un fil électrique. Donne le lieu et le problème aux secours, puis suis leurs consignes.</p></div></section>
    <section class="rp-aid-grid" aria-label="Choisir une situation">${FICHES.map(f => html `<a class="rp-aid-tile" href="#/secours/${f.id}"><span class="rp-aid-tile-icon" aria-hidden="true">${f.icon}</span><strong>${f.title}</strong><span class="rp-aid-tile-arrow" aria-hidden="true">→</span></a>`)}</section>
    ${notice()}
    <section class="rp-aid-sources"><h2>Sources de confiance</h2><p>Ces résumés ont été rédigés à partir des fiches de la <a href="https://www.croix-rouge.fr/les-gestes-de-premiers-secours" target="_blank" rel="noopener noreferrer">Croix-Rouge française</a>, d'<a href="https://www.ameli.fr/assure/sante/urgence/pathologies/avc" target="_blank" rel="noopener noreferrer">Ameli</a> et de <a href="https://www.service-public.gouv.fr/particuliers/vosdroits/F33954" target="_blank" rel="noopener noreferrer">Service-Public</a>. Une formation de premiers secours reste essentielle.</p></section>`);
}
