export const ADVENTURES = {
    blackout: {
        title: "La ville s'éteint", icon: "🌙", subtitle: "72 heures sans électricité ni réseau", tint: "mint",
        steps: [
            { hour: 0, icon: "⚡", title: "Tout s'arrête", story: "Les lumières s'éteignent et le téléphone perd le réseau. Un adulte réunit le foyer. Quelle est la première décision ?", choices: [
                    { title: "Sortir les lampes, la radio et vérifier les réserves", consequence: "Vous repérez ce qui fonctionne et ce qu'il faut économiser.", points: 25 },
                    { title: "Utiliser le téléphone sans arrêt pour chercher du réseau", consequence: "La batterie baisse vite sans améliorer la réception.", points: 5, phoneWaste: 20 },
                    { title: "Attendre sans vérifier l'équipement", consequence: "Les premières heures passent sans savoir ce qui manque.", points: 10 },
                ] },
            { hour: 12, icon: "🥫", title: "Le dîner se complique", story: "Le réfrigérateur n'est plus alimenté. Il faut organiser les repas sans prendre de risques.", choices: [
                    { title: "Privilégier les aliments stables, garder le frigo fermé", consequence: "Vous utilisez les aliments non périssables et limitez les ouvertures du réfrigérateur.", points: 25 },
                    { title: "Ouvrir le frigo régulièrement pour regarder", consequence: "L'air froid se perd. Les aliments périssables devront être évalués selon les consignes sanitaires.", points: 5, foodWaste: 0.35 },
                    { title: "Allumer un réchaud à combustible dans la maison", consequence: "Danger d'intoxication au monoxyde de carbone : les appareils à combustion doivent rester hors des espaces clos.", points: 0 },
                ] },
            { hour: 36, icon: "📻", title: "Une information importante", story: "Le réseau fonctionne mal. Une rumeur circule sur une nouvelle coupure d'eau.", choices: [
                    { title: "Écouter la radio et chercher une consigne officielle", consequence: "Vous privilégiez les informations vérifiables et ne relayez pas de rumeur.", points: 25 },
                    { title: "Transmettre la rumeur à tout le quartier", consequence: "Les informations non confirmées peuvent créer de la confusion.", points: 5, phoneWaste: 15 },
                    { title: "Ignorer toute information jusqu'à demain", consequence: "Vous risquez de manquer des recommandations importantes.", points: 10 },
                ] },
            { hour: 60, icon: "🤝", title: "Dernière ligne droite", story: "La troisième journée se termine. Comment organiser la suite avec la famille ?", choices: [
                    { title: "Faire le point ensemble sur l'eau, la nourriture et les contacts", consequence: "Le foyer partage les tâches et identifie ses besoins restants.", points: 25 },
                    { title: "Utiliser toutes les batteries pour se distraire", consequence: "La charge restante pour communiquer diminue.", points: 5, phoneWaste: 30 },
                    { title: "Garder les difficultés pour soi", consequence: "Les autres membres de la famille ne peuvent pas aider efficacement.", points: 10 },
                ] },
        ],
    },
    flood: {
        title: "La montée des eaux", icon: "🌧️", subtitle: "Pluie, inondation et décisions en famille", tint: "blue",
        steps: [
            { hour: 0, icon: "🌧️", title: "La pluie s'intensifie", story: "Une vigilance officielle annonce un risque d'inondation. Vous êtes encore chez vous.", choices: [
                    { title: "Vérifier les consignes locales et préparer le nécessaire", consequence: "La famille identifie les informations utiles et les affaires indispensables.", points: 25 },
                    { title: "Aller filmer la rivière en crue", consequence: "Approcher une zone inondée expose à des dangers imprévisibles.", points: 0 },
                    { title: "Tout ignorer puisque la maison est encore au sec", consequence: "Le temps disponible pour se préparer se réduit.", points: 10 },
                ] },
            { hour: 12, icon: "🎒", title: "Préparation du départ", story: "Les autorités annoncent qu'une évacuation pourrait être nécessaire. Que préparez-vous ?", choices: [
                    { title: "Papiers, médicaments, eau, vêtements et contacts", consequence: "L'essentiel est prêt pour suivre un éventuel ordre d'évacuation.", points: 25 },
                    { title: "Seulement quelques objets de valeur", consequence: "Des besoins vitaux peuvent être oubliés.", points: 5 },
                    { title: "Aucun sac : on improvisera", consequence: "Un départ urgent risque d'être plus difficile.", points: 10 },
                ] },
            { hour: 36, icon: "🚧", title: "Une route est coupée", story: "Une route est recouverte d'eau. Il n'est pas possible de savoir ici si un itinéraire alternatif est sûr.", choices: [
                    { title: "Éviter l'eau et suivre les indications des autorités", consequence: "Vous ne tentez pas de traverser une route inondée.", points: 25 },
                    { title: "Passer vite en voiture", consequence: "Même peu profonde, l'eau peut cacher un courant et emporter un véhicule.", points: 0 },
                    { title: "Traverser à pied pour vérifier", consequence: "L'eau masque les trous, obstacles et courants.", points: 0 },
                ] },
            { hour: 60, icon: "🏠", title: "Après le danger", story: "Une accalmie se dessine. Vous souhaitez rentrer, mais les autorités n'ont pas confirmé la sécurité de la zone.", choices: [
                    { title: "Attendre l'autorisation et les consignes de retour", consequence: "Vous évitez un retour prématuré dans un bâtiment ou une zone potentiellement dangereux.", points: 25 },
                    { title: "Rentrer immédiatement sans vérifier", consequence: "Les risques électriques, structurels et sanitaires peuvent persister.", points: 0 },
                    { title: "Se fier uniquement à une publication sur les réseaux", consequence: "Une publication isolée ne remplace pas une consigne officielle.", points: 5 },
                ] },
        ],
    },
    conflict: {
        title: "72 heures d'incertitude", icon: "🛡️", subtitle: "Protéger les civils lors d'une crise majeure", tint: "peach",
        steps: [
            { hour: 0, icon: "📻", title: "Les services s'interrompent", story: "Électricité, réseau et commerces deviennent indisponibles. Une consigne officielle demande de rester à l'abri.", choices: [
                    { title: "Respecter la consigne et rassembler les essentiels", consequence: "Vous évitez les déplacements non nécessaires et repérez les réserves.", points: 25 },
                    { title: "Partir au hasard sans information", consequence: "Un départ improvisé peut exposer à des dangers inconnus.", points: 0 },
                    { title: "Sortir pour observer ce qui se passe", consequence: "L'exposition au danger augmente sans information utile.", points: 0 },
                ] },
            { hour: 12, icon: "💧", title: "L'eau devient précieuse", story: "Le robinet ne fonctionne plus. Vous devez organiser les usages de l'eau disponible.", choices: [
                    { title: "Vérifier la réserve d'eau potable et suivre les consignes", consequence: "Vous connaissez les volumes disponibles, sans réduire les besoins vitaux des personnes.", points: 25 },
                    { title: "Boire de l'eau d'origine inconnue sans vérification", consequence: "Une eau contaminée présente un risque sanitaire grave.", points: 0 },
                    { title: "Utiliser l'eau potable pour nettoyer le sol", consequence: "Une partie de la réserve est perdue pour les besoins essentiels.", points: 5, waterWaste: 3 },
                ] },
            { hour: 36, icon: "📄", title: "Une évacuation est annoncée", story: "Les autorités donnent des consignes d'évacuation et un itinéraire. Votre plan familial est-il prêt ?", choices: [
                    { title: "Suivre les consignes et prendre le sac préparé", consequence: "Vous vous organisez autour des informations officielles et des besoins particuliers du foyer.", points: 25 },
                    { title: "Choisir un raccourci inconnu", consequence: "L'application ne peut pas confirmer la sûreté d'un trajet improvisé.", points: 0 },
                    { title: "Attendre des rumeurs pour décider", consequence: "Les informations non vérifiées peuvent retarder la protection de la famille.", points: 5 },
                ] },
            { hour: 60, icon: "🤝", title: "Rester unis", story: "La fatigue se fait sentir et les contacts sont difficiles. Comment garder les proches informés ?", choices: [
                    { title: "Utiliser le plan de contacts et les informations officielles", consequence: "Le foyer privilégie ses points de rendez-vous et les canaux prévus.", points: 25 },
                    { title: "Publier sa localisation et celle des proches partout", consequence: "Diffuser des données personnelles sensibles peut créer de nouveaux risques.", points: 0, phoneWaste: 20 },
                    { title: "Multiplier les appels sans message prioritaire", consequence: "La batterie baisse rapidement pour peu d'informations utiles.", points: 10, phoneWaste: 20 },
                ] },
        ],
    },
};
const safe = (n, max) => Number.isFinite(n) ? Math.max(0, Math.min(max, n)) : 0;
export const waterPerDay = (people) => people * 3.785;
export function startAdventure(plan, id, demo) {
    const people = Math.max(1, plan.household.people.length);
    const bank = plan.inventory.powerBanks.reduce((total, p) => total + safe(p.ratedMah, 200000) * safe(p.charge, 1), 0);
    return {
        id, index: 0, hour: 0, people,
        water: safe(plan.inventory.waterLiters, 50000), food: safe(plan.inventory.foodPersonDays, 10000),
        battery: safe(plan.inventory.phoneCharge * 100, 100) + Math.min(30, bank / 1000),
        score: 0, last: "", decisions: [], finished: false,
        needsAttention: plan.household.people.some(p => p.needsPoweredDevice || p.limitedMobility || p.ageGroup === "infant"),
        demo,
    };
}
export function chooseAdventure(state, choiceIndex) {
    if (state.finished || !Number.isInteger(choiceIndex) || choiceIndex < 0 || choiceIndex > 2 || state.decisions.length !== state.index)
        return state;
    const adventure = ADVENTURES[state.id];
    const step = adventure.steps[state.index];
    if (!step)
        return state;
    const choice = step.choices[choiceIndex];
    const next = adventure.steps[state.index + 1];
    const nextHour = next?.hour ?? 72;
    const hours = nextHour - state.hour;
    if (hours < 0)
        return state;
    const water = Math.max(0, state.water - waterPerDay(state.people) * hours / 24 - (choice.waterWaste ?? 0));
    const food = Math.max(0, state.food - state.people * hours / 24 - (choice.foodWaste ?? 0));
    const battery = Math.max(0, state.battery - hours / 4 - (choice.phoneWaste ?? 0));
    return {
        ...state, index: state.index + 1, hour: nextHour,
        water, food, battery: Math.round(battery),
        score: state.score + choice.points, last: choice.consequence,
        decisions: [...state.decisions, choiceIndex], finished: !next,
    };
}
export function adventureSignals(state) {
    const signals = [];
    if (state.water <= 0)
        signals.push("💧 Réserve d'eau potable épuisée dans ce modèle simplifié.");
    else if (state.water < waterPerDay(state.people))
        signals.push("💧 Moins d'une journée d'eau potable restante selon les hypothèses.");
    if (state.food <= 0)
        signals.push("🥫 Réserve d'aliments non périssables épuisée dans le modèle.");
    if (state.battery <= 0)
        signals.push("🔋 Autonomie de communication simulée épuisée.");
    if (state.needsAttention)
        signals.push("💛 Pense aux besoins particuliers de chaque membre du foyer.");
    return signals;
}
