import { SCENARIOS } from "../engine/index.js";
import { ANSWERS, buildDrill } from "../engine/drills.js";
import { html, mount } from "./ui.js";
const SELECTABLE = new Set(SCENARIOS.map((s) => s.id));
export function renderDrills(root, plan, selected) {
    const scenarioId = selected && SELECTABLE.has(selected) ? selected : "power";
    const drill = buildDrill(plan, scenarioId);
    mount(root, html `
    <section class="feature-intro">
      <div class="feature-kicker">Entraînement personnalisé</div>
      <h1>Et si ça arrivait demain ?</h1>
      <p class="muted">Un mini-défi tiré des stocks et des dépendances de votre foyer, calculé directement sur votre appareil.</p>
      <p class="feature-note">Simulation pédagogique, pas prédiction d'un événement réel. Vérifiez les données de votre foyer.</p>
    </section>
    <section class="card challenge">
      <label for="drill-scenario" class="hint">Situation à explorer</label>
      <select id="drill-scenario" aria-label="Choisir un scénario">
        ${SCENARIOS.map((s) => html `<option value="${s.id}" ${s.id === scenarioId ? "selected" : ""}>${buildDrill(plan, s.id).scenarioName}</option>`)}
      </select>
      <div class="drill-stage">01 / Observation</div>
      <h2>Quand le premier besoin essentiel risque-t-il de ne plus être couvert ?</h2>
      <p class="muted">Horizon : ${drill.durationHours} heures. Choisis avant de découvrir le résultat.</p>
      <div class="answers" role="group" aria-label="Choix de réponse">
        ${ANSWERS.map((answer) => html `<button type="button" class="answer" data-answer="${answer.id}">${answer.label}</button>`)}
      </div>
      <div class="drill-feedback" id="drill-feedback" role="status" aria-live="polite" hidden></div>
    </section>
    <section class="card challenge-next">
      <div class="drill-stage">02 / Décision</div>
      <h2>Transformer la leçon en préparation</h2>
      <p class="muted">La prochaine action sera proposée après ta réponse. Tu pourras ensuite modifier tes réserves et refaire l'exercice.</p>
      <a class="btn" href="#/setup">Mettre à jour mon foyer</a>
    </section>`);
    root.querySelector("#drill-scenario")?.addEventListener("change", (event) => {
        const select = event.target;
        location.hash = `#/drill/${select.value}`;
    });
    for (const el of root.querySelectorAll("[data-answer]")) {
        el.addEventListener("click", () => {
            const answer = el.dataset.answer;
            const correct = answer === drill.correct;
            for (const b of root.querySelectorAll("[data-answer]")) {
                b.disabled = true;
                b.classList.toggle("chosen", b === el);
                b.classList.toggle("correct", b.dataset.answer === drill.correct);
            }
            const feedback = root.querySelector("#drill-feedback");
            if (!feedback)
                return;
            feedback.hidden = false;
            mount(feedback, html `
        <h3>${correct ? "Bien vu !" : "Regardons ce que dit la simulation."}</h3>
        <p>${drill.explanation}</p>
        <p class="hint">Première action proposée par le moteur : ${drill.action}</p>
        <a class="btn primary" href="#/scenario/${drill.scenarioId}">Voir les causes et le plan d'action</a>`);
        });
    }
}
