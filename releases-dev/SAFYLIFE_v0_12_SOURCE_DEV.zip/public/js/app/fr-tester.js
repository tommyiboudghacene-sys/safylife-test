import { html, mount } from "./ui.js";
const QUESTIONS = [
    { id: "simple", label: "C'était facile à comprendre ?" },
    { id: "amusant", label: "Tu as aimé les jeux ?" },
    { id: "joli", label: "Tu trouves ça joli ?" },
];
const OPTIONS = [
    { id: "oui", face: "😍", label: "Oui !" },
    { id: "moyen", face: "😐", label: "Un peu" },
    { id: "non", face: "😕", label: "Non" },
];
const votes = {};
let comment = "";
export function testerReport() {
    const choiceName = (c) => OPTIONS.find(o => o.id === c)?.label ?? "Pas répondu";
    return [
        "MON AVIS — SAFYLIFE (version d'essai)",
        ...QUESTIONS.map(q => `${q.label} ${choiceName(votes[q.id])}`),
        `Ce que je changerais : ${comment.trim().slice(0, 500) || "Rien à signaler"}`,
    ].join("\n");
}
export function renderTester(root, onQuit) {
    mount(root, html `
    <section class="rp-tester-hero"><a href="#/" class="rp-back">← Accueil</a><span class="rp-eyebrow">🎯 Mission découverte · Environ 5 minutes</span>
      <div class="rp-tester-symbol" aria-hidden="true">🚀</div><h1>À toi de tester !</h1>
      <p>Essaie ces trois activités. Il n'y a pas de mauvaise réponse. Dis-nous ce que tu aimes… et ce qui te gêne !</p>
      <span class="rp-tester-reassurance">✅ Pas de compte · 🎮 Pas d'achat · 📶 Fonctionne sans Internet</span></section>
    <section class="rp-tester-steps" aria-label="Trois activités à essayer">
      <a href="#/game/kit" class="rp-tester-step"><span class="rp-tester-step-num">1</span><span class="rp-tester-step-icon" aria-hidden="true">🎒</span><span><strong>Prépare ton sac</strong><small>Choisis huit objets utiles.</small></span><span aria-hidden="true">→</span></a>
      <a href="#/aventure/blackout" class="rp-tester-step"><span class="rp-tester-step-num">2</span><span class="rp-tester-step-icon" aria-hidden="true">🌙</span><span><strong>Vis une aventure</strong><small>Choisis ce que fait ta famille.</small></span><span aria-hidden="true">→</span></a>
      <a href="#/monde" class="rp-tester-step"><span class="rp-tester-step-num">3</span><span class="rp-tester-step-icon" aria-hidden="true">🌍</span><span><strong>Explore le monde</strong><small>Choisis un pays sur la carte.</small></span><span aria-hidden="true">→</span></a>
    </section>
    <section class="rp-tester-survey card" aria-label="Mon avis sur l'application">
      <span class="rp-eyebrow">💬 Ton avis compte</span><h2>Alors, tu en penses quoi ?</h2><p>Appuie sur un visage pour répondre.</p>
      ${QUESTIONS.map(q => html `<div class="rp-tester-question"><h3>${q.label}</h3><div class="rp-tester-rating" role="group" aria-label="${q.label}">
        ${OPTIONS.map(o => html `<button type="button" data-test-rate="${q.id}:${o.id}" aria-pressed="${votes[q.id] === o.id}" class="rp-tester-rate ${votes[q.id] === o.id ? "is-selected" : ""}"><span aria-hidden="true">${o.face}</span><strong>${o.label}</strong></button>`)}
      </div></div>`)}
      <label class="rp-tester-label" for="rp-test-comment">Quelque chose à améliorer ? (facultatif)</label>
      <textarea id="rp-test-comment" rows="3" maxlength="500" placeholder="Par exemple : je n'ai pas compris ce bouton…">${comment}</textarea>
      <label class="rp-tester-label" for="rp-tester-report">Ton avis prêt à partager</label>
      <textarea id="rp-tester-report" rows="5" readonly aria-label="Résumé de mes réponses">${testerReport()}</textarea>
      <div class="rp-tester-actions"><button class="btn primary" type="button" id="rp-tester-copy">📋 Copier mon avis</button><button class="btn" type="button" id="rp-tester-share">📤 Partager</button></div>
      <p id="rp-tester-copy-status" class="hint" role="status" aria-live="polite">Les réponses restent sur ce téléphone. Rien n'est envoyé automatiquement.</p>
    </section><div class="rp-tester-finish"><button type="button" class="btn" id="rp-tester-done">🏠 Terminer mon test</button></div>
    <p class="rp-small-print">Cet exercice est un test d'ergonomie, pas une formation de sécurité ni un service d'urgence.</p>`);
    const update = () => {
        const report = root.querySelector("#rp-tester-report");
        if (report)
            report.value = testerReport();
    };
    root.querySelectorAll("[data-test-rate]").forEach(button => button.addEventListener("click", () => {
        const [key, value] = button.dataset.testRate.split(":");
        votes[key] = value;
        root.querySelectorAll(`[data-test-rate^="${key}:"]`).forEach(option => {
            const active = option === button;
            option.classList.toggle("is-selected", active);
            option.setAttribute("aria-pressed", String(active));
        });
        update();
    }));
    root.querySelector("#rp-test-comment")?.addEventListener("input", event => {
        comment = event.target.value.slice(0, 500);
        update();
    });
    const status = root.querySelector("#rp-tester-copy-status");
    const manualCopy = () => {
        const field = root.querySelector("#rp-tester-report");
        field.focus();
        field.select();
        status.textContent = "Ton texte est sélectionné. Fais un appui long puis « Copier » si nécessaire.";
    };
    root.querySelector("#rp-tester-copy")?.addEventListener("click", async () => {
        try {
            if (!navigator.clipboard?.writeText) {
                manualCopy();
                return;
            }
            await navigator.clipboard.writeText(testerReport());
            status.textContent = "✅ Avis copié ! Colle-le dans notre conversation pour me le transmettre.";
        }
        catch {
            manualCopy();
        }
    });
    root.querySelector("#rp-tester-share")?.addEventListener("click", async () => {
        if (typeof navigator.share !== "function") {
            manualCopy();
            return;
        }
        try {
            await navigator.share({ title: "Mon avis SAFYLIFE", text: testerReport() });
            status.textContent = "Menu de partage terminé. Tu choisis à qui envoyer ton avis.";
        }
        catch {
            status.textContent = "Partage annulé. Ton avis reste disponible ci-dessus.";
        }
    });
    root.querySelector("#rp-tester-done")?.addEventListener("click", onQuit);
}
