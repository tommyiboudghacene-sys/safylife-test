export function validFix(value, now = Date.now()) {
    if (!value || typeof value !== "object")
        return false;
    const fix = value;
    return Number.isFinite(fix.latitude) && Math.abs(fix.latitude) <= 90 &&
        Number.isFinite(fix.longitude) && Math.abs(fix.longitude) <= 180 &&
        Number.isFinite(fix.accuracy) && fix.accuracy >= 0 &&
        Number.isFinite(fix.at) && fix.at > 0 && fix.at <= now + 60000;
}
export function fixQuality(fix, now = Date.now()) {
    const ageMinutes = Math.max(0, (now - fix.at) / 60000);
    if (ageMinutes > 30)
        return "stale";
    if (ageMinutes > 5 || fix.accuracy > 1000)
        return "review";
    return "recent";
}
export function fixWarning(fix, now = Date.now()) {
    const quality = fixQuality(fix, now);
    if (quality === "stale")
        return "⚠️ ANCIENNE POSITION — elle ne représente peut-être plus l'endroit où tu te trouves.";
    if (quality === "review")
        return "⚠️ Position à revérifier : relevé ancien ou précision insuffisante.";
    return "Position récente : vérifie néanmoins la précision et ton environnement.";
}
export function positionText(fix, now = Date.now()) {
    const lines = [
        "SAFYLIFE — Position GPS à communiquer (aucun SOS automatique)",
        `Coordonnées : ${fix.latitude.toFixed(5)}, ${fix.longitude.toFixed(5)}`,
        `Relevée le ${new Date(fix.at).toLocaleString("fr-FR")} · précision estimée ± ${Math.round(fix.accuracy)} m`,
        fixWarning(fix, now),
    ];
    return lines.join("\n");
}
