export function parseOfflineCacheInventory(input) {
    if (!input || typeof input !== "object")
        return null;
    const data = input;
    if (data.type !== "SAFYLIFE_OFFLINE_STATUS" || typeof data.ready !== "boolean" ||
        typeof data.count !== "number" || typeof data.total !== "number" ||
        !Number.isSafeInteger(data.count) || !Number.isSafeInteger(data.total) ||
        data.count < 0 || data.total < 1 || data.total > 1000 || data.count > data.total)
        return null;
    // The worker must not claim completeness when one or more assets are missing.
    return { ready: data.ready && data.count === data.total, count: data.count, total: data.total };
}
