import { savePlan } from "./store.js";
import { html, mount, num } from "./ui.js";
const v = (value) => String(value ?? "");
const checked = (value) => value ? "checked" : "";
const option = (value, selected) => value === selected ? "selected" : "";
/** A compact, entirely French editor for all inputs used by the simulator. */
export function renderProfil(root, plan) {
    const people = plan.household.people;
    const count = (kind) => people.filter((p) => p.ageGroup === kind).length;
    const h = plan.household.home;
    const i = plan.inventory;
    const bank = i.powerBanks[0];
    const med = i.medications[0];
    const contact = i.contacts[0];
    mount(root, html `
    <section class="feature-intro rp-page-lead">
      <a href="#/" class="rp-back">← Accueil</a>
      <div class="feature-kicker">À remplir avec un adulte</div>
      <h1>Ma maison, mes réserves 🏠</h1>
      <p class="muted">Dis-nous combien vous êtes et ce que vous avez déjà. Pas besoin de tout remplir !</p>
    </section>
    <form id="rp-profile" class="rp-profile">
      <section class="card">
        <span class="rp-step">Étape 1 sur 2</span><h2>👨‍👩‍👧‍👦 Qui habite ici ?</h2>
        <div class="rp-form-grid">
          <label>Adultes <input name="adults" type="number" min="0" max="15" value="${count("adult")}" required></label>
          <label>Enfants <input name="children" type="number" min="0" max="15" value="${count("child")}" required></label>
          <label>Bébés <input name="infants" type="number" min="0" max="10" value="${count("infant")}" required></label>
          <label>Personnes âgées <input name="older" type="number" min="0" max="15" value="${count("older")}" required></label>
        </div>
        <div class="rp-checks">
          <label><input name="mobility" type="checkbox" ${checked(people.some(p => p.limitedMobility))}> Une personne a une mobilité réduite</label>
          <label><input name="medical-device" type="checkbox" ${checked(people.some(p => p.needsPoweredDevice))}> Un appareil médical dépend de l'électricité</label>
        </div>
      </section>
      <details class="card rp-settings">
        <summary>⚙️ Mon logement <small>Plus de détails, si besoin</small></summary>
        <div class="rp-form-grid">
          <label>Arrivée d'eau
            <select name="water-supply">
              <option value="gravity" ${option("gravity", h.waterSupply)}>Réseau classique</option>
              <option value="electric-pump" ${option("electric-pump", h.waterSupply)}>Pompe électrique</option>
              <option value="bottled-only" ${option("bottled-only", h.waterSupply)}>Eau en bouteilles uniquement</option>
            </select>
          </label>
          <label>Cuisson
            <select name="cooking">
              <option value="electric" ${option("electric", h.cooking)}>Électrique</option>
              <option value="gas" ${option("gas", h.cooking)}>Gaz</option>
              <option value="camp-stove" ${option("camp-stove", h.cooking)}>Réchaud autonome</option>
              <option value="none" ${option("none", h.cooking)}>Aucune</option>
            </select>
          </label>
          <label>Climat
            <select name="climate">
              <option value="temperate" ${option("temperate", h.climate)}>Tempéré</option>
              <option value="hot" ${option("hot", h.climate)}>Très chaud</option>
            </select>
          </label>
          <label>Étage <input name="floor" type="number" min="0" max="80" value="${v(h.floor)}"></label>
        </div>
        <div class="rp-checks">
          <label><input name="fridge" type="checkbox" ${checked(h.hasFridge)}> Réfrigérateur</label>
          <label><input name="freezer" type="checkbox" ${checked(h.hasFreezer)}> Congélateur</label>
          <label><input name="cooling" type="checkbox" ${checked(h.cooling !== "none")}> Ventilateur ou climatisation électrique</label>
        </div>
      </details>
      <section class="card">
        <span class="rp-step">Étape 2 sur 2</span><h2>💧 Qu'avons-nous à la maison ?</h2>
        <div class="rp-form-grid">
          <label>Eau à boire (en litres) <input name="water" type="number" min="0" max="50000" step="0.5" value="${v(i.waterLiters)}"></label>
          <label>Jours de nourriture pour 1 personne <input name="food" type="number" min="0" max="10000" step="0.5" value="${v(i.foodPersonDays)}"></label>
          <label>Lampes sans prise électrique <input name="flashlights" type="number" min="0" max="30" value="${v(i.flashlights)}"></label>
        </div>
        <div class="rp-checks rp-easy-checks">
          <label><input name="radio" type="checkbox" ${checked(i.batteryRadio)}> Nous avons une radio à piles ou à manivelle</label>
          <label><input name="aid" type="checkbox" ${checked(i.firstAidKit)}> Nous avons une trousse de secours</label>
        </div>
        <details class="rp-form-advanced"><summary>➕ Ajouter d'autres objets (facultatif)</summary>
        <div class="rp-form-grid">
          <label>Nourriture au frais (journées-personnes) <input name="perishable" type="number" min="0" max="10000" step="0.5" value="${v(i.perishableFoodPersonDays)}"></label>
          <label>Capacité d'une batterie externe (mAh) <input name="powerbank" type="number" min="0" max="200000" step="1000" value="${v(bank?.ratedMah ?? 0)}"></label>
          <label>Téléphones <input name="phones" type="number" min="0" max="30" value="${v(i.phones)}"></label>
          <label>Charge des téléphones (%) <input name="phone-charge" type="number" min="0" max="100" value="${Math.round(i.phoneCharge * 100)}"></label>
          <label>Piles de rechange <input name="batteries" type="number" min="0" max="100" value="${v(i.spareBatteries)}"></label>
          <label>Carburant du générateur (litres) <input name="generator" type="number" min="0" max="1000" step="0.5" value="${v(i.generatorFuelLiters)}"></label>
          <label>Consommation du générateur (litres/h) <input name="generator-rate" type="number" min="0" max="30" step="0.1" value="${v(i.generatorLitersPerHour)}"></label>
          <label>Autonomie du réchaud (heures) <input name="stove" type="number" min="0" max="1000" value="${v(i.cookingFuelHours)}"></label>
          <label>Argent liquide (montant indicatif) <input name="cash" type="number" min="0" max="100000" value="${v(i.cashOnHand)}"></label>
        </div>
        </details>
      </section>
      <details class="card rp-settings">
        <summary>🩺 Santé et contacts <small>À remplir avec un adulte</small></summary>
        <p class="hint">Le médicament sert uniquement au calcul des réserves, jamais à conseiller une dose.</p>
        <div class="rp-form-grid">
          <label>Nom d'un traitement (facultatif) <input name="med-name" type="text" maxlength="60" value="${med?.label ?? ""}"></label>
          <label>Jours de traitement disponibles <input name="med-days" type="number" min="0" max="3650" value="${med && med.dosesPerDay > 0 ? Math.floor(med.dosesOnHand / med.dosesPerDay) : 0}"></label>
          <label>Contact hors zone (nom) <input name="contact-name" maxlength="60" value="${contact?.name ?? ""}"></label>
          <label>Téléphone du contact <input name="contact-phone" type="tel" maxlength="40" value="${contact?.phone ?? ""}"></label>
          <label>Carburant du véhicule (%) <input name="fuel" type="number" min="0" max="100" value="${Math.round(i.vehicle.fuelFraction * 100)}"></label>
          <label>Autonomie réservoir plein (km) <input name="range" type="number" min="0" max="2000" value="${v(i.vehicle.rangeKmFullTank)}"></label>
        </div>
        <div class="rp-checks">
          <label><input name="cold-med" type="checkbox" ${checked(med?.requiresRefrigeration ?? false)}> Traitement nécessitant le froid</label>
          <label><input name="vehicle" type="checkbox" ${checked(i.vehicle.present)}> Véhicule disponible</label>
        </div>
      </details>
      <div class="btn-row">
        <button class="btn primary block rp-save-profile" type="submit">✅ Enregistrer ma maison</button>
      </div>
      <p class="hint">Si tu as rempli les détails, ils seront conservés aussi. <a href="#/data">Sauvegarder mes données</a>.</p>
    </form>`);
    root.querySelector("#rp-profile")?.addEventListener("submit", async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        if (!form.reportValidity())
            return;
        const data = new FormData(form);
        const n = (key, max = 100000) => Math.min(max, Math.max(0, num(data.get(key), 0)));
        const flag = (key) => data.get(key) === "on";
        const str = (key) => String(data.get(key) ?? "").trim();
        const people = [];
        const add = (ageGroup, count, label) => {
            for (let j = 0; j < count; j++)
                people.push({ id: `p${people.length + 1}`, label: `${label} ${j + 1}`, ageGroup });
        };
        add("adult", n("adults", 15), "Adulte");
        add("child", n("children", 15), "Enfant");
        add("infant", n("infants", 10), "Bébé");
        add("older", n("older", 15), "Senior");
        if (!people.length) {
            window.alert("Ajoute au moins une personne au foyer.");
            return;
        }
        if (flag("mobility"))
            people[0].limitedMobility = true;
        if (flag("medical-device"))
            people[0].needsPoweredDevice = true;
        plan.household.people = people;
        plan.household.home = {
            ...plan.household.home,
            waterSupply: str("water-supply"),
            cooking: str("cooking"),
            cooling: flag("cooling") ? "fan" : "none",
            climate: str("climate"),
            floor: n("floor", 80),
            hasFridge: flag("fridge"), hasFreezer: flag("freezer"),
        };
        const medName = str("med-name");
        const contactName = str("contact-name");
        const phone = str("contact-phone");
        const ratedMah = n("powerbank", 200000);
        plan.inventory = {
            ...plan.inventory,
            waterLiters: n("water", 50000), foodPersonDays: n("food", 10000),
            perishableFoodPersonDays: n("perishable", 10000),
            powerBanks: ratedMah > 0 ? [{ id: "bank1", label: "Batterie externe", ratedMah, charge: 1 }] : [],
            phones: n("phones", 30), phoneCharge: n("phone-charge", 100) / 100,
            flashlights: n("flashlights", 30), spareBatteries: n("batteries", 100),
            batteryRadio: flag("radio"), firstAidKit: flag("aid"),
            generatorFuelLiters: n("generator", 1000), generatorLitersPerHour: n("generator-rate", 30),
            cookingFuelHours: n("stove", 1000), cashOnHand: n("cash", 100000),
            medications: medName ? [{ id: "med1", label: medName, dosesOnHand: n("med-days", 3650), dosesPerDay: 1, requiresRefrigeration: flag("cold-med") }] : [],
            contacts: contactName || phone ? [{ id: "contact1", name: contactName || "Contact", phone, relation: "Contact d'urgence", outOfArea: true }] : [],
            vehicle: { present: flag("vehicle"), fuelFraction: n("fuel", 100) / 100, rangeKmFullTank: n("range", 2000) },
        };
        await savePlan(plan);
        location.hash = "#/";
    });
}
