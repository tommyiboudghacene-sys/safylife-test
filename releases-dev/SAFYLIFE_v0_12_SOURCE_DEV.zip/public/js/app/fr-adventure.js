import { adventureSignals, ADVENTURES, chooseAdventure, startAdventure } from "./fr-adventure-engine.js";
import { html, mount } from "./ui.js";
const KEY = "resilience-pocket:adventure:1:";
const memory = new Map();
function validState(value, id) {
    if (!value || typeof value !== "object")
        return false;
    const s = value;
    return s.id === id && Number.isInteger(s.index) && s.index >= 0 && s.index <= 4 &&
        Array.isArray(s.decisions) && s.decisions.length === s.index && s.decisions.every(n => Number.isInteger(n) && n >= 0 && n <= 2) &&
        Number.isFinite(s.water) && s.water >= 0 && Number.isFinite(s.food) && s.food >= 0 &&
        Number.isFinite(s.battery) && s.battery >= 0 && Number.isFinite(s.score) && s.score >= 0 && s.score <= 100 &&
        Number.isInteger(s.people) && s.people > 0 && s.people <= 40 && typeof s.last === "string" && s.last.length < 500 &&
        typeof s.demo === "boolean" && typeof s.needsAttention === "boolean" && typeof s.finished === "boolean" &&
        s.finished === (s.index === ADVENTURES[id].steps.length);
}
function saved(id) {
    const fromMemory = memory.get(id);
    if (fromMemory)
        return fromMemory;
    try {
        const value = JSON.parse(localStorage.getItem(KEY + id) ?? "null");
        if (validState(value, id)) {
            memory.set(id, value);
            return value;
        }
    }
    catch { /* local file storage unavailable; play remains available */ }
    return null;
}
export function exportAdventureProgress() {
    const values = {};
    for (const id of Object.keys(ADVENTURES)) {
        const state = saved(id);
        if (state)
            values[id] = JSON.parse(JSON.stringify(state));
    }
    return values;
}
export function importAdventureProgress(input) {
    if (!input || typeof input !== "object")
        return;
    const incoming = input;
    for (const id of Object.keys(ADVENTURES)) {
        if (validState(incoming[id], id))
            save(incoming[id]);
    }
}
function save(state) {
    memory.set(state.id, state);
    try {
        localStorage.setItem(KEY + state.id, JSON.stringify(state));
    }
    catch { /* current session only */ }
}
export function renderAdventures(root) {
    mount(root, html `
    <section class="rp-page-lead"><a href="#/drill" class="rp-back">← Tous les jeux</a><span class="rp-eyebrow">Nouveau · Aventure interactive</span>
      <h1>Ma famille, 72 heures 🌟</h1><p>Trois histoires à vivre ensemble. Tes choix modifient le parcours et les réserves du foyer.</p></section>
    <section class="rp-adventure-grid">${Object.entries(ADVENTURES).map(([id, game]) => {
        const progress = saved(id);
        return html `<a href="#/aventure/${id}" class="rp-adventure-tile rp-adventure-${game.tint}">
        <span class="rp-adventure-tile-icon" aria-hidden="true">${game.icon}</span><span class="rp-tag">${progress?.finished ? "Rejouer ou revoir" : progress ? `Étape ${progress.index + 1} sur 4` : "4 décisions"}</span>
        <h2>${game.title}</h2><p>${game.subtitle}</p><strong>${progress ? "Continuer l'histoire →" : "Commencer l'aventure →"}</strong></a>`;
    })}</section>
    <section class="card rp-adventure-intro"><h2>🎒 Ton équipement change l'histoire</h2>
      <p>Le jeu tient compte des personnes, de l'eau, de la nourriture et des batteries enregistrées dans <a href="#/setup">Mes réserves</a>. Si tu n'as pas encore renseigné ton foyer, un exemple fictif est utilisé.</p>
      <p class="hint">Les conséquences sont des exemples pédagogiques, pas des prédictions ni des consignes opérationnelles. Un score élevé ne signifie pas que ta famille est en sécurité.</p>
    </section>`);
}
export function renderAdventure(root, plan, id, demo) {
    if (!(id in ADVENTURES)) {
        renderAdventures(root);
        return;
    }
    const key = id;
    const game = ADVENTURES[key];
    const resume = saved(key);
    const state = resume && resume.demo === demo ? resume : startAdventure(plan, key, demo);
    if (state !== resume)
        save(state);
    const step = game.steps[state.index];
    const alerts = adventureSignals(state);
    mount(root, html `
    <section class="rp-game-top"><a class="rp-back" href="#/aventures">← Les aventures</a><span class="rp-tag">72 heures · ${game.title}</span></section>
    <div class="rp-adventure-header rp-adventure-${game.tint}"><span class="rp-adventure-huge" aria-hidden="true">${state.finished ? "🏁" : step.icon}</span>
      <div><span class="rp-eyebrow">${state.finished ? "Aventure terminée" : `Chapitre ${state.index + 1} / 4`}</span><h1>${state.finished ? "Bravo pour cette aventure !" : step.title}</h1>
      <p>${state.finished ? "Regardons ce que tes choix ont changé." : game.subtitle}</p></div></div>
    <section class="rp-adventure-resources" aria-label="Réserves dans le jeu">
      <div><span>⏳ Temps</span><strong>${state.hour} / 72 h</strong></div>
      <div><span>💧 Eau</span><strong>${state.water.toLocaleString("fr-FR", { maximumFractionDigits: 1 })} L</strong></div>
      <div><span>🥫 Repas</span><strong>${state.food.toLocaleString("fr-FR", { maximumFractionDigits: 1 })} j-personnes</strong></div>
      <div><span>🔋 Énergie</span><strong>${state.battery} pts</strong></div>
    </section>
    <div class="rp-adventure-track" role="progressbar" aria-label="Progression de l'aventure" aria-valuemin="0" aria-valuemax="4" aria-valuenow="${state.index}"><span style="width:${state.index / 4 * 100}%"></span></div>
    ${state.demo ? html `<p class="feature-note">🎭 Exemple fictif. <a href="#/setup">Enregistrer les réserves réelles</a> pour une nouvelle partie.</p>` : ""}
    ${state.last ? html `<section class="rp-adventure-result"><span>🧭 Conséquence de ton choix</span><p>${state.last}</p></section>` : ""}
    ${alerts.length ? html `<section class="rp-adventure-signals"><strong>À surveiller dans ce modèle</strong><ul>${alerts.map(a => html `<li>${a}</li>`)}</ul></section>` : ""}
    ${state.finished ? html `
      <section class="card rp-adventure-end"><span class="rp-eyebrow">Ton parcours</span><h2>${state.score} / 100 points de décision</h2>
        <p>${state.score >= 75 ? "Tu as souvent privilégié la préparation et les informations fiables." : "Certaines décisions peuvent être améliorées. Rejoue pour voir leurs conséquences."}</p>
        <p><strong>Rappel :</strong> ce score évalue uniquement des choix de jeu. Les réserves et la sécurité réelles doivent être vérifiées par les adultes.</p>
        <div class="btn-row"><button class="btn primary" id="rp-adventure-restart">🔄 Rejouer</button><a class="btn" href="#/missions">🌟 Mes missions réelles</a><a class="btn" href="#/setup">🎒 Vérifier mon équipement</a></div>
      </section>` : html `
      <section class="card rp-adventure-scene"><span class="rp-eyebrow">🕰️ Heure ${step.hour}</span><h2>Que décides-tu ?</h2><p>${step.story}</p>
        <p class="rp-adventure-context">${state.water < state.people * 3.785 ? "💧 Attention : les réserves d'eau sont faibles pour ce foyer." : "💚 Tu connais maintenant les réserves disponibles."} ${state.battery < 20 ? "La batterie se vide : les communications deviennent difficiles." : ""}</p>
        <div class="rp-choices">${step.choices.map((choice, index) => html `<button type="button" class="rp-choice rp-adventure-option" data-adventure-choice="${index}"><span class="rp-adventure-option-number">${index + 1}</span>${choice.title}</button>`)}</div>
      </section>`}
    <p class="rp-small-print">Simulation éducative simplifiée. Consommation indicative : 3,785 L d'eau par personne et par jour, et une journée-personne de nourriture. La batterie est un indice de jeu, pas une estimation électrique. Les situations de conflit n'évaluent jamais la sécurité d'un abri ou d'un itinéraire.</p>`);
    root.querySelectorAll("[data-adventure-choice]").forEach(button => button.addEventListener("click", () => {
        const next = chooseAdventure(state, Number(button.dataset.adventureChoice));
        if (next === state)
            return;
        save(next);
        renderAdventure(root, plan, key, demo);
    }));
    root.querySelector("#rp-adventure-restart")?.addEventListener("click", () => {
        save(startAdventure(plan, key, demo));
        renderAdventure(root, plan, key, demo);
    });
}
