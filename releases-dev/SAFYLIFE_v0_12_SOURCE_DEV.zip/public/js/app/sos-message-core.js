import { fixQuality, positionText, validFix } from "./position-core.js";
export function helpRequestText(fix, now = Date.now(), lang = "fr") {
    const message = {
        fr: {
            intro: "J'AI BESOIN D'AIDE. Je ne peux peut-être pas téléphoner. Merci de prévenir les secours et de leur donner ma position si vous pouvez. Ne prenez pas de risques pour venir me chercher.",
            unknown: "Ma position GPS n'est pas disponible. Demandez-moi où je me trouve.",
            footer: "Message préparé avec SAFYLIFE ; envoi uniquement après confirmation sur le téléphone.",
        },
        en: {
            intro: "I NEED HELP. I may not be able to make a phone call. Please contact local emergency services and give them my location if possible. Do not put yourself in danger to reach me.",
            unknown: "My GPS position is unavailable. Please ask me where I am.",
            footer: "Prepared with SAFYLIFE. This message will only be sent if I confirm it on my phone.",
        },
        es: {
            intro: "NECESITO AYUDA. Puede que no pueda llamar. Por favor, contacta con los servicios de emergencia locales e indícales mi ubicación si es posible. No te pongas en peligro para buscarme.",
            unknown: "No tengo ubicación GPS disponible. Pregúntame dónde estoy.",
            footer: "Preparado con SAFYLIFE. Este mensaje solo se envía si lo confirmo en mi teléfono.",
        },
    }[lang];
    if (!fix || !validFix(fix, now))
        return `${message.intro}\n${message.unknown}\n${message.footer}`;
    if (lang === "fr")
        return `${message.intro}\n${positionText(fix, now)}\n${message.footer}`;
    const quality = fixQuality(fix, now);
    const warning = {
        en: {
            stale: "WARNING: OLD POSITION — this may no longer be where I am.",
            review: "WARNING: position may be outdated or inaccurate. Please verify.",
            recent: "Recent GPS reading. Actual accuracy may differ from the estimated accuracy.",
        },
        es: {
            stale: "ATENCIÓN: POSICIÓN ANTIGUA — puede que ya no esté allí.",
            review: "ATENCIÓN: ubicación antigua o poco precisa. Compruébala.",
            recent: "Lectura GPS reciente. La precisión real puede ser diferente de la estimada.",
        },
    }[lang][quality];
    const timestamp = new Date(fix.at).toLocaleString(lang === "en" ? "en-GB" : "es-ES");
    const position = lang === "en"
        ? `Coordinates: ${fix.latitude.toFixed(5)}, ${fix.longitude.toFixed(5)}\nRecorded: ${timestamp} · estimated accuracy ±${Math.round(fix.accuracy)} m`
        : `Coordenadas: ${fix.latitude.toFixed(5)}, ${fix.longitude.toFixed(5)}\nRegistrado: ${timestamp} · precisión estimada ±${Math.round(fix.accuracy)} m`;
    return `${message.intro}\n${position}\n${warning}\n${message.footer}`;
}
/** Sanitise free-form phone input; never store it or dial arbitrary characters. */
export function normalizeTrustedNumber(raw) {
    if (!/^[+0-9() .\-]{7,30}$/.test(raw.trim()))
        return null;
    const clean = raw.replace(/[() .\-]/g, "");
    if (!/^\+?[0-9]{7,15}$/.test(clean))
        return null;
    return clean;
}
export function smsDraftUrl(number, text, ios = false) {
    const recipient = normalizeTrustedNumber(number);
    if (!recipient || text.length > 1500 || !text.trim())
        return null;
    // iOS supports the &body form, Android commonly accepts ?body.
    return `sms:${recipient}${ios ? "&" : "?"}body=${encodeURIComponent(text)}`;
}
