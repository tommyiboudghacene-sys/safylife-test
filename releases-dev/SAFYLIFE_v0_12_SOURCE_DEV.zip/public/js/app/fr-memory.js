import { createMemoryRound, flipMemoryTile, hideMismatched } from "./memory-core.js";
import { html, mount } from "./ui.js";
const BEST_KEY = "resilience-pocket:memory-best:1";
const best = { 6: 0, 8: 0, 12: 0 };
try {
    const stored = JSON.parse(localStorage.getItem(BEST_KEY) ?? "null");
    for (const n of [6, 8, 12]) {
        if (stored && Number.isInteger(stored[n]) && stored[n] >= n && stored[n] <= 100000)
            best[n] = stored[n];
    }
}
catch { /* Session still works without browser storage. */ }
let round = null;
let hiddenTimer = null;
let recorded = null;
const LEVELS = [
    { count: 6, name: "Découverte", badge: "⭐" },
    { count: 8, name: "Aventurier", badge: "⭐⭐" },
    { count: 12, name: "Champion", badge: "⭐⭐⭐" },
];
function saveBest(state) {
    if (!state.finished || recorded === state)
        return;
    recorded = state;
    if (!best[state.level] || state.attempts < best[state.level]) {
        best[state.level] = state.attempts;
        try {
            localStorage.setItem(BEST_KEY, JSON.stringify(best));
        }
        catch { /* Session still works. */ }
    }
}
export function renderMemory(root) {
    if (!round)
        round = createMemoryRound(6);
    const state = round;
    if (hiddenTimer !== null) {
        window.clearTimeout(hiddenTimer);
        hiddenTimer = null;
    }
    saveBest(state);
    const visible = new Set([...state.open, ...state.matched]);
    const misses = state.open.length === 2;
    const found = state.matched.length / 2;
    const total = state.level;
    const progress = Math.round(found / total * 100);
    mount(root, html `
    <section class="rp-page-lead rp-memory-title"><a href="#/drill" class="rp-back">← Tous les jeux</a>
      <span class="rp-eyebrow">🧠 Grand jeu · Sans Internet</span><h1>Mémoire 72h</h1>
      <p>Retrouve les paires d'objets utiles. Fais travailler ta mémoire et essaie de battre ton record !</p></section>
    <section class="rp-memory-levels" aria-label="Niveau de difficulté">
      ${LEVELS.map(level => html `<button type="button" data-memory-level="${level.count}" class="rp-memory-level ${state.level === level.count ? "is-selected" : ""}" aria-pressed="${state.level === level.count}">
        <span>${level.badge}</span><strong>${level.name}</strong><small>${level.count} paires</small></button>`)}
    </section>
    <section class="rp-memory-stage" aria-label="Jeu de mémoire">
      <div class="rp-memory-score"><span><strong>${found} / ${total}</strong><small>Paires trouvées</small></span>
        <span><strong>${state.attempts}</strong><small>Essais</small></span>
        <span><strong>${best[state.level] || "—"}</strong><small>Mon record</small></span></div>
      <div class="rp-memory-progress" role="progressbar" aria-valuenow="${found}" aria-valuemin="0" aria-valuemax="${total}" aria-label="Paires trouvées"><span style="width:${progress}%"></span></div>
      <div class="rp-memory-grid" style="--memory-cols:${state.level === 6 ? 4 : state.level === 8 ? 4 : 6}" aria-label="Cartes à retourner">
        ${state.tiles.map(tile => {
        const isMatched = state.matched.includes(tile.id);
        const isVisible = visible.has(tile.id);
        return html `<button type="button" class="rp-memory-tile ${isVisible ? "is-open" : ""} ${isMatched ? "is-matched" : ""}"
            data-memory-tile="${tile.id}" aria-label="${isVisible ? tile.label : "Carte cachée " + (tile.id + 1)}" aria-pressed="${isVisible}" ${isVisible || state.finished || misses ? "disabled" : ""}>
            <span class="rp-memory-back" aria-hidden="true">✦</span><span class="rp-memory-front" aria-hidden="true">${tile.icon}</span></button>`;
    })}
      </div>
      <div class="rp-memory-message" role="status" aria-live="polite">
        ${state.finished ? html `<strong>🎉 Bravo, tu as retrouvé toutes les paires !</strong><p>Partie terminée en ${state.attempts} essais. ${best[state.level] === state.attempts ? "C'est ton meilleur score !" : "Tu peux encore améliorer ton score !"}</p>`
        : misses ? "Deux objets différents. Mémorise-les avant qu'ils se cachent !" : found ? "Super ! Continue à retrouver les paires." : "Retourne deux cartes pour commencer."}
      </div>
      <button type="button" class="btn primary rp-memory-again" id="rp-memory-again">🔄 ${state.finished ? "Nouvelle partie !" : "Recommencer la partie"}</button>
    </section>
    <p class="rp-small-print">Un jeu original pour toute la famille, entièrement local. Les illustrations sont ludiques : le jeu ne constitue pas une consigne de sécurité.</p>`);
    root.querySelectorAll("[data-memory-level]").forEach(button => button.addEventListener("click", () => {
        const next = Number(button.dataset.memoryLevel);
        if (![6, 8, 12].includes(next))
            return;
        round = createMemoryRound(next);
        renderMemory(root);
    }));
    root.querySelector("#rp-memory-again")?.addEventListener("click", () => {
        round = createMemoryRound(state.level);
        renderMemory(root);
    });
    root.querySelectorAll("[data-memory-tile]").forEach(button => button.addEventListener("click", () => {
        if (round !== state)
            return;
        const outcome = flipMemoryTile(state, Number(button.dataset.memoryTile));
        if (outcome === "ignored")
            return;
        renderMemory(root);
    }));
    if (misses) {
        hiddenTimer = window.setTimeout(() => {
            hiddenTimer = null;
            if (!root.isConnected || !location.hash.startsWith("#/game/memory") || round !== state)
                return;
            hideMismatched(state);
            renderMemory(root);
        }, 950);
    }
}
