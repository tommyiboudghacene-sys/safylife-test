import { SCENARIOS, formatHours, headlineNeed, runScenario, samplePlan } from "../engine/index.js";
import { renderAssumptions, renderData } from "./assumptions.js";
import { renderChecklist, renderHome, renderScenario } from "./dashboard.js";
import { renderDrills } from "./drills.js";
import { renderGuide } from "./guide.js";
import { renderPrintPlan } from "./plan-print.js";
import { timelineSvg } from "./timeline.js";
import { hasSetup, loadPlan, savePlan } from "./store.js";
import { html, mount, toast } from "./ui.js";
import { parseStep, renderWizard } from "./wizard.js";
function setCurrentNav(route) {
    for (const a of document.querySelectorAll("nav a")) {
        const target = a.getAttribute("href") ?? "";
        const active = route === "home" ? target === "#/" : target.startsWith(`#/${route}`);
        if (active)
            a.setAttribute("aria-current", "page");
        else
            a.removeAttribute("aria-current");
    }
}
function renderWelcome(root) {
    // A worked example, simulated live from the sample household, so a first-time
    // visitor sees what the app produces before entering anything.
    const sample = samplePlan();
    const { result } = runScenario(sample, "power");
    const need = headlineNeed(result);
    const width = Math.max(320, Math.min(640, root.clientWidth - 40));
    const pct = Math.round((result.sustainableHours / result.durationHours) * 100);
    // The sample is calculated live from the MIT-licensed simulation engine.
    const leaf = (c) => (c.children.length === 1 ? leaf(c.children[0]) : c);
    const phrase = (c) => {
        if (c.kind === "stock")
            return `${c.label}${c.amount ? ` (${c.amount})` : ""} ${c.reason ?? "ran out"}`;
        if (c.reason)
            return `${c.label}: ${c.reason}`;
        const root = leaf(c);
        const when = c.failsAt === 0 ? "stopped at once" : `stopped at ${formatHours(c.failsAt)}`;
        return `${c.label} ${when}${root !== c ? ` (${root.label.toLowerCase()} ${root.reason ?? "unavailable"})` : ""}`;
    };
    const chain = need?.because.map((c, i) => (i ? phrase(c).charAt(0).toLowerCase() + phrase(c).slice(1) : phrase(c))).join(", and ") ?? "";
    mount(root, html `
    <section class="welcome">
      <div class="kicker">Préparation aux crises · Prototype</div>
      <h1>Et si tout s'arrêtait demain&nbsp;?</h1>
      <p class="lead">Prépare ton foyer, découvre les besoins qui pourraient manquer en premier, puis entraîne-toi à prendre les bonnes décisions. Les simulations et les fiches fonctionnent hors connexion après installation.</p>
      <div class="btn-row">
        <a class="btn primary" href="#/setup">Préparer mon foyer</a>
        <button class="btn" data-action="sample">Essayer une démo</button>
        <a class="btn quiet" href="#/guide">Consulter les fiches</a>
      </div>
      <ul class="points">
        <li><b>6 scénarios</b><span>calculés heure par heure selon les ressources disponibles</span></li>
        <li><b>Défis adaptés</b><span>les exercices s'appuient sur les failles réelles de ta simulation</span></li>
        <li><b>Sans réseau</b><span>après installation ; tes données restent sur cet appareil</span></li>
      </ul>
    </section>
    <section class="card preview" aria-label="Résultat d'exemple">
      <div class="preview-head">
        <span class="badge">Exemple calculé</span>
        <span class="hint">Deux adultes au 4e étage, avec une pompe électrique pour l'eau</span>
      </div>
      <h2>Panne électrique : ${formatHours(result.sustainableHours)} de couverture estimée sur ${formatHours(result.durationHours)}</h2>
      <div class="meter danger"><i style="width:${pct}%"></i></div>
      ${need ? html `<p class="preview-why"><strong>Première fragilité calculée à ${formatHours(need.failsAt)}.</strong> ${chain ? html `Détail technique : ${chain}.` : ""}</p>` : ""}
      ${timelineSvg(result, width)}
      <div class="btn-row"><button class="btn" data-action="sample">Explorer cet exemple</button></div>
      <p class="hint">Estimation pédagogique, pas prévision d'une guerre, d'une catastrophe ou d'un risque individuel.</p>
    </section>`);
    root.querySelectorAll("[data-action=sample]").forEach((el) => el.addEventListener("click", async () => {
        await savePlan(samplePlan());
        toast("Foyer de démonstration chargé");
        void route();
    }));
}
async function route() {
    const plan = await loadPlan();
    const parts = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean);
    const [page, arg] = parts;
    window.scrollTo({ top: 0 });
    const old = document.getElementById("main");
    const root = old.cloneNode(false); // a fresh node drops the old listeners
    old.replaceWith(root);
    if (!hasSetup(plan) && page !== "setup" && page !== "guide") {
        setCurrentNav("home");
        renderWelcome(root);
        return;
    }
    switch (page) {
        case undefined:
        case "":
            setCurrentNav("home");
            renderHome(root, plan);
            break;
        case "setup":
            setCurrentNav("setup");
            renderWizard(root, plan, parseStep(arg));
            break;
        case "scenario": {
            setCurrentNav("home");
            const id = SCENARIOS.some((s) => s.id === arg) ? arg : "power";
            renderScenario(root, plan, id);
            break;
        }
        case "checklist":
            setCurrentNav("checklist");
            renderChecklist(root, plan);
            break;
        case "drill":
            setCurrentNav("drill");
            renderDrills(root, plan, arg);
            break;
        case "guide":
            setCurrentNav("guide");
            renderGuide(root);
            break;
        case "print":
            setCurrentNav("print");
            renderPrintPlan(root, plan);
            break;
        case "assumptions":
            setCurrentNav("assumptions");
            renderAssumptions(root, plan);
            break;
        case "data":
            setCurrentNav("data");
            renderData(root, plan);
            break;
        default:
            location.hash = "#/";
    }
}
window.addEventListener("hashchange", () => { void route(); });
void route();
// Offline indicator.
const badge = document.getElementById("offline-badge");
const updateOnline = () => { if (badge)
    badge.hidden = navigator.onLine; };
window.addEventListener("online", updateOnline);
window.addEventListener("offline", updateOnline);
updateOnline();
// Service worker: cache-first, so the app opens with no network after the first visit.
if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
        navigator.serviceWorker.register("sw.js").catch(() => { });
    });
}
