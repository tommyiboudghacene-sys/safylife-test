export function decodeWorldRing(encoded, precision) {
    if (!Number.isFinite(precision) || precision <= 0)
        throw new Error("Invalid map precision");
    let cursor = 0;
    let north = 0;
    let east = 0;
    const points = [];
    let minLat = Infinity;
    let maxLat = -Infinity;
    let minLon = Infinity;
    let maxLon = -Infinity;
    const next = () => {
        let power = 1;
        let unsigned = 0;
        for (let groups = 0; groups < 8; groups++) {
            if (cursor >= encoded.length)
                throw new Error("Truncated polygon data");
            const byte = encoded.charCodeAt(cursor++) - 63;
            if (byte < 0 || byte > 63)
                throw new Error("Malformed polygon data");
            unsigned += (byte % 32) * power;
            if (byte < 32)
                return unsigned % 2 === 0 ? unsigned / 2 : -(unsigned + 1) / 2;
            power *= 32;
        }
        throw new Error("Polygon value exceeds expected precision");
    };
    while (cursor < encoded.length) {
        north += next();
        east += next();
        const lat = north / precision;
        const lon = east / precision;
        if (Math.abs(lat) > 90.1 || Math.abs(lon) > 180.1)
            throw new Error("Invalid map coordinate");
        points.push({ lat, lon });
        minLat = Math.min(minLat, lat);
        maxLat = Math.max(maxLat, lat);
        minLon = Math.min(minLon, lon);
        maxLon = Math.max(maxLon, lon);
    }
    return { points, minLat, maxLat, minLon, maxLon };
}
export function decodeWorld(data) {
    if (!data || !Array.isArray(data.countries) || data.countries.length > 320)
        throw new Error("Invalid world map pack");
    return data.countries.map(([code, shapes]) => {
        if (!/^[a-z]{2,3}$/.test(code) || !Array.isArray(shapes) || shapes.length > 200)
            throw new Error("Invalid country shape");
        return { code, rings: shapes.map(s => decodeWorldRing(s, data.precision)) };
    });
}
function within(ring, lat, lon) {
    if (lat < ring.minLat || lat > ring.maxLat || lon < ring.minLon || lon > ring.maxLon)
        return false;
    let inside = false;
    const points = ring.points;
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const p = points[i];
        const previous = points[j];
        if ((p.lat > lat) !== (previous.lat > lat) &&
            lon < (previous.lon - p.lon) * (lat - p.lat) / (previous.lat - p.lat) + p.lon)
            inside = !inside;
    }
    return inside;
}
export function countryAtPoint(countries, position) {
    if (!Number.isFinite(position.lat) || !Number.isFinite(position.lon) || Math.abs(position.lat) > 90 || Math.abs(position.lon) > 180)
        return null;
    let chosen = null;
    for (const country of countries) {
        let parity = 0;
        let area = Infinity;
        for (const ring of country.rings) {
            if (within(ring, position.lat, position.lon)) {
                parity++;
                area = Math.min(area, (ring.maxLat - ring.minLat) * (ring.maxLon - ring.minLon));
            }
        }
        if (parity % 2 === 1 && (!chosen || area < chosen.area))
            chosen = { code: country.code, area };
    }
    return chosen?.code ?? null;
}
