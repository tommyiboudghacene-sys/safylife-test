/** Optional, user-requested observational data from the USGS public GeoJSON feed.
 * NOT emergency warnings, impact forecasts or personalized proximity alerts.
 * Nothing is cached or requested before the user clicks Refresh.
 */
export const USGS_FEED = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson";
export const USGS_HOME = "https://earthquake.usgs.gov/earthquakes/";
function safeEventUrl(value) {
    if (typeof value !== "string")
        return null;
    try {
        const parsed = new URL(value);
        if (parsed.protocol !== "https:" || parsed.hostname !== "earthquake.usgs.gov" ||
            !/^\/earthquakes\/eventpage\/[\w.-]{1,100}\/?$/.test(parsed.pathname) ||
            parsed.username || parsed.password || parsed.search || parsed.hash)
            return null;
        return parsed.href;
    }
    catch {
        return null;
    }
}
export function parseEarthquakeFeed(input, now = Date.now()) {
    if (!input || typeof input !== "object" || !Number.isFinite(now))
        return [];
    const obj = input;
    if (!Array.isArray(obj.features))
        return [];
    const result = [];
    for (const item of obj.features.slice(0, 500)) {
        if (!item || typeof item !== "object")
            continue;
        const feature = item;
        if (!feature.properties || typeof feature.properties !== "object")
            continue;
        const props = feature.properties;
        const url = safeEventUrl(props.url);
        if (props.type !== "earthquake" || typeof props.mag !== "number" || !Number.isFinite(props.mag) || props.mag < 4.5 || props.mag > 10 ||
            typeof props.time !== "number" || !Number.isFinite(props.time) || props.time > now + 600_000 || props.time < now - 8 * 86400_000 ||
            typeof props.place !== "string" || !url)
            continue;
        const place = props.place.trim().slice(0, 125);
        if (!place)
            continue;
        result.push({ place, magnitude: props.mag, at: props.time, url });
    }
    return result.sort((a, b) => b.at - a.at).slice(0, 8);
}
export async function loadEarthquakes(fetcher = fetch) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
        const response = await fetcher(USGS_FEED, { method: "GET", signal: controller.signal, cache: "no-store", redirect: "error" });
        if (!response.ok)
            throw new Error(`HTTP ${response.status}`);
        const len = Number(response.headers.get("content-length"));
        if (len > 3_000_000)
            throw new Error("Feed too large");
        return parseEarthquakeFeed(await response.json());
    }
    finally {
        clearTimeout(timeout);
    }
}
