import { botAction, cardName, createMatch, drawAndPass, ELEMENTS, isPlayable, playCard, topCard } from "./card-core.js";
import { html, mount } from "./ui.js";
const STATS_KEY = "resilience-pocket:duel-stats:1";
let match = null;
let pendingJoker = null;
let recorded = null;
let timer = null;
let stats = { wins: 0, losses: 0, draws: 0 };
try {
    const data = JSON.parse(localStorage.getItem(STATS_KEY) ?? "null");
    if (data && ["wins", "losses", "draws"].every(key => Number.isInteger(data[key]) && data[key] >= 0 && data[key] < 1000000)) {
        stats = { wins: data.wins, losses: data.losses, draws: data.draws };
    }
}
catch { /* Some local-file browsers disable storage. */ }
function saveResult(state) {
    if (!state.winner || recorded === state)
        return;
    recorded = state;
    if (state.winner === "human")
        stats.wins++;
    else if (state.winner === "bot")
        stats.losses++;
    else
        stats.draws++;
    try {
        localStorage.setItem(STATS_KEY, JSON.stringify(stats));
    }
    catch { /* session only */ }
}
function cardSymbol(card) {
    if (card.kind === "wild")
        return "🌈";
    if (card.kind === "pause")
        return "⏸";
    if (card.kind === "plus2")
        return "+2";
    return String(card.value);
}
function renderFace(card, interactive, canPlay) {
    const theme = ELEMENTS.find(e => e.id === card.element);
    const style = "color:" + (theme?.color ?? "#6850a1");
    const symbol = cardSymbol(card);
    const label = cardName(card);
    return html `<button type="button" class="rp-duel-card ${card.kind === "wild" ? "is-wild" : ""} ${canPlay ? "is-playable" : ""}"
    style="${style}" aria-label="${label}" data-duel-card="${interactive ? card.id : ""}" ${!interactive || !canPlay ? "disabled" : ""}>
    <span class="rp-duel-card-corner">${symbol}</span><span class="rp-duel-card-center" aria-hidden="true">${symbol}</span>
    <span class="rp-duel-card-theme">${theme?.icon ?? "🌈"} ${theme?.name ?? "Joker"}</span>
  </button>`;
}
export function renderCardDuel(root) {
    if (!match)
        match = createMatch();
    const state = match;
    saveResult(state);
    if (timer !== null) {
        window.clearTimeout(timer);
        timer = null;
    }
    const humanTurn = state.turn === "human" && !state.winner;
    const botTurn = state.turn === "bot" && !state.winner;
    const top = topCard(state);
    const element = ELEMENTS.find(e => e.id === state.activeElement);
    mount(root, html `
    <section class="rp-page-lead rp-duel-title"><a href="#/drill" class="rp-back">← Tous les jeux</a><span class="rp-eyebrow">🎴 Grand jeu · Sans Internet</span>
      <h1>Duel des éléments</h1><p>Un vrai duel de cartes contre un rival qui joue sur ton téléphone. Chaque manche est différente !</p></section>
    <section class="rp-duel-stats"><span>🏆 ${stats.wins} victoire(s)</span><span>🤖 ${stats.losses} défaite(s)</span><span>🤝 ${stats.draws} égalité(s)</span></section>
    <section class="rp-duel-table" aria-label="Table de jeu">
      <div class="rp-duel-opponent"><span class="rp-duel-avatar" aria-hidden="true">🤖</span><div><strong>Le rival</strong>
        <small>${state.hands.bot.length} carte(s) en main</small></div><span class="rp-duel-turn ${botTurn ? "is-active" : ""}">${botTurn ? "Il réfléchit…" : "En attente"}</span></div>
      <div class="rp-duel-board"><div class="rp-duel-pile"><span class="rp-duel-pile-label">Carte posée</span>${renderFace(top, false, false)}</div>
        <div class="rp-duel-current-element"><span>Couleur à suivre</span><strong style="color:${element.color}">${element.icon} ${element.name}</strong>
          <button id="rp-duel-draw" type="button" class="rp-duel-draw" ${!humanTurn || pendingJoker !== null ? "disabled" : ""}>🂠 Piocher et passer</button></div></div>
      <div class="rp-duel-message" role="status" aria-live="polite">${state.note}</div>
      ${pendingJoker !== null && humanTurn ? html `<div class="rp-duel-color-picker">
        <h2>🌈 Choisis une couleur pour ton joker</h2><div class="rp-duel-color-grid">${ELEMENTS.map(suit => html `<button type="button" data-duel-element="${suit.id}" style="--choice-color:${suit.color}">${suit.icon} ${suit.name}</button>`)}</div>
        <button type="button" class="btn" id="rp-duel-cancel">Annuler</button></div>` : ""}
      ${state.winner ? html `<div class="rp-duel-finish"><h2>${state.winner === "human" ? "🏆 Bravo, tu as gagné !" : state.winner === "bot" ? "🤖 Le rival a gagné !" : "🤝 Égalité !"}</h2>
        <p>${state.turns} coups joués. Tu peux recommencer autant de fois que tu veux.</p><button class="btn primary" id="rp-duel-restart">🔁 Nouvelle manche</button></div>` : ""}
      <div class="rp-duel-player"><div><strong>🧑 Tes cartes</strong><small>${state.hands.human.length} carte(s) · ${humanTurn ? "À toi de jouer !" : "Patiente un instant"}</small></div>
        <div class="rp-duel-hand" aria-label="Tes cartes">${state.hands.human.map(card => renderFace(card, true, humanTurn && isPlayable(state, card) && pendingJoker === null))}</div></div>
    </section>
    <details class="rp-duel-rules"><summary>📖 Comment jouer ?</summary><p>Pose une carte de même <strong>couleur</strong>, de même <strong>numéro</strong> ou de même <strong>symbole</strong>.</p>
      <p>⏸ Pause : ton rival saute un tour. <strong>+2</strong> : il prend deux cartes et saute son tour. 🌈 Joker : choisis la nouvelle couleur.</p>
      <p>Tu peux piocher et passer si tu ne veux pas jouer. Le premier à poser toutes ses cartes gagne. Ces règles sont celles de Duel des éléments, pas celles d'un autre jeu.</p></details>
    <p class="rp-small-print">Jeu de cartes original et local : le rival, les cartes et les résultats fonctionnent sans connexion ni compte. Ce jeu est un divertissement, pas une formation aux gestes de secours.</p>`);
    root.querySelectorAll("[data-duel-card]").forEach(button => {
        button.addEventListener("click", () => {
            if (!match || !humanTurn || pendingJoker !== null)
                return;
            const id = Number(button.dataset.duelCard);
            const card = match.hands.human.find(c => c.id === id);
            if (!card)
                return;
            if (card.kind === "wild")
                pendingJoker = id;
            else
                playCard(match, "human", id);
            renderCardDuel(root);
        });
    });
    root.querySelectorAll("[data-duel-element]").forEach(button => {
        button.addEventListener("click", () => {
            if (!match || pendingJoker === null)
                return;
            const chosen = button.dataset.duelElement;
            if (playCard(match, "human", pendingJoker, chosen))
                pendingJoker = null;
            renderCardDuel(root);
        });
    });
    root.querySelector("#rp-duel-cancel")?.addEventListener("click", () => {
        pendingJoker = null;
        renderCardDuel(root);
    });
    root.querySelector("#rp-duel-draw")?.addEventListener("click", () => {
        if (match && pendingJoker === null)
            drawAndPass(match, "human");
        renderCardDuel(root);
    });
    root.querySelector("#rp-duel-restart")?.addEventListener("click", () => {
        match = createMatch();
        pendingJoker = null;
        renderCardDuel(root);
    });
    if (botTurn) {
        timer = window.setTimeout(() => {
            timer = null;
            if (!root.isConnected || !location.hash.startsWith("#/game/cards") || !match || match !== state || state.turn !== "bot" || state.winner)
                return;
            botAction(match);
            renderCardDuel(root);
        }, 680);
    }
}
