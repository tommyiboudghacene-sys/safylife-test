import { SCENARIOS } from "../engine/index.js";
import { ANSWERS, buildDrill } from "../engine/drills.js";
import { html, mount } from "./ui.js";
const STORAGE_KEY = "resilience-pocket:games:fr:2";
const emptyScores = () => ({
    chrono: { attempts: 0, best: 0 }, kit: { attempts: 0, best: 0 }, decision: { attempts: 0, best: 0 },
});
let scores = emptyScores();
try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null");
    if (saved && typeof saved === "object") {
        for (const key of ["chrono", "kit", "decision"]) {
            if (saved[key] && Number.isFinite(saved[key]?.best) && Number.isFinite(saved[key]?.attempts)) {
                scores[key] = { attempts: saved[key].attempts, best: saved[key].best };
            }
        }
    }
}
catch { /* file:// may block localStorage; in-memory progress still works */ }
function record(key, points) {
    scores[key].attempts += 1;
    scores[key].best = Math.max(scores[key].best, points);
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(scores));
    }
    catch { /* see above */ }
}
export function exportGameScores() { return JSON.parse(JSON.stringify(scores)); }
export function importGameScores(input) {
    if (!input || typeof input !== "object")
        return;
    const next = input;
    for (const key of ["chrono", "kit", "decision"]) {
        const data = next[key];
        if (data && Number.isInteger(data.attempts) && data.attempts >= 0 && Number.isFinite(data.best) && data.best >= 0 && data.best <= 100) {
            scores[key] = { attempts: data.attempts, best: data.best };
        }
    }
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(scores));
    }
    catch { /* see above */ }
}
const GAMES = [
    { id: "chrono", icon: "⏱️", title: "Le compte à rebours", description: "Devine ce qui pourrait manquer en premier à la maison.", max: 100, tag: "Je devine" },
    { id: "kit", icon: "🎒", title: "Le défi du sac", description: "Choisis les 8 objets les plus utiles pour ton sac.", max: 100, tag: "Je choisis" },
    { id: "decision", icon: "🧭", title: "À toi de choisir !", description: "Trois histoires : que ferais-tu pour rester en sécurité ?", max: 60, tag: "Je réfléchis" },
];
export function renderJeux(root, demo) {
    mount(root, html `
    <section class="feature-intro">
      <a href="#/" class="rp-back">← Accueil</a>
      <div class="feature-kicker">2 grands jeux + 3 défis + 3 aventures</div>
      <h1>À toi de jouer ! 🎮</h1>
      <p class="muted">Envie d'une vraie partie de cartes ou d'un jeu rapide ? Choisis ! Tout fonctionne même sans Internet après installation.</p>
      ${demo ? html `<p class="feature-note">Pour le premier jeu, un foyer fictif est utilisé. <a href="#/setup">Personnaliser mon foyer</a>.</p>` : ""}
    </section>
    <section class="rp-big-games" aria-label="Grands jeux sans connexion">
      <a class="rp-big-game rp-big-game--cards" href="#/game/cards"><span class="rp-big-game-art" aria-hidden="true">🎴</span><span class="rp-tag">⭐ Nouveau · Grande partie</span>
        <h2>Duel des éléments</h2><p>Un duel de cartes colorées contre un rival dans ton téléphone. Pose les bonnes cartes, bloque ton adversaire et gagne la manche !</p><strong>Jouer aux cartes →</strong></a>
      <a class="rp-big-game rp-big-game--memory" href="#/game/memory"><span class="rp-big-game-art" aria-hidden="true">🧠</span><span class="rp-tag">⭐ Nouveau · 3 niveaux</span>
        <h2>Mémoire 72h</h2><p>Retourne les cartes pour retrouver les paires. De 12 à 24 cartes, rejoue pour battre ton record !</p><strong>Jouer au memory →</strong></a>
    </section>
    <h2 class="rp-other-games-title">Les 3 défis pour apprendre</h2>
    <section class="rp-game-grid">
      ${GAMES.map((g) => html `
        <a class="card rp-game-card" href="#/game/${g.id}">
          <div class="rp-game-emoji" aria-hidden="true">${g.icon}</div>
          <span class="rp-tag">${g.tag}</span>
          <h2>${g.title}</h2>
          <p>${g.description}</p>
          <div class="rp-game-bottom"><strong>C'est parti ! <span aria-hidden="true">→</span></strong><span>Meilleur score : ${scores[g.id].best}/${g.max}</span></div>
        </a>`)}
    </section>
    <section class="rp-adventure-game-link"><span aria-hidden="true">🌙</span><div><span class="rp-eyebrow">Le grand jeu</span><h2>Ma famille, 72 heures</h2><p>Trois aventures avec des conséquences différentes selon tes décisions et ton équipement.</p></div><a class="btn primary" href="#/aventures">Découvrir →</a></section>
    <section class="card rp-footnote">
      <h2>💡 L'important, c'est d'apprendre</h2>
      <p>Après chaque réponse, on t'explique pourquoi. Les points sont un jeu : ils ne disent pas si tu es en sécurité dans la vraie vie.</p>
    </section>`);
}
export function renderChrono(root, plan, selected) {
    const id = SCENARIOS.some((s) => s.id === selected) ? selected : "power";
    const drill = buildDrill(plan, id);
    mount(root, html `
    <section class="rp-game-top"><a href="#/drill">← Tous les jeux</a><span class="rp-tag">Jeu 1 · Chrono-crise</span></section>
    <section class="card rp-game-stage">
      <div class="rp-big-icon" aria-hidden="true">⏱️</div>
      <h1>Le compte à rebours</h1>
      <label class="rp-select-label">Choisis une situation
        <select id="chrono-scenario">${SCENARIOS.map((s) => html `<option value="${s.id}" ${s.id === id ? "selected" : ""}>${buildDrill(plan, s.id).scenarioName}</option>`)}</select>
      </label>
      <p class="muted">Durée étudiée : ${drill.durationHours} heures. Quand apparaîtrait la première rupture d'un besoin essentiel selon ton inventaire ?</p>
      <div class="rp-choices">${ANSWERS.map(a => html `<button class="rp-choice" data-chrono="${a.id}">${a.label}</button>`)}</div>
      <div id="chrono-result" class="rp-feedback" hidden></div>
    </section>`);
    root.querySelector("#chrono-scenario")?.addEventListener("change", e => {
        location.hash = `#/game/chrono/${e.target.value}`;
    });
    root.querySelectorAll("[data-chrono]").forEach(b => b.addEventListener("click", () => {
        const good = b.dataset.chrono === drill.correct;
        record("chrono", good ? 100 : 0);
        root.querySelectorAll("[data-chrono]").forEach(option => {
            option.disabled = true;
            option.classList.toggle("correct", option.dataset.chrono === drill.correct);
            option.classList.toggle("chosen", option === b);
        });
        const area = root.querySelector("#chrono-result");
        area.hidden = false;
        mount(area, html `
      <h2>${good ? "🎯 Bonne intuition ! +100 points" : "💡 Une information à retenir"}</h2>
      <p>${drill.explanation}</p>
      <p class="hint">Le modèle suppose que les ressources déclarées sont réellement disponibles. Il ne prédit pas les événements ni leur dangerosité.</p>
      <div class="btn-row"><a class="btn primary" href="#/scenario/${id}">Comprendre cette simulation</a><a class="btn" href="#/drill">Autre jeu</a></div>`);
    }));
}
const ITEMS = [
    { id: "water", icon: "💧", label: "Eau potable", important: true, why: "Une réserve d'eau est prioritaire." },
    { id: "radio", icon: "📻", label: "Radio à piles et piles", important: true, why: "Permet de suivre les consignes officielles hors réseau." },
    { id: "food", icon: "🥫", label: "Aliments sans cuisson", important: true, why: "Aide à tenir pendant une interruption des services." },
    { id: "light", icon: "🔦", label: "Lampe et piles", important: true, why: "Éclaire sans électricité." },
    { id: "meds", icon: "💊", label: "Traitements personnels", important: true, why: "Les besoins de santé propres au foyer sont essentiels." },
    { id: "papers", icon: "📄", label: "Copies de documents", important: true, why: "Facilite les démarches et l'identification." },
    { id: "aid", icon: "🩹", label: "Trousse de secours", important: true, why: "Permet de disposer du matériel de premiers soins." },
    { id: "clothes", icon: "🧥", label: "Vêtements chauds et couverture", important: true, why: "Aide à se protéger des conditions météo." },
    { id: "console", icon: "🎮", label: "Console de jeu", important: false, why: "Moins prioritaire que les besoins vitaux dans un sac limité." },
    { id: "perfume", icon: "🌸", label: "Parfum", important: false, why: "N'est pas une priorité de protection." },
    { id: "hairdryer", icon: "💨", label: "Sèche-cheveux", important: false, why: "Dépend du courant et prend de la place." },
    { id: "decoration", icon: "🖼️", label: "Objet décoratif", important: false, why: "N'aide pas à faire face à une coupure." },
];
export function renderKit(root) {
    const selected = new Set();
    mount(root, html `
    <section class="rp-game-top"><a href="#/drill">← Tous les jeux</a><span class="rp-tag">Jeu 2 · Sac 72 h</span></section>
    <section class="card rp-game-stage">
      <div class="rp-big-icon" aria-hidden="true">🎒</div>
      <h1>8 places dans ton sac</h1>
      <p class="muted">Choisis huit catégories prioritaires parmi ces douze propositions. C'est un jeu de classement : en vrai, adapte toujours ton kit aux personnes et aux consignes locales.</p>
      <div class="rp-kit-meter"><span id="kit-count">0 / 8 éléments</span><div class="meter"><i id="kit-fill" style="width:0%"></i></div></div>
      <div class="rp-kit-grid">${ITEMS.map((item) => html `<button type="button" class="rp-kit-item" data-kit="${item.id}" aria-pressed="false"><span class="rp-kit-icon" aria-hidden="true">${item.icon}</span>${item.label}</button>`)}</div>
      <button type="button" class="btn primary block" id="kit-check" disabled>Valider mon sac</button>
      <div class="rp-feedback" id="kit-result" hidden></div>
    </section>`);
    const confirm = root.querySelector("#kit-check");
    root.querySelectorAll("[data-kit]").forEach(button => button.addEventListener("click", () => {
        const id = button.dataset.kit;
        if (selected.has(id))
            selected.delete(id);
        else if (selected.size < 8)
            selected.add(id);
        button.classList.toggle("chosen", selected.has(id));
        button.setAttribute("aria-pressed", String(selected.has(id)));
        root.querySelector("#kit-count").textContent = `${selected.size} / 8 éléments`;
        root.querySelector("#kit-fill").style.width = `${selected.size / 8 * 100}%`;
        confirm.disabled = selected.size !== 8;
    }));
    confirm.addEventListener("click", () => {
        const good = ITEMS.filter(x => x.important && selected.has(x.id)).length;
        const score = Math.round(good / 8 * 100);
        record("kit", score);
        confirm.disabled = true;
        root.querySelectorAll("[data-kit]").forEach(b => {
            b.disabled = true;
            b.classList.toggle("correct", ITEMS.some(x => x.id === b.dataset.kit && x.important));
        });
        const result = root.querySelector("#kit-result");
        result.hidden = false;
        mount(result, html `
      <h2>🎒 Score : ${score}/100</h2>
      <p>${good} catégories essentielles sur 8 sélectionnées.</p>
      <ul class="rp-answer-list">${ITEMS.filter(x => x.important).map(x => html `<li>${x.label} — ${x.why}</li>`)}</ul>
      <p class="hint">Source : <a href="https://www.securite-civile.interieur.gouv.fr/reagir/comment-se-preparer-face-aux-risques/kit-durgence" target="_blank" rel="noopener noreferrer">Sécurité civile, kit d'urgence 72 h</a>. Liste simplifiée pour ce jeu, non exhaustive.</p>
      <a class="btn" href="#/drill">Choisir un autre jeu</a>`);
    });
}
const SEQUENCES = {
    conflict: {
        title: "Conflit : protéger les civils", icon: "🛡️",
        source: "https://www.interieur.gouv.fr/documentation/ressources/guide-tous-responsables.html",
        scenes: [
            { question: "Une alerte officielle demande de rester à l'abri dans un bâtiment sûr. Que fais-tu ?", choices: ["Je pars au hasard sur la route", "Je respecte la mise à l'abri et écoute les instructions", "Je vais filmer dehors"], answer: 1, reason: "Les consignes officielles de sauvegarde dépendent de la nature et de la localisation du danger." },
            { question: "Le réseau mobile et Internet sont interrompus. Quelle ressource prévue est utile ?", choices: ["Une radio autonome et un plan familial sur papier", "Les rumeurs non vérifiées", "Appeler sans arrêt tous mes contacts"], answer: 0, reason: "Une radio et un plan convenu à l'avance aident à recevoir les informations et retrouver ses proches." },
            { question: "Les autorités ordonnent une évacuation avec itinéraire indiqué. Quelle décision privilégier ?", choices: ["Improviser un raccourci inconnu", "Attendre que quelqu'un publie une vidéo", "Suivre les consignes et l'itinéraire officiel si praticable"], answer: 2, reason: "L'application ne connaît pas les conditions sur le terrain : les instructions officielles restent prioritaires." },
        ],
    },
    flood: {
        title: "Inondation : éviter les pièges", icon: "🌧️",
        source: "https://www.securite-civile.interieur.gouv.fr/reagir/comment-se-preparer-face-aux-risques",
        scenes: [
            { question: "La route devant toi est recouverte d'eau de crue. Quelle action ?", choices: ["Faire demi-tour vers un lieu sûr", "Traverser vite en voiture", "Marcher dans l'eau pour mesurer"], answer: 0, reason: "L'eau peut cacher des courants, trous ou obstacles ; ne la traverse pas." },
            { question: "Une évacuation officielle est annoncée. Que fais-tu ?", choices: ["Je reste pour regarder l'eau monter", "Je suis les instructions des autorités", "Je pars sans prévenir avec un trajet improvisé"], answer: 1, reason: "Les consignes officielles indiquent la réponse adaptée à la situation locale." },
            { question: "Le courant coupe. Où faire fonctionner un groupe électrogène ?", choices: ["Dans le salon", "Dans le garage fermé", "Dehors, loin des ouvertures"], answer: 2, reason: "Les gaz de combustion présentent un risque mortel d'intoxication au monoxyde de carbone." },
        ],
    },
    power: {
        title: "Panne : décisions en chaîne", icon: "🔦",
        source: "https://www.ready.gov/power-outages",
        scenes: [
            { question: "Tu veux utiliser un réchaud à combustible. Où l'utiliser ?", choices: ["À l'intérieur fenêtres fermées", "Dehors, dans des conditions sûres", "Dans une petite pièce ventilée"], answer: 1, reason: "Les appareils à combustion présentent un danger de monoxyde de carbone en espace clos." },
            { question: "Le réfrigérateur n'est plus alimenté. Première bonne habitude ?", choices: ["Le laisser fermé autant que possible", "Ouvrir pour vérifier chaque minute", "Le réchauffer avec une flamme"], answer: 0, reason: "Limiter les ouvertures conserve plus longtemps le froid restant." },
            { question: "Le réseau mobile est saturé et ta batterie diminue. Que faire ?", choices: ["Diffuser des rumeurs", "Laisser l'écran allumé", "Économiser la batterie et utiliser le plan de communication"], answer: 2, reason: "La préparation et la sobriété d'énergie prolongent les possibilités de contact." },
        ],
    },
};
let session = { kind: "", index: 0, score: 0 };
export function renderDecisions(root, kind = "conflict") {
    const key = kind in SEQUENCES ? kind : "conflict";
    const data = SEQUENCES[key];
    if (session.kind !== key)
        session = { kind: key, index: 0, score: 0 };
    const scene = data.scenes[session.index];
    mount(root, html `
    <section class="rp-game-top"><a href="#/drill">← Tous les jeux</a><span class="rp-tag">Jeu 3 · Décisions critiques</span></section>
    <section class="card rp-game-stage">
      <div class="rp-big-icon" aria-hidden="true">${data.icon}</div>
      <h1>${data.title}</h1>
      <div class="rp-switches">
        ${Object.entries(SEQUENCES).map(([id, value]) => html `<button type="button" class="rp-switch ${key === id ? "active" : ""}" data-scene="${id}">${value.icon} ${value.title.split(" : ")[0]}</button>`)}
      </div>
      ${scene ? html `
        <p class="rp-progress-label">Situation ${session.index + 1} / ${data.scenes.length} · ${session.score} point(s)</p>
        <div class="meter"><i style="width:${session.index / data.scenes.length * 100}%"></i></div>
        <h2>${scene.question}</h2>
        <div class="rp-choices">${scene.choices.map((choice, i) => html `<button type="button" class="rp-choice" data-decision="${i}">${choice}</button>`)}</div>
        <div class="rp-feedback" id="decision-feedback" hidden></div>` : html `
        <h2>Partie terminée !</h2>
        <p class="rp-final-score">${session.score} / 60 points</p>
        <p>Une bonne décision dans un jeu ne remplace jamais les instructions officielles.</p>
        <div class="btn-row"><button class="btn primary" id="decision-replay">Rejouer</button><a class="btn" href="#/drill">Autres jeux</a></div>`}
      <p class="hint rp-game-source">Référence : <a href="${data.source}" target="_blank" rel="noopener noreferrer">consignes officielles de préparation</a> (lien accessible avec Internet).</p>
    </section>`);
    root.querySelectorAll("[data-scene]").forEach(button => button.addEventListener("click", () => {
        const next = button.dataset.scene;
        session = { kind: next, index: 0, score: 0 };
        location.hash = `#/game/decision/${next}`;
        if (next === key)
            renderDecisions(root, key);
    }));
    root.querySelector("#decision-replay")?.addEventListener("click", () => {
        session = { kind: key, index: 0, score: 0 };
        renderDecisions(root, key);
    });
    root.querySelectorAll("[data-decision]").forEach(button => button.addEventListener("click", () => {
        if (!scene)
            return;
        const correct = Number(button.dataset.decision) === scene.answer;
        if (correct)
            session.score += 20;
        root.querySelectorAll("[data-decision]").forEach(b => {
            b.disabled = true;
            b.classList.toggle("correct", Number(b.dataset.decision) === scene.answer);
            b.classList.toggle("chosen", b === button);
        });
        const area = root.querySelector("#decision-feedback");
        area.hidden = false;
        mount(area, html `
      <h3>${correct ? "✅ Bonne décision ! +20" : "💡 À retenir"}</h3>
      <p>${scene.reason}</p>
      <button type="button" class="btn primary" id="decision-next">${session.index + 1 === data.scenes.length ? "Voir mon résultat" : "Situation suivante"}</button>`);
        root.querySelector("#decision-next")?.addEventListener("click", () => {
            session.index += 1;
            if (session.index === data.scenes.length)
                record("decision", session.score);
            renderDecisions(root, key);
        });
    }));
}
