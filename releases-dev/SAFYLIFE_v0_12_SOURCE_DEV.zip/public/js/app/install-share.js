let deferredPrompt = null;
let installedThisSession = false;
/** An installed PWA requires a secure origin (localhost is allowed for development). */
export function isEligibleInstallOrigin(protocol, hostname, standalone) {
    if (standalone)
        return false;
    return protocol === "https:" || (protocol === "http:" &&
        (hostname === "localhost" || hostname === "127.0.0.1" || hostname === "[::1]"));
}
export function canOfferInstall() {
    return isEligibleInstallOrigin(location.protocol, location.hostname, document.body.dataset.mode === "standalone");
}
function alreadyInstalled() {
    const iosStandalone = navigator.standalone === true;
    return installedThisSession || iosStandalone || !!window.matchMedia?.("(display-mode: standalone)")?.matches;
}
export function initInstallSharing() {
    window.addEventListener("beforeinstallprompt", e => {
        e.preventDefault();
        deferredPrompt = e;
    });
    window.addEventListener("appinstalled", () => {
        installedThisSession = true;
        deferredPrompt = null;
        const state = document.getElementById("rp-app-install-state");
        if (state)
            state.textContent = "SAFYLIFE installée sur cet appareil.";
    });
}
export function setupInstallSharing(root) {
    const install = root.querySelector("#rp-app-install");
    const share = root.querySelector("#rp-app-share");
    const state = root.querySelector("#rp-app-install-state");
    if (!install || !share || !state)
        return;
    if (!canOfferInstall()) {
        install.hidden = true;
        share.hidden = true;
        return;
    }
    if (alreadyInstalled()) {
        install.hidden = true;
        state.textContent = "Application installée : conserve-la pour tes préparatifs.";
    }
    install.addEventListener("click", async () => {
        if (deferredPrompt) {
            const prompt = deferredPrompt;
            deferredPrompt = null;
            try {
                await prompt.prompt();
                const choice = await prompt.userChoice;
                state.textContent = choice.outcome === "accepted"
                    ? "Installation demandée : vérifie ton écran d’accueil."
                    : "Installation annulée. Tu pourras l’ajouter plus tard.";
            }
            catch {
                state.textContent = "Ouvre le menu de ton navigateur puis « Installer l’application » ou « Ajouter à l’écran d’accueil ».";
            }
        }
        else {
            state.textContent = "Sur Android : menu ⋮ du navigateur → Installer l’application. Sur iPhone : Partager → Sur l’écran d’accueil.";
        }
    });
    share.addEventListener("click", async () => {
        const url = `${location.origin}${location.pathname}`;
        const message = "SAFYLIFE : une application gratuite pour préparer ses proches aux catastrophes. Installe-la avant d’en avoir besoin.";
        try {
            if (typeof navigator.share === "function") {
                await navigator.share({ title: "SAFYLIFE", text: message, url });
                state.textContent = "Choisis toi-même à qui partager SAFYLIFE.";
            }
            else if (navigator.clipboard?.writeText) {
                await navigator.clipboard.writeText(`${message}\n${url}`);
                state.textContent = "Lien copié. Tu peux maintenant le partager avec tes proches.";
            }
            else {
                state.textContent = `Copie ce lien et envoie-le à tes proches : ${url}`;
            }
        }
        catch {
            state.textContent = "Partage annulé ou indisponible. Rien n’a été envoyé automatiquement.";
        }
    });
}
