"""Real-browser PWA test: real HTTP server, real service worker, real offline mode.
Usage: python3 -I pwa_real.py <public_dir> <port>
Not a physical-device test.
"""
import subprocess, sys, json, time
from playwright.sync_api import sync_playwright

ROOT, PORT = sys.argv[1], sys.argv[2]
AXE = (__import__('pathlib').Path(__file__).resolve().parent.parent / 'node_modules/axe-core/axe.min.js').read_text(encoding='utf-8')
ROUTES = ['#/', '#/terrain', '#/secours', '#/monde', '#/setup', '#/guide', '#/checklist',
          '#/missions', '#/drill', '#/simulations', '#/data', '#/print', '#/essai', '#/aventures']
server = subprocess.Popen([sys.executable, '-m', 'http.server', PORT, '--bind', '127.0.0.1', '--directory', ROOT],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
report = {}
try:
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=__import__('os').environ.get('CHROME','/usr/bin/chromium'), headless=True,
                              args=['--no-sandbox', '--disable-dev-shm-usage', '--no-proxy-server'])
        c = b.new_context(viewport={'width': 390, 'height': 844}, service_workers='allow', locale='fr-FR')
        page = c.new_page()
        errs, cons = [], []
        page.on('pageerror', lambda e: errs.append(str(e)))
        page.on('console', lambda m: cons.append(f'{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
        page.goto(f'http://127.0.0.1:{PORT}/', wait_until='load', timeout=20000)
        page.wait_for_function('() => navigator.serviceWorker && navigator.serviceWorker.controller', timeout=20000)
        report['sw_controlled'] = True
        report['manifest'] = page.evaluate("""async () => { const l=document.querySelector('link[rel=manifest]');
            if(!l) return null; const r=await fetch(l.href); return await r.json(); }""")
        report['cache'] = page.evaluate("""async () => { const out={}; for (const k of await caches.keys()) {
            const c=await caches.open(k); out[k]=(await c.keys()).length; } return out; }""")
        # Go offline and test every route after a full reload
        c.set_offline(True)
        page.reload(wait_until='load', timeout=15000)
        offline = {}
        for r in ROUTES:
            page.evaluate('(r)=>{location.hash=r;window.dispatchEvent(new Event("hashchange"))}', r)
            page.wait_for_timeout(150)
            txt = page.locator('#main').inner_text().strip()
            offline[r] = len(txt)
        report['offline_route_text_len'] = offline
        # New tab, cold start offline
        p2 = c.new_page()
        p2.goto(f'http://127.0.0.1:{PORT}/#/terrain', wait_until='load', timeout=15000)
        p2.wait_for_timeout(500)
        report['cold_offline_sos_len'] = len(p2.locator('#main').inner_text())
        # Accessibility on key routes, 3 languages via home toggle not assumed -> FR only here
        axe_res = {}
        for r in ['#/', '#/terrain', '#/secours', '#/monde', '#/setup', '#/checklist']:
            page.evaluate('(r)=>{location.hash=r;window.dispatchEvent(new Event("hashchange"))}', r)
            page.wait_for_timeout(200)
            page.evaluate(AXE)
            res = page.evaluate("""async () => { const r = await axe.run(document, {resultTypes:['violations']});
                return r.violations.map(v => ({id:v.id, impact:v.impact, n:v.nodes.length,
                    sample:v.nodes.slice(0,3).map(n=>n.target.join(' ')+' :: '+(n.failureSummary||'').slice(0,160))})); }""")
            axe_res[r] = res
        report['axe'] = axe_res
        report['html_lang'] = page.evaluate('document.documentElement.lang')
        report['page_errors'] = errs
        report['console'] = cons[:30]
        b.close()
finally:
    server.terminate(); server.wait()
print(json.dumps(report, ensure_ascii=False, indent=1))
