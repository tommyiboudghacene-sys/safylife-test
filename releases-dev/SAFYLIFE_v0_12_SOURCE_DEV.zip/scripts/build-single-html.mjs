/**
 * SAFYLIFE offline single-file builder.
 * Uses TypeScript's CommonJS transpiler to bundle local TS modules without
 * installing an extra bundler; produces a static script, no eval or remote assets.
 */
import { readFileSync, writeFileSync, readdirSync, statSync } from "node:fs";
import { resolve, dirname, relative, sep } from "node:path";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
let ts;
try { ts = require("typescript"); }
catch {
  // A system-installed tsc can build in restricted/offline environments.
  const globalTs = resolve(dirname(process.execPath), "../lib/node_modules/typescript");
  ts = require(globalTs);
}
function recurse(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap(entry =>
    entry.isDirectory() ? recurse(resolve(dir, entry.name)) : entry.name.endsWith(".ts") ? [resolve(dir, entry.name)] : []);
}
const sourceRoot = resolve("src");
const modules = recurse(sourceRoot).map(file => {
  const id = "/" + relative(sourceRoot, file).split(sep).join("/").replace(/\.ts$/, ".js");
  const compiled = ts.transpileModule(readFileSync(file, "utf8"), {
    fileName: file,
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, removeComments: true },
    reportDiagnostics: true,
  });
  const errors = (compiled.diagnostics || []).filter(d => d.category === ts.DiagnosticCategory.Error);
  if (errors.length) throw new Error(`Could not transpile ${id}: ${errors.map(e => e.messageText).join(" ")}`);
  return `${JSON.stringify(id)}: function(module, exports, require) {\n${compiled.outputText}\n}`;
});
const bundled = `(function(){
"use strict";
const modules = {${modules.join(",\n")}};
const cache = Object.create(null);
function run(id) {
  if (!Object.prototype.hasOwnProperty.call(modules, id)) throw new Error("Missing SAFYLIFE module: " + id);
  if (cache[id]) return cache[id].exports;
  const module = { exports: {} }; cache[id] = module;
  modules[id](module, module.exports, name => {
    if (!name.startsWith(".")) throw new Error("Unexpected external module: " + name);
    const resolved = new URL(name, "https://safylife.invalid" + id).pathname;
    return run(resolved);
  });
  return module.exports;
}
run("/app/fr-main.js");
})();`;
let page = readFileSync("public/index.html", "utf8");
// The PWA CSP forbids inline scripts; the standalone file is inline by design, so drop it there.
page = page.replace(/^\s*<meta http-equiv="Content-Security-Policy"[^>]*>\r?\n/m, "");
const css = readFileSync("public/styles.css", "utf8");
const world = readFileSync("public/world-shapes.json", "utf8");
const license = readFileSync("LICENSE", "utf8");
function replaceExactlyOnce(pattern, replacement) {
  let count = 0;
  page = page.replace(pattern, () => { count++; return replacement; });
  if (count !== 1) throw new Error(`Expected one HTML replacement for ${pattern}; got ${count}`);
}
replaceExactlyOnce(/<link rel="stylesheet" href="styles\.css">/, `<style>\n${css}\n</style>`);
replaceExactlyOnce(/<script type="module" src="js\/app\/fr-main\.js"><\/script>/, `<script>\n${bundled.replace(/<\/script/gi,"<\\/script")}\n</script>`);
replaceExactlyOnce(/<\/head>/, `<script id="rp-world-data" type="application/json">${world.replace(/<\/script/gi,"<\\/script")}</script>\n</head>`);
page = page.replace(/^\s*<link rel="(?:manifest|icon|apple-touch-icon)"[^>]*>\r?\n/gm, "");
replaceExactlyOnce(/<body>/, `<body data-mode="standalone">`);
replaceExactlyOnce(/<span class="offline-badge" id="offline-badge" hidden>Hors connexion<\/span>/, `<span class="offline-badge" id="offline-badge">Application autonome</span>`);
replaceExactlyOnce(/<\/head>/, `<!-- Code d'origine sous licence MIT. ${license.replace(/-->/g,"-- >")} -->\n</head>`);
replaceExactlyOnce(/<\/body>/, `<script>if(location.protocol==='file:'){const b=document.getElementById('offline-badge');if(b){b.textContent='Guides enregistrés';b.hidden=false;}}</script></body>`);
const external = page.match(/<script\b[^>]*\bsrc=|<link\b[^>]*\bhref=|<img\b[^>]*\bsrc=/i);
if (external) throw new Error(`Unexpected external dependency: ${external[0]}`);
const dest = resolve("..", "SAFYLIFE_autonome.html");
writeFileSync(dest, page, "utf8");
console.log(`Wrote ${dest} (${Math.round(statSync(dest).size / 1024)} KiB) with ${modules.length} modules.`);
