from playwright.sync_api import sync_playwright
import pathlib
html=pathlib.Path('/mnt/data/SAFYLIFE_v8_autonome.html').read_text()
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium', headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,permissions=['geolocation'],geolocation={'latitude':48.8566,'longitude':2.3522,'accuracy':15})
    page=ctx.new_page()
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded',timeout=18000)
    print('home',page.locator('h1').first.inner_text())
    page.screenshot(path='/mnt/data/safylife_v8_accueil.png')
    page.evaluate('location.hash = "#/terrain"')
    page.wait_for_selector('#rp-terrain-country')
    print('country options',page.locator('#rp-terrain-country option').count())
    page.locator('#rp-terrain-country').select_option('FR')
    assert page.locator('a[href="tel:112"]').count()>0
    page.locator('#rp-terrain-country').select_option('JP')
    assert page.locator('a[href="tel:119"]').count()>0
    assert page.locator('a[href="tel:110"]').count()>0
    page.locator('#rp-terrain-country').select_option('MA')
    assert page.locator('a[href="tel:150"]').count()>0
    page.locator('#rp-terrain-country').select_option('FR')
    page.evaluate("""() => { Object.defineProperty(navigator, 'geolocation', { configurable: true, value: { getCurrentPosition(ok) { ok({coords:{latitude:48.8566,longitude:2.3522,accuracy:15},timestamp:Date.now()}); } } }); }""")
    page.get_by_role('button',name='Relever ma position').click()
    page.wait_for_selector('.rp-coordinates')
    assert '48.85660' in page.locator('.rp-coordinates').inner_text()
    print('location',page.locator('.rp-coordinates').inner_text()[:150])
    page.screenshot(path='/mnt/data/safylife_v8_sos.png')
    # Simulate previously stored location by manually modifying storage then re-render via route
    print('page errors:',errors)
    assert not errors,errors
    b.close()
