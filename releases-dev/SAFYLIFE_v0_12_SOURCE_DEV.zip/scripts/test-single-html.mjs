import assert from 'node:assert/strict';
import { readFileSync, statSync } from 'node:fs';
import { resolve } from 'node:path';

const target = resolve('..', 'SAFYLIFE_autonome.html');
const page = readFileSync(target, 'utf8');
assert.ok(statSync(target).size > 100_000, 'Standalone file is suspiciously small');
assert.match(page, /<title>SAFYLIFE/, 'The application keeps the SAFYLIFE name');
assert.match(page, /id="rp-world-data"/, 'World outlines are embedded');
assert.match(page, /function run\(id\)/, 'The application modules are embedded');
assert.match(page, /rp-terrain-country/, 'Country selection is available offline');
assert.match(page, /rp-safety-sos/, 'SOS is visible from the home screen');
assert.match(page, /n'envoie pas automatiquement d'alerte/, 'SOS limitation must be explicit');
assert.doesNotMatch(page, /<script\b[^>]*\bsrc=|<link\b[^>]*\bhref=|<img\b[^>]*\bsrc=/i,
  'Standalone app must not download scripts, images, or stylesheets');
console.log('Standalone HTML integrity: PASS. Actual browser tests run separately.');
