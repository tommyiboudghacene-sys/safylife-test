import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, existsSync, statSync, writeFileSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
const root=process.cwd();
const out=resolve(root,'..');
const candidates = [
  {name:'SAFYLIFE_PWA.zip', files:['public']},
  {name:'SAFYLIFE_PROJET_COMPLET.zip', files:['public','src','tests','scripts','README.md','NOTICES.md','ETAT-DU-PROJET.md','SAFYLIFE_TESTS_ET_LIMITES.md','LICENSE','package.json','package-lock.json','tsconfig.json','tsconfig.test.json','e2e','playwright.config.ts']},
];
for(const item of candidates) {
  const target=join(out,item.name);
  execFileSync('python',['-c', `
import os,sys,zipfile
root=sys.argv[1]; dest=sys.argv[2]; mode=sys.argv[3]
paths = sys.argv[4:]
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name in paths:
  path=os.path.join(root,name)
  if os.path.isdir(path):
   for current,dirs,files in os.walk(path):
    dirs[:]=[d for d in dirs if d not in {'__pycache__','node_modules','.git','build'}]
    for f in sorted(files):
     if f.endswith('.pyc'):continue
     src=os.path.join(current,f)
     arc=os.path.relpath(src,os.path.join(root,'public') if mode=='public' else root)
     z.write(src,arc)
  elif os.path.isfile(path):z.write(path,os.path.basename(path))
with zipfile.ZipFile(dest) as z:
 bad=z.testzip()
 if bad:raise RuntimeError('Bad ZIP entry: '+bad)
 print(mode, len(z.namelist()),'files',os.path.getsize(dest),'bytes')
`,root,target,item.files.length===1?'public':'full',...item.files],{stdio:'inherit'});
}
const files=['SAFYLIFE_autonome.html',...candidates.map(x=>x.name)];
const report={generated_at:new Date().toISOString(),test_source_files:readdirSync(join(root,'tests')).filter(n=>n.endsWith('.test.ts')).length,offline_assets:(readFileSync(join(root,'public/sw.js'),'utf8').match(/const ASSETS = \[([\s\S]*?)\];/)?.[1].match(/"\.\/[^"]+"/g)||[]).length,files:Object.fromEntries(files.map(f=>[f,{sha256:createHash('sha256').update(readFileSync(join(out,f))).digest('hex'),bytes:statSync(join(out,f)).size}]))};
writeFileSync(join(out,'SAFYLIFE_CHECKSUMS.json'),JSON.stringify(report,null,2)+'\n');
console.log('Release integrity manifests written');
