"""SOS/GPS feedback and French-only notice in a real Chromium (GPS simulated).
Usage: python3 -I sos_i18n.py <public_dir> <port> <screenshot_dir>"""
import subprocess, sys, time
from playwright.sync_api import sync_playwright
ROOT, PORT, SHOTS = sys.argv[1], sys.argv[2], sys.argv[3]
s = subprocess.Popen([sys.executable, '-m', 'http.server', PORT, '--bind', '127.0.0.1', '--directory', ROOT], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
GEO = """(mode)=>Object.defineProperty(navigator,'geolocation',{configurable:true,value:{getCurrentPosition(ok,err){
  window.__geoCalled=true;
  setTimeout(()=>{ if(mode==='ok') ok({coords:{latitude:44.04,longitude:1.1,accuracy:20},timestamp:Date.now()});
  else err({code: mode==='denied'?1:mode==='timeout'?3:2}); }, 300);}}})"""
fails = []
def check(cond, msg):
    if not cond: fails.append(msg)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=__import__('os').environ.get('CHROME','/usr/bin/chromium'), headless=True, args=['--no-sandbox', '--no-proxy-server'])
        for lang, loc_btn, status_sel, expect in [
            ('en', '#rp-int-locate', '#rp-int-location-status', {'searching': 'Looking for your position', 'denied': 'permission denied', 'timeout': 'within 15 seconds'}),
            ('es', '#rp-int-locate', '#rp-int-location-status', {'searching': 'Buscando tu posición', 'denied': 'denegado', 'timeout': 'en 15 segundos'}),
            ('fr', '#rp-terrain-locate', '#rp-terrain-status', {'searching': 'Recherche de ta position', 'denied': 'refusé', 'timeout': 'en 15 secondes'})]:
            c = b.new_context(viewport={'width': 390, 'height': 844}, service_workers='block')
            pg = c.new_page(); errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
            pg.goto(f'http://127.0.0.1:{PORT}/', wait_until='load')
            pg.evaluate("(l)=>localStorage.setItem('resilience-pocket:language:1', l)", lang)
            pg.reload(wait_until='load')
            for mode in ['denied', 'timeout', 'ok']:
                pg.evaluate('location.hash="#/";window.dispatchEvent(new Event("hashchange"))')
                pg.evaluate('location.hash="#/terrain";window.dispatchEvent(new Event("hashchange"))')
                pg.wait_for_selector(loc_btn)
                pg.evaluate(GEO, mode)
                pg.locator(loc_btn).click()
                if mode != 'ok':
                    check(expect['searching'] in pg.locator(status_sel).inner_text(), f'{lang}: no searching feedback')
                    pg.wait_for_timeout(500)
                    check(expect[mode] in pg.locator(status_sel).inner_text(), f'{lang}: {mode} message missing: {pg.locator(status_sel).inner_text()!r}')
                else:
                    pg.wait_for_selector('.rp-coordinates', timeout=3000)
                    check('44.04000' in pg.locator('.rp-coordinates').inner_text(), f'{lang}: coordinates not shown')
            body = pg.locator('#main').inner_text().lower()
            check(not any(w in body for w in ['rescuers have been notified', 'secours ont été prévenus', 'secours alertés', 'rescate avisado']), f'{lang}: misleading SOS wording')
            pg.screenshot(path=f'{SHOTS}/sos_{lang}.png', full_page=False)
            # French-only notice
            pg.evaluate('location.hash="#/secours";window.dispatchEvent(new Event("hashchange"))')
            pg.wait_for_timeout(200)
            notice = pg.locator('.rp-fr-only')
            if lang == 'fr':
                check(notice.count() == 0, 'fr: French-only notice shown to French users')
            else:
                check(notice.count() == 1, f'{lang}: French-only notice missing')
                check(pg.locator('.rp-fr-only a[href="#/terrain"]').count() == 1, f'{lang}: notice lacks SOS link')
                check(pg.locator('#main').get_attribute('lang') == 'fr', f'{lang}: French content not marked lang=fr')
                pg.screenshot(path=f'{SHOTS}/secours_notice_{lang}.png')
            pg.evaluate('location.hash="#/";window.dispatchEvent(new Event("hashchange"))')
            pg.wait_for_timeout(200)
            pg.screenshot(path=f'{SHOTS}/home_{lang}.png')
            check(not errs, f'{lang}: JS errors {errs}')
            c.close()
        b.close()
finally:
    s.terminate()
print('FAIL' if fails else 'PASS: GPS searching/denied/timeout/success FR/EN/ES, no misleading SOS wording, French-only notice with SOS link + lang=fr, JS errors 0')
for f in fails: print(' -', f)
sys.exit(1 if fails else 0)
