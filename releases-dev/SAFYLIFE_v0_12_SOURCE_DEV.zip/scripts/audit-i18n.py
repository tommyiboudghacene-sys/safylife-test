"""Browser i18n audit: for EN/ES, collect visible text per route and flag French-looking lines.
Usage: python3 -I i18n_audit.py <public_dir> <port>"""
import subprocess, sys, time, json, re
from playwright.sync_api import sync_playwright
ROOT, PORT = sys.argv[1], sys.argv[2]
ROUTES = ['#/', '#/terrain', '#/secours', '#/monde', '#/setup', '#/guide', '#/checklist', '#/drill', '#/simulations', '#/data', '#/print']
FR = re.compile(r"\b(le|la|les|des|du|une|est|pour|avec|vous|votre|tes|ton|ta|sans|dans|sur|qui|ne|pas|à|où|être|Accueil|Préparer|Secours|Aller au contenu|Hors connexion)\b", re.I)
s = subprocess.Popen([sys.executable, '-m', 'http.server', PORT, '--bind', '127.0.0.1', '--directory', ROOT], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
out = {}
try:
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=__import__('os').environ.get('CHROME','/usr/bin/chromium'), headless=True, args=['--no-sandbox', '--no-proxy-server'])
        for lang in ['en', 'es']:
            c = b.new_context(viewport={'width': 390, 'height': 844}, service_workers='block')
            pg = c.new_page()
            pg.goto(f'http://127.0.0.1:{PORT}/', wait_until='load')
            pg.evaluate("(l)=>localStorage.setItem('resilience-pocket:language:1', l)", lang)
            pg.reload(wait_until='load')
            res = {}
            for r in ROUTES:
                pg.evaluate('(r)=>{location.hash=r;window.dispatchEvent(new Event("hashchange"))}', r)
                pg.wait_for_timeout(150)
                chrome = pg.evaluate("""()=>[...document.querySelectorAll('.skip,.topnav a,.tabbar a,.rp-aid-fab,.brand')].map(e=>(e.innerText+' |aria:'+(e.getAttribute('aria-label')||'')).trim())""")
                body = pg.locator('#main').inner_text()
                lines = [l.strip() for l in body.split('\n') if l.strip()]
                frl = [l for l in lines if len(FR.findall(l)) >= 2]
                res[r] = {'lines': len(lines), 'fr_lines': len(frl), 'fr_ratio': round(len(frl) / max(1, len(lines)), 2), 'fr_sample': frl[:4]}
                if r == '#/': res['_chrome'] = chrome
            res['_lang_attr'] = pg.evaluate('document.documentElement.lang')
            out[lang] = res
            c.close()
        b.close()
finally:
    s.terminate()
print(json.dumps(out, ensure_ascii=False, indent=1))
