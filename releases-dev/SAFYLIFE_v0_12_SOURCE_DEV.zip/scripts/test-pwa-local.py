from playwright.sync_api import sync_playwright
import subprocess, sys
from pathlib import Path
ROOT=str(Path(__file__).resolve().parent.parent / 'public')
port='8769'
server=subprocess.Popen([sys.executable,'-m','http.server',port,'--bind','127.0.0.1','--directory',ROOT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
  with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
    c=b.new_context(viewport={'width':390,'height':844},service_workers='allow')
    page=c.new_page()
    errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
    try:
      page.goto(f'http://127.0.0.1:{port}/',timeout=11000,wait_until='domcontentloaded')
      page.wait_for_selector('.rp-welcome',timeout=11000)
      print('HTTP OK',page.title())
      # Keep an explicit worker registration to verify cache readiness
      page.wait_for_function('() => navigator.serviceWorker && !!navigator.serviceWorker.controller',timeout=15000)
      print('SW controlled',page.evaluate('!!navigator.serviceWorker.controller'))
      page.reload(wait_until='domcontentloaded')
      c.set_offline(True)
      page.reload(wait_until='domcontentloaded',timeout=9000)
      page.wait_for_selector('.rp-welcome',timeout=9000)
      page.evaluate("window.location.hash='#/monde';window.dispatchEvent(new Event('hashchange'))")
      page.wait_for_selector('.rp-practice-card',timeout=8000)
      print('OFFLINE PWA PASS',page.title(),page.locator('.rp-practice-card').count(),'JS ERR',errs)
    except Exception as e:
      print('PWA BROWSER TEST UNAVAILABLE',type(e).__name__,str(e)[:500])
    b.close()
finally:
  server.terminate();server.wait()
