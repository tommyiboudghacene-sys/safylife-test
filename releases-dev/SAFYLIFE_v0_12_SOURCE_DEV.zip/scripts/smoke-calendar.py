"""Exercise user-initiated calendar reminder downloads in Chromium (not push notifications)."""
from pathlib import Path
from playwright.sync_api import sync_playwright

content = Path('/mnt/data/SAFYLIFE_autonome.html').read_text(encoding='utf-8')
with sync_playwright() as p:
  browser = p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page = browser.new_page(accept_downloads=True,viewport={'width':360,'height':740})
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(content, wait_until='domcontentloaded')
  page.wait_for_selector('#rp-remind-world')
  with page.expect_download(timeout=10000) as info:
    page.locator('#rp-remind-world').click()
  download=info.value
  assert download.suggested_filename == 'SAFYLIFE-rappel-world.ics',download.suggested_filename
  path=download.path()
  content_ics=Path(path).read_bytes()
  assert b'RRULE:FREQ=WEEKLY' in content_ics
  assert b'BEGIN:VCALENDAR' in content_ics
  assert 'aucune notification' in page.locator('#rp-reminder-feedback').inner_text().lower()
  with page.expect_download(timeout=10000) as info:
    page.locator('#rp-remind-supplies').click()
  assert info.value.suggested_filename.endswith('supplies.ics')
  assert not errors,errors
  width=page.evaluate('document.documentElement.scrollWidth')
  assert width <= 360, f'horizontal overflow {width}'
  print('PASS: calendar reminders .ics downloads, opt-in messaging, 360px mobile layout, no JavaScript errors.')
  browser.close()
