import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const scope = 'https://test.example/apps/safylife/';
const handlers = {};
const store = new Map([['another-app-cache', new Map([['https://test.example/a','other']])]]);
const network = [];
let networkUp = true;
const cacheAPI = {
  async keys() { return [...store.keys()]; },
  async delete(key) { return store.delete(key); },
  async open(key) {
    if (!store.has(key)) store.set(key, new Map());
    const values = store.get(key);
    return {
      async addAll(urls) {
        if (!networkUp) throw new Error('offline');
        for (const url of urls) values.set(new URL(url, scope).href, new Response('cached:' + url));
      },
      async match(req) { const key = typeof req === 'string' ? req : req.url; return values.get(key) ?? null; },
      async delete(req) { return values.delete(typeof req === 'string' ? req : req.url); },
    };
  }
};
const api = {
  self: {
    registration: {scope},
    clients: { claim: async () => {} },
    skipWaiting: async () => {},
    addEventListener(name, fn) { handlers[name] = fn; }
  },
  caches: cacheAPI,
  URL, Response,
  fetch: async req => {
    network.push(req.url);
    if (!networkUp) throw new Error('offline');
    return new Response('network:' + req.url);
  },
};
vm.runInNewContext(readFileSync('public/sw.js', 'utf8'), api, { filename: 'public/sw.js' });
const trigger = async (kind, extra = {}) => {
  let work;
  let response;
  handlers[kind]({
    waitUntil(promise) { work = promise; },
    respondWith(promise) { response = promise; },
    ...extra,
  });
  if (work) await work;
  return response ? await response : undefined;
};
await trigger('install');
assert.equal(await cacheAPI.keys().then(k=>k.filter(x=>x.startsWith('safylife-')).length), 1);
await trigger('activate');
assert.ok(store.has('another-app-cache'), 'neighboring apps caches must not be deleted');
let message;
await trigger('message', {data:{type:'SAFYLIFE_OFFLINE_STATUS'}, ports:[{postMessage(obj){message=obj}}]});
assert.equal(message.ready, true);
assert.equal(message.count, message.total);
networkUp = false;
const homepage = await trigger('fetch', {request: new Request(scope + 'index.html')});
assert.ok((await homepage.text()).startsWith('cached:'), 'offline home must load from cache');
const map = await trigger('fetch', {request: new Request(scope+'world-shapes.json')});
assert.ok((await map.text()).startsWith('cached:'), 'offline map must load from cache');
const privateReq = await trigger('fetch',{request: new Request(scope+'api/private-user-profile')});
assert.equal(privateReq, undefined, 'private routes must never be intercepted or cached');
const queryReq = await trigger('fetch',{request: new Request(scope+'index.html?secret=1')});
assert.equal(queryReq, undefined, 'query-driven URLs must not silently receive cached content');
const otherReq = await trigger('fetch',{request: new Request('https://elsewhere.example/script.js')});
assert.equal(otherReq, undefined, 'foreign origins not intercepted');
assert.equal(network.length, 0, 'when offline, precached resources never ask the network');
const activeKey = [...store.keys()].find(x=>x.startsWith('safylife-'));
store.get(activeKey).delete(scope+'world-shapes.json');
await trigger('message', {data:{type:'SAFYLIFE_OFFLINE_STATUS'}, ports:[{postMessage(obj){message=obj}}]});
assert.equal(message.ready, false, 'missing offline resource reported, not pretended ready');
assert.equal(message.count, message.total - 1);
console.log('Service worker: installation, cache isolation, offline, private-URL exclusions, and completeness checks PASS.');
