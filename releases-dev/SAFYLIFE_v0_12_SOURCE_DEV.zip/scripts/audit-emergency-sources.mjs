/** Offline structural audit of numbers already present in SAFYLIFE.
 * This does NOT verify that the official websites are current or correct.
 */
import { countryOptions, emergencyFor, additionalEmergencyNumbersFor } from '../public/js/app/fr-world.js';
const countries = countryOptions('fr');
const errors = [];
const sources = [];
let withNumbers = 0;
for (const { code, title } of countries) {
  const primary = emergencyFor(code);
  const extras = additionalEmergencyNumbersFor(code);
  if (primary) withNumbers++;
  for (const item of [...(primary ? [primary] : []), ...extras]) {
    if (!/^\d{2,7}$/.test(item.number)) errors.push(`${code}: invalid phone number ${item.number}`);
    if (!item.source?.trim() || !item.url?.startsWith('https://')) errors.push(`${code}: source missing or non-HTTPS`);
    if (!['all', 'ambulance', 'fire-medical', 'police', 'police-mobile', 'police-landline'].includes(item.kind ?? item.type))
      errors.push(`${code}: unspecified agency`);
  }
  if (primary) sources.push({ code, country: title, number: primary.number, agency: primary.kind, source: primary.url, additional: extras.map(x => `${x.type} ${x.number}`) });
}
if (errors.length) { console.error(errors.join('\n')); process.exit(1); }
const summary = { countries: countries.length, withSourcedNumbers: withNumbers, missingOrUnverified: countries.length - withNumbers };
console.log('STRUCTURAL NUMBER AUDIT (not fact-check):', JSON.stringify(summary));
if (process.argv.includes('--json')) console.log(JSON.stringify(sources, null, 2));
