"""Real Chromium DOM smoke of the self-contained HTML via set_content.
The sandbox blocks file:// and localhost, so this does NOT assert PWA network or GPS hardware.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

html = Path('/mnt/data/SAFYLIFE_autonome.html').read_text(encoding='utf-8')
errors=[]
routes = {
 '#/':'Prêts si une catastrophe arrive.',
 '#/terrain':'Mon centre d\'urgence',
 '#/monde':'Le monde dans ta poche',
 '#/secours':'Les gestes qui sauvent',
 '#/setup':None,
 '#/simulations':None,
 '#/drill':None,
 '#/guide':None,
 '#/checklist':None,
 '#/missions':None,
 '#/essai':None,
 '#/aventures':None,
 '#/data':'Sauvegarde et confidentialité',
 '#/print':'Plan familial de préparation',
 '#/game/cards':'Duel des éléments',
 '#/game/memory':'Mémoire 72h',
 '#/aventure/blackout':None,
}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 page.on('pageerror',lambda error:errors.append(str(error)))
 page.set_content(html,wait_until='domcontentloaded',timeout=15000)
 page.wait_for_selector('.rp-welcome',timeout=10000)
 assert 'SAFYLIFE' in page.title()
 assert page.locator('.rp-safety-sos[href="#/terrain"]').count()==1
 assert page.locator('script[src],link[href],img[src]').count()==0
 for route, expected in routes.items():
  page.evaluate('(url) => { window.location.hash = url; window.dispatchEvent(new Event("hashchange")); }',route)
  page.wait_for_timeout(80)
  if expected:
   text=page.locator('#main').inner_text()
   assert expected in text, f'{route}: expected {expected} in {text[:170]}'
  assert page.locator('#main').inner_text().strip(), route
 # Security: SOS cannot claim that it contacts rescuers automatically.
 page.evaluate('window.location.hash="#/terrain"; window.dispatchEvent(new Event("hashchange"))')
 page.wait_for_selector('#rp-terrain-country')
 assert 'Rien n' in page.locator('#main').inner_text() and 'transmis sans ton action' in page.locator('#main').inner_text()
 country=page.locator('#rp-terrain-country')
 country.select_option('FR')
 assert page.locator('a[href="tel:112"]').count()>=1
 country.select_option('JP')
 assert page.locator('a[href="tel:119"]').count()>=1
 assert page.locator('a[href="tel:110"]').count()>=1
 country.select_option('MA')
 assert page.locator('a[href="tel:150"]').count()>=1
 # Browser-simulated GPS, not actual phone satellite GPS.
 page.evaluate('''() => Object.defineProperty(navigator, "geolocation", {configurable:true, value:{getCurrentPosition(success){success({coords:{latitude:34.5, longitude:-6.9, accuracy:42}, timestamp:Date.now()})}}})''')
 page.locator('#rp-terrain-locate').click()
 page.wait_for_selector('.rp-coordinates')
 assert '34.50000' in page.locator('.rp-coordinates').inner_text()
 page.locator('#rp-terrain-forget').click()
 assert page.locator('.rp-coordinates').count()==0
 # Privacy controls exist and operate through explicit confirmation.
 page.evaluate('window.location.hash="#/data";window.dispatchEvent(new Event("hashchange"))')
 page.wait_for_selector('#rp-wipe-all')
 assert page.locator('#rp-export').count()==1
 # Prevent removal during automated smoke; genuine users see a confirm box.
 page.on('dialog',lambda dialog: dialog.dismiss())
 page.locator('#rp-wipe-all').click()
 assert page.locator('#rp-wipe-all').count()==1
 # mobile horizontal layout bound; no gross overflow on the screen.
 page.evaluate('window.location.hash="#/";window.dispatchEvent(new Event("hashchange"))')
 page.wait_for_selector('.rp-welcome')
 page.screenshot(path='/mnt/data/SAFYLIFE_mobile.png',full_page=False)
 width=page.evaluate('document.documentElement.scrollWidth')
 assert width <= 420, f'horizontal overflow {width} vs viewport 390'
 assert not errors, f'JS exceptions: {errors[:3]}'
 print(f'PASS: {len(routes)} routes, SOS country selection, simulated location, privacy controls, mobile screenshot; JS errors=0, horizontal width={width}.')
 b.close()
