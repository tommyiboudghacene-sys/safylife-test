"""Test the opt-in acoustic SOS button using a fake AudioContext to avoid playing sound.
This tests the UI wiring and cleanup only; it does not certify real phone audio hardware.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
content = Path('/mnt/data/SAFYLIFE_autonome.html').read_text(encoding='utf-8')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':320,'height':690})
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.evaluate('''() => {window.testSignal = {events:[],closed:0};
 class MockAudioContext {
  currentTime = 0; destination = {};
  resume() {window.testSignal.events.push('resume');return Promise.resolve();}
  close() {window.testSignal.closed++;return Promise.resolve();}
  createOscillator(){return {frequency:{value:0},type:'sine',connect(){},start(){window.testSignal.events.push('start')},stop(){}}}
  createGain(){return {gain:{setValueAtTime(){},linearRampToValueAtTime(){}},connect(){}}}
 }
 window.AudioContext=MockAudioContext;}''')
 page.set_content(content)
 page.wait_for_selector('.rp-welcome')
 page.evaluate("window.location.hash='#/terrain';window.dispatchEvent(new Event('hashchange'))")
 page.wait_for_selector('[data-sos-sound]')
 page.locator('[data-sos-sound]').click()
 page.wait_for_function("document.querySelector('[data-sos-sound]').textContent.includes('Arrêter')")
 assert page.evaluate('testSignal.events.filter(x=>x===\'start\').length') >= 9
 page.locator('[data-sos-sound]').click()
 page.wait_for_function("document.querySelector('[data-sos-sound]').textContent.includes('Émettre')")
 assert page.evaluate('testSignal.closed') >= 1
 # Re-render the SOS page while sound is active, must not leak prior audio.
 page.locator('[data-sos-sound]').click()
 before=page.evaluate('testSignal.closed')
 page.locator('#rp-terrain-country').select_option('JP')
 page.wait_for_selector('[data-sos-sound]')
 assert page.evaluate('testSignal.closed') > before, 'audio not closed when root re-renders'
 assert not errors,errors
 print('PASS: manual sound starts/stops, cleans up on country change, 320px view, no JS errors (mock audio).')
 b.close()
