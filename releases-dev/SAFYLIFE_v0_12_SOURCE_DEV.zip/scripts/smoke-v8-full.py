"""In-memory Chromium checks for the autonomous HTML.
This DOES NOT verify a real PWA installation or a real GNSS fix.
"""
from playwright.sync_api import sync_playwright
from pathlib import Path
html = Path('/mnt/data/SAFYLIFE_v8_autonome.html').read_text('utf-8')
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  ctx=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  page=ctx.new_page()
  errors=[]
  page.on('pageerror',lambda e: errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded')
  routes={
    '':'h1', 'terrain':'#rp-terrain-country', 'monde':'#rp-world-country',
    'secours':'.rp-aid-landing', 'setup':'h1', 'simulations':'.rp-scenario-grid',
    'missions':'h1', 'aventures':'h1', 'guide':'h1', 'checklist':'h1',
    'drill':'h1', 'game/kit':'[data-kit]', 'game/cards':'h1', 'game/memory':'h1',
    'essai':'#rp-tester-copy', 'data':'h1', 'print':'h1'
  }
  for name,selector in routes.items():
    page.evaluate('(name)=>{location.hash="#/"+name}',name)
    page.locator(selector).first.wait_for(state='attached',timeout=5000)
    assert len(page.locator('main').inner_text())>25,(name,'empty main')
  print('Screens passed:',len(routes))
  page.evaluate('location.hash="#/terrain"')
  page.locator('#rp-terrain-country').wait_for()
  page.locator('#rp-terrain-country').select_option('JP')
  assert page.locator('a[href="tel:119"]').count()==1
  assert page.locator('a[href="tel:110"]').count()==1
  page.locator('#rp-terrain-country').select_option('FR')
  assert page.locator('a[href="tel:112"]').count()==1
  page.locator('#rp-terrain-country').select_option('MA')
  assert page.locator('a[href="tel:150"]').count()==1
  page.locator('#rp-terrain-country').select_option('FR')
  page.evaluate('''() => {Object.defineProperty(navigator,'geolocation',{configurable:true,value:{getCurrentPosition(ok){ok({coords:{latitude:45.764,longitude:4.836,accuracy:1800},timestamp:Date.now()-45*60000})}}});}''')
  page.get_by_role('button',name='Relever ma position').click()
  page.locator('.rp-fix-stale').wait_for()
  assert 'ANCIENNE POSITION' in page.locator('#rp-terrain-coords').inner_text()
  print('Stale location warning: passed (mocked GPS)')
  assert not errors,errors
  print('JavaScript errors:',len(errors))
  browser.close()
