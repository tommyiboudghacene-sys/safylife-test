"""SAFYLIFE browser regression without server access.
Loads the generated single-file app into Chromium via set_content.
Tests DOM/JS behavior, NOT a real service worker or physical GPS/modem.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

PAGE = Path(__file__).resolve().parents[2] / 'SAFYLIFE_autonome.html'
HTML = PAGE.read_text(encoding='utf-8')

def route(page, path):
    page.evaluate('(path) => { location.hash=path; window.dispatchEvent(new Event("hashchange")); }', path)
    page.wait_for_timeout(180)

def set_lang(page, lang):
    if lang != 'fr':
        route(page, '#/monde')
        page.locator('#rp-world-language').select_option(lang)
        page.wait_for_timeout(200)

errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox','--disable-dev-shm-usage'])
    for lang in ['fr', 'en', 'es']:
        page = browser.new_page(viewport={'width': 390,'height':844})
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.set_content(HTML, wait_until='load')
        set_lang(page, lang)
        route(page, '#/terrain')
        button = '#rp-terrain-locate' if lang == 'fr' else '#rp-int-locate'
        state = '#rp-terrain-status' if lang == 'fr' else '#rp-int-location-status'
        assert page.locator(button).count() == 1, f'{lang}: geolocation button missing'
        page.evaluate('''() => {
            window.__geoCalls = 0;
            Object.defineProperty(navigator,'geolocation',{configurable: true, value: {
                getCurrentPosition(ok,err) {
                  window.__geoCalls++;
                  setTimeout(() => ok({coords:{latitude:44.041,longitude:1.12,accuracy:30}, timestamp:Date.now()}),350);
                }
            }});
        }''')
        page.locator(button).click()
        assert page.locator(button).is_disabled(), f'{lang}: GPS button should be disabled while pending'
        page.evaluate('(btn)=>document.querySelector(btn).click()', button)
        assert page.evaluate('window.__geoCalls') == 1, f'{lang}: overlapping GPS requests'
        route(page, '#/monde')
        page.wait_for_timeout(500)
        assert page.locator('#rp-world-language').count() == 1, f'{lang}: late GPS result overwrote a different route'
        route(page, '#/terrain')
        page.evaluate('''() => Object.defineProperty(navigator,'geolocation',{configurable:true, value: {
            getCurrentPosition(ok,err){setTimeout(()=>ok({coords:{latitude:44.042,longitude:1.12,accuracy:20},timestamp:Date.now()}),40)}
        }})''')
        page.locator(button).click()
        page.wait_for_timeout(150)
        assert page.locator('.rp-coordinates').count() == 1, f'{lang}: GPS success not displayed'
        assert '44.04200' in page.locator('.rp-coordinates').inner_text(), f'{lang}: GPS coordinates wrong'
        # Native share present but not permitted -> show fallback when clipboard unavailable.
        page.evaluate('''() => { Object.defineProperty(navigator,'share',{configurable:true, value:()=>Promise.reject(new DOMException('blocked','NotAllowedError'))}); Object.defineProperty(document,'execCommand',{configurable:true, value:()=>false}); Object.defineProperty(navigator,'clipboard',{configurable:true, value:{writeText:()=>Promise.reject(new Error('clipboard denied'))}}); }''')
        share = '#rp-terrain-share' if lang == 'fr' else '#rp-int-share'
        page.locator(share).click()
        page.wait_for_timeout(170)
        field = page.locator('[data-manual-emergency-copy] textarea')
        assert field.count() == 1 and field.input_value().strip(), f'{lang}: no manual copy fallback after share denial'
        assert not page.locator('[data-manual-emergency-copy]').is_hidden(), f'{lang}: fallback hidden'
        assert not errors, f'{lang}: JS errors {errors}'
        print(f'{lang}: route guard, GPS dedupe/success and share fallback PASS')
        page.close()
    browser.close()
print('PASS: 3 languages, Chrome DOM; no real phone or service worker')
