from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  context=b.new_context(viewport={'width':390,'height':844},service_workers='allow')
  page=context.new_page()
  errs=[]
  page.on('pageerror', lambda e:errs.append(str(e)))
  page.goto('http://127.0.0.1:8769/index.html',wait_until='domcontentloaded',timeout=15000)
  page.wait_for_selector('#rp-app-install')
  print('LOADED',page.title())
  ready=page.evaluate('''async() => {const r=await Promise.race([navigator.serviceWorker.ready,new Promise((_,reject)=>setTimeout(()=>reject(new Error('sw timeout')),10000))]);return {scope:r.scope,controller:!!navigator.serviceWorker.controller}}''')
  print('READY',ready)
  page.reload(wait_until='domcontentloaded')
  page.wait_for_selector('.rp-welcome')
  status=page.evaluate('''async() => { const r=await navigator.serviceWorker.ready;return await new Promise((resolve,reject)=>{const channel=new MessageChannel();const t=setTimeout(()=>reject(new Error('status timeout')),5000);channel.port1.onmessage=e=>{clearTimeout(t);resolve(e.data);};r.active.postMessage({type:'SAFYLIFE_OFFLINE_STATUS'},[channel.port2]);});}''')
  print('CACHE',status)
  assert status['ready'],status
  context.set_offline(True)
  page.reload(wait_until='domcontentloaded',timeout=15000)
  page.wait_for_selector('.rp-welcome',timeout=15000)
  page.locator('a[href="#/monde"]').first.click()
  page.wait_for_selector('#rp-world-canvas',timeout=10000)
  page.wait_for_function("document.querySelector('#rp-world-load-status')?.textContent?.includes('✓')",timeout=10000)
  print('OFFLINE READY: page, world map, status',page.locator('#rp-world-load-status').inner_text())
  assert not errs,errs
  print('PASS: PWA installed in local Chromium, offline reopen + offline world map. No JS exceptions.')
  b.close()
