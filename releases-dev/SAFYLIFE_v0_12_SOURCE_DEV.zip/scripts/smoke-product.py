"""DOM smoke with real Chromium JS engine; simulates GPS because hardware unavailable.
This is NOT a real device/PWA installation/field-rescue validation.
"""
from playwright.sync_api import sync_playwright
from pathlib import Path
html=Path('/mnt/data/SAFYLIFE_autonome.html').read_text(encoding='utf-8')
ROUTES=['#/','#/terrain','#/monde','#/secours','#/setup','#/simulations','#/drill','#/guide','#/checklist','#/missions','#/essai','#/aventures','#/data','#/print','#/game/cards','#/game/memory','#/aventure/blackout']
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
  page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=15000)
  page.wait_for_selector('.rp-safety-hero')
  for route in ROUTES:
    page.evaluate('(route)=>{location.hash=route;window.dispatchEvent(new Event("hashchange"))}',route)
    page.wait_for_timeout(40)
    assert page.locator('#main').inner_text().strip(),route
  # Grounded emergency numbers and manual SMS draft (never auto-send)
  page.evaluate("location.hash='#/terrain';window.dispatchEvent(new Event('hashchange'))")
  page.locator('#rp-terrain-country').select_option('MA')
  assert page.locator('a[href="tel:150"]').count()>=1
  assert page.locator('a[href="tel:190"]').count()>=1
  page.locator('#rp-terrain-country').select_option('JP')
  assert page.locator('a[href="tel:119"]').count()>=1
  assert page.locator('a[href="tel:110"]').count()>=1
  page.evaluate('''() => Object.defineProperty(navigator, 'geolocation', {configurable:true, value:{getCurrentPosition(cb){cb({coords:{latitude:36.1, longitude:140.1, accuracy:50}, timestamp:Date.now()})}}})''')
  page.locator('#rp-terrain-locate').click()
  page.wait_for_selector('.rp-coordinates')
  assert '36.10000' in page.locator('.rp-coordinates').inner_text()
  page.locator('#rp-terrain-forget').click()
  assert page.locator('.rp-coordinates').count()==0
  page.locator('#rp-sms-number').fill('112')
  page.locator('#rp-sms-open').click()
  assert 'au moins 7 chiffres' in page.locator('#rp-sms-status').inner_text()
  # World language settings; preserves national phone mapping after switching
  page.evaluate("location.hash='#/monde';window.dispatchEvent(new Event('hashchange'))")
  page.wait_for_selector('#rp-world-language')
  page.locator('#rp-world-language').select_option('en')
  assert 'How other countries prepare' in page.locator('.rp-global-practices').inner_text()
  page.evaluate("location.hash='#/';window.dispatchEvent(new Event('hashchange'))")
  assert 'Be ready before' in page.locator('.rp-safety-hero').inner_text()
  page.evaluate("location.hash='#/terrain';window.dispatchEvent(new Event('hashchange'))")
  page.wait_for_selector('#rp-int-country')
  page.locator('#rp-int-country').select_option('US')
  assert page.locator('a[href="tel:911"]').count()>=1
  assert 'does not automatically notify' in page.locator('#main').inner_text()
  page.evaluate("location.hash='#/monde';window.dispatchEvent(new Event('hashchange'))")
  page.locator('#rp-world-language').select_option('es')
  assert 'Cómo se preparan otros países' in page.locator('.rp-global-practices').inner_text()
  page.evaluate("location.hash='#/terrain';window.dispatchEvent(new Event('hashchange'))")
  page.wait_for_selector('#rp-int-country')
  assert 'Asistencia de emergencia' in page.locator('#main').inner_text()
  page.locator('#rp-int-sms-number').fill('112')
  page.locator('#rp-int-sms-open').click()
  assert '7 cifras' in page.locator('#rp-int-sms-status').inner_text()
  # Check responsive at 320, 390, 768, 1024
  for width in [320,390,768,1024]:
    page.set_viewport_size({'width':width,'height':900})
    for route in ['#/','#/terrain','#/monde']:
      page.evaluate('(route)=>{location.hash=route;window.dispatchEvent(new Event("hashchange"))}',route)
      page.wait_for_timeout(60)
      page.wait_for_selector('#main')
      actual=page.evaluate('document.documentElement.scrollWidth')
      if actual > width+1:
        print('OVERFLOW',width,route,actual, page.evaluate('({iw:innerWidth,cw:document.documentElement.clientWidth,bw:document.body.clientWidth, bs:document.body.scrollWidth, ms:document.querySelector("#main")?.scrollWidth, bc:document.body.clientWidth, main:document.querySelector("#main")?.getBoundingClientRect().width})'))
        for x in page.evaluate("() => [...document.querySelectorAll('body *')].map(e=>({cls: typeof e.className === 'string' ? e.className : '', tag:e.tagName, id:e.id, text:e.textContent?.trim().slice(0,70), r:Math.round(e.getBoundingClientRect().right),w:Math.round(e.getBoundingClientRect().width)})).filter(e=>e.r > 321).sort((a,b)=>b.r-a.r).slice(0,12)"):
          print(x)
        print('SCROLL offenders:',page.evaluate("() => [...document.querySelectorAll('#main *')].map(e=>({tag:e.tagName,id:e.id,cls:typeof e.className==='string'?e.className:'',sw:e.scrollWidth,cw:e.clientWidth, rect:e.getBoundingClientRect().width})).filter(x=>x.sw>x.cw+5).sort((a,b)=>b.sw-b.cw-(a.sw-a.cw)).slice(0,15)"))
      assert actual <= width+1, f'overflow at {width} {route}: {actual}' 
  page.set_viewport_size({'width':390,'height':844})
  page.evaluate("location.hash='#/';window.dispatchEvent(new Event('hashchange'))")
  page.screenshot(path='/mnt/data/SAFYLIFE_APERCU_ACTUEL.png')
  assert not errs, f'JavaScript errors: {errs}'
  print(f'PASS: {len(ROUTES)} routes, offline-world cards FR/EN/ES, SOS France/Morocco/Japan/US, simulated GPS, input safety, responsive 320-1024, JS errors=0; GPS hardware and PWA installation untested.')
  b.close()
