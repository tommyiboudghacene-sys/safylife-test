"""Desktop/mobile browser checks for international weekly practice and calendar UI.
Only tests local UI; no live feed and no mobile OS push notification is involved.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
html=Path('/mnt/data/SAFYLIFE_autonome.html').read_text(encoding='utf-8')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':320,'height':800})
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html)
 page.wait_for_selector('#rp-weekly-title')
 for code,title in [('en',"This week’s offline preparedness idea"),('es','Idea semanal guardada sin conexión'),('fr','À découvrir cette semaine')]:
  page.evaluate("window.location.hash='#/monde';window.dispatchEvent(new Event('hashchange'))")
  page.wait_for_selector('#rp-world-language')
  page.locator('#rp-world-language').select_option(code)
  page.evaluate("window.location.hash='#/';window.dispatchEvent(new Event('hashchange'))")
  page.wait_for_function('needle => document.querySelector("#main")?.textContent?.includes(needle)',arg=title,timeout=5000)
  text=page.locator('#main').inner_text()
  assert title.upper() in text,(code,text[700:1100])
  assert page.locator('#rp-remind-world').count() == 1
  assert page.locator('#rp-remind-supplies').count() == 1
  assert 'not live news' in text.lower() if code == 'en' else True
  width=page.evaluate('document.documentElement.scrollWidth')
  assert width <= 320,(code,width)
 assert not errors,errors
 print('PASS: home weekly practice and reminders FR/EN/ES, 320px without overflow or JS errors.')
 browser.close()
