from playwright.sync_api import sync_playwright
from pathlib import Path
import subprocess, sys, json
html=Path('/mnt/data/SAFYLIFE_autonome.html').read_text(encoding='utf-8')
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
    errors=[]
    page=b.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded',timeout=20000)
    page.wait_for_selector('.rp-safety-hero')
    page.evaluate("window.location.hash='#/terrain'; window.dispatchEvent(new Event('hashchange'))")
    page.wait_for_selector('#rp-sms-number')
    page.locator('#rp-sms-number').fill('123')
    page.locator('#rp-sms-open').click()
    assert 'au moins 7 chiffres' in page.locator('#rp-sms-status').inner_text()
    page.locator('#rp-terrain-country').select_option('JP')
    assert page.locator('a[href="tel:119"]').count()>0
    assert page.locator('a[href="tel:110"]').count()>0
    page.screenshot(path='/mnt/data/SAFYLIFE_SOS_FINAL_TEST.png',full_page=False)
    page.evaluate("window.location.hash='#/monde'; window.dispatchEvent(new Event('hashchange'))")
    page.wait_for_selector('.rp-global-practices')
    assert page.locator('.rp-practice-card').count()>=8
    page.locator('#rp-world-language').select_option('en')
    assert 'How other countries prepare' in page.locator('.rp-global-practices').inner_text()
    page.locator('#rp-world-language').select_option('es')
    assert 'Cómo se preparan otros países' in page.locator('.rp-global-practices').inner_text()
    page.evaluate("window.location.hash='#/';window.dispatchEvent(new Event('hashchange'))")
    page.wait_for_selector('.rp-safety-hero')
    page.screenshot(path='/mnt/data/SAFYLIFE_ACCUEIL_FINAL_TEST.png',full_page=False)
    assert not errors, errors
    assert page.evaluate('document.documentElement.scrollWidth')<=390
    print('PASS: emergency SMS invalid guard, JP 119/110, at least 8 international offline cards FR/EN/ES, home mobile no overflow, JS errors 0')
    b.close()
