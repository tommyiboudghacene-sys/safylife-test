from pathlib import Path
p=Path('src/app/fr-world.ts')
s=p.read_text(); s=s.replace('import { WORLD_PRACTICES, WORLD_PRACTICES_REVIEWED } from "./world-practices.js";', 'import { WORLD_PRACTICES, WORLD_PRACTICES_REVIEWED } from "./world-practices.js";\nimport { loadEarthquakes, USGS_HOME, type EarthquakeObservation } from "./live-earthquakes.js";')
needle='  mount(root, html`\n    <section class="rp-page-lead">'
new='''  const seismic = {
    fr: {title:"🌐 Séismes récents observés dans le monde",intro:"Données scientifiques USGS chargées uniquement si tu appuies sur Actualiser. Il ne s’agit ni d’alertes, ni de prévisions, ni de consignes d’évacuation.",refresh:"Actualiser depuis l’USGS",offline:"Aucune donnée en direct sans Internet. Les fiches de prévention hors connexion restent disponibles.",loading:"Connexion à l’USGS…",error:"Données momentanément indisponibles. Consulte la source officielle sur Internet.",empty:"Aucun événement récent correspondant aux critères du flux.",date:"Heure locale",mag:"Magnitude",source:"Source USGS — événements observés",privacy:"En actualisant, ton appareil contacte directement l’USGS. SAFYLIFE ne transmet pas ta position GPS."},
    en: {title:"🌐 Recently observed earthquakes worldwide",intro:"USGS scientific data are loaded ONLY when you press Refresh. This is NOT an alert, prediction or evacuation guidance.",refresh:"Refresh from USGS",offline:"No live data without Internet. Offline preparation tips remain available.",loading:"Connecting to USGS…",error:"Data unavailable. Check the official source online.",empty:"No recent events matched the feed criteria.",date:"Local time",mag:"Magnitude",source:"USGS — observed events",privacy:"Refresh contacts USGS directly. SAFYLIFE does not transmit your GPS location."},
    es: {title:"🌐 Terremotos observados recientemente en el mundo",intro:"Los datos científicos del USGS se consultan SOLO si pulsas Actualizar. NO son alertas, predicciones ni instrucciones de evacuación.",refresh:"Actualizar desde USGS",offline:"No hay datos actuales sin Internet. Las recomendaciones guardadas siguen disponibles.",loading:"Conectando a USGS…",error:"Datos no disponibles. Consulta la fuente oficial en Internet.",empty:"No hay eventos recientes en este conjunto de datos.",date:"Hora local",mag:"Magnitud",source:"USGS — eventos observados",privacy:"Al actualizar, tu dispositivo contacta directamente con USGS. SAFYLIFE no envía tu GPS."},
  }[lang];
  mount(root, html`
    <section class="rp-page-lead">'''
assert s.count(needle)==1
s=s.replace(needle,new)
needle='''    <section class="rp-global-practices" aria-labelledby="rp-practices-title">'''
new='''    <section class="card rp-earthquakes" aria-labelledby="rp-earthquakes-title">
      <h2 id="rp-earthquakes-title">${seismic.title}</h2><p>${seismic.intro}</p>
      <button type="button" id="rp-usgs-refresh" class="btn">↻ ${seismic.refresh}</button>
      <p class="hint">${seismic.privacy}</p>
      <div id="rp-usgs-results" role="status" aria-live="polite"><p class="hint">${seismic.offline}</p></div>
      <a href="${USGS_HOME}" target="_blank" rel="noopener noreferrer">${seismic.source} ↗</a>
    </section>
    <section class="rp-global-practices" aria-labelledby="rp-practices-title">'''
assert s.count(needle)==1
s=s.replace(needle,new)
needle='''  void draw();
  root.querySelector<HTMLSelectElement>("#rp-world-language")'''
new='''  void draw();
  root.querySelector<HTMLButtonElement>("#rp-usgs-refresh")?.addEventListener("click",async()=>{
    const button = root.querySelector<HTMLButtonElement>("#rp-usgs-refresh")!;
    const container = root.querySelector<HTMLElement>("#rp-usgs-results")!;
    if (!navigator.onLine) {container.textContent=seismic.offline;return;}
    button.disabled=true;
    container.textContent=seismic.loading;
    try {
      const earthquakes: EarthquakeObservation[] = await loadEarthquakes();
      if (!root.isConnected) return;
      mount(container,html`${earthquakes.length ? html`<ul class="rp-earthquake-list">${earthquakes.map(e => html`<li><strong>M ${e.magnitude.toFixed(1)}</strong> — ${e.place}<small>${seismic.date}: ${new Date(e.at).toLocaleString(lang)} · <a href="${e.url}" target="_blank" rel="noopener noreferrer">USGS ↗</a></small></li>`)}</ul>` : html`<p>${seismic.empty}</p>`}`);
    } catch {if(root.isConnected) container.textContent=seismic.error;}
    finally {if(root.isConnected) button.disabled=false;}
  });
  root.querySelector<HTMLSelectElement>("#rp-world-language")'''
assert s.count(needle)==1
s=s.replace(needle,new)
p.write_text(s)

# Safety-critical optional trusted contact UI in FR + EN/ES.
p=Path('src/app/fr-terrain.ts');s=p.read_text()
s=s.replace('import { attachDistressSignal } from "./distress-signal.js";', 'import { attachDistressSignal } from "./distress-signal.js";\nimport { loadTrustedContact, saveTrustedContact, deleteTrustedContact } from "./trusted-contact.js";')
s=s.replace('''<input id="rp-sms-number" type="tel" inputmode="tel" autocomplete="off" placeholder="Ex. +33 6 12 34 56 78" aria-describedby="rp-sms-note">''','''<input id="rp-sms-number" type="tel" inputmode="tel" autocomplete="off" placeholder="Ex. +33 6 12 34 56 78" value="${loadTrustedContact() ?? ""}" aria-describedby="rp-sms-note">''')
s=s.replace('''<p id="rp-sms-note" class="hint">Le numéro n'est pas enregistré. Le bouton ouvre l'application SMS : tu dois encore vérifier et envoyer le message toi-même. Réseau mobile nécessaire.</p>''','''<p id="rp-sms-note" class="hint">Tu peux mémoriser volontairement ce numéro sur CE téléphone pour gagner du temps en urgence. Attention : il restera lisible par une personne ayant accès à ton appareil. SAFYLIFE ne l'envoie pas à un serveur. Tu dois vérifier et envoyer chaque SMS toi-même (réseau mobile nécessaire).</p>
        <div class="btn-row"><button type="button" class="btn" id="rp-sms-save-contact">Enregistrer sur ce téléphone</button><button type="button" class="btn danger" id="rp-sms-clear-contact">Effacer le numéro mémorisé</button></div>''')
s=s.replace('''  root.querySelector<HTMLButtonElement>("#rp-sms-open")?.addEventListener("click", () => {''','''  root.querySelector<HTMLButtonElement>("#rp-sms-save-contact")?.addEventListener("click",()=>{
    const input=root.querySelector<HTMLInputElement>("#rp-sms-number")!;
    const status=root.querySelector<HTMLElement>("#rp-sms-status")!;
    status.textContent=saveTrustedContact(input.value) ? "Contact enregistré uniquement sur cet appareil. Aucun SMS envoyé." : "Numéro invalide ou stockage indisponible.";
  });
  root.querySelector<HTMLButtonElement>("#rp-sms-clear-contact")?.addEventListener("click",()=>{
    const ok=deleteTrustedContact();
    if (ok) root.querySelector<HTMLInputElement>("#rp-sms-number")!.value="";
    root.querySelector<HTMLElement>("#rp-sms-status")!.textContent=ok ? "Contact supprimé de cet appareil." : "Impossible d'effacer le contact ici.";
  });
  root.querySelector<HTMLButtonElement>("#rp-sms-open")?.addEventListener("click", () => {''')
p.write_text(s)

p=Path('src/app/sos-international.ts');s=p.read_text()
s=s.replace('import { attachDistressSignal } from "./distress-signal.js";', 'import { attachDistressSignal } from "./distress-signal.js";\nimport { loadTrustedContact, saveTrustedContact, deleteTrustedContact } from "./trusted-contact.js";')
s=s.replace('''phoneHelp:"The number is not saved. You must confirm the recipient and press Send in your phone's messaging app. Cellular service is required.",''','''phoneHelp:"You may optionally save the number on THIS device. Anyone with access to your device may see it. SAFYLIFE does not send it to a server. Every SMS requires your confirmation and mobile coverage.",saveContact:"Save on this device",deleteContact:"Forget saved number",savedContact:"Saved locally; no SMS sent.",deletedContact:"Saved number deleted.",saveFailed:"Invalid number or local storage unavailable.",deleteFailed:"Could not delete local number.",''')
s=s.replace('''phoneHelp:"No guardamos el número. Debes comprobar el destinatario y pulsar Enviar en la aplicación SMS. Se requiere cobertura móvil.",''','''phoneHelp:"Puedes guardar voluntariamente el número SOLO en este dispositivo. Otra persona con acceso al teléfono podría verlo. SAFYLIFE no lo envía a un servidor. Cada SMS requiere confirmación y cobertura móvil.",saveContact:"Guardar en este dispositivo",deleteContact:"Borrar número guardado",savedContact:"Guardado localmente; sin enviar SMS.",deletedContact:"Número guardado borrado.",saveFailed:"Número inválido o almacenamiento no disponible.",deleteFailed:"No se pudo borrar el número.",''')
s=s.replace('''<input id="rp-int-sms-number" type="tel" inputmode="tel" autocomplete="off" placeholder="+33 6 12 34 56 78">''','''<input id="rp-int-sms-number" type="tel" inputmode="tel" autocomplete="off" value="${loadTrustedContact() ?? ""}" placeholder="+33 6 12 34 56 78">''')
s=s.replace('''<p class="hint">${t.phoneHelp}</p><div class="btn-row">''','''<p class="hint">${t.phoneHelp}</p><div class="btn-row"><button type="button" class="btn" id="rp-int-sms-save">${t.saveContact}</button><button type="button" class="btn danger" id="rp-int-sms-delete">${t.deleteContact}</button></div><div class="btn-row">''')
s=s.replace('''  root.querySelector<HTMLButtonElement>("#rp-int-sms-open")?.addEventListener("click",()=>{''','''  root.querySelector<HTMLButtonElement>("#rp-int-sms-save")?.addEventListener("click",()=>{
    const phone=root.querySelector<HTMLInputElement>("#rp-int-sms-number")!.value;
    status().textContent=saveTrustedContact(phone)?t.savedContact:t.saveFailed;
  });
  root.querySelector<HTMLButtonElement>("#rp-int-sms-delete")?.addEventListener("click",()=>{
    const ok=deleteTrustedContact();
    if(ok) root.querySelector<HTMLInputElement>("#rp-int-sms-number")!.value="";
    status().textContent=ok?t.deletedContact:t.deleteFailed;
  });
  root.querySelector<HTMLButtonElement>("#rp-int-sms-open")?.addEventListener("click",()=>{''')
p.write_text(s)

# include new scripts offline
p=Path('public/sw.js');s=p.read_text();s=s.replace('''  "./js/app/weekly-practice.js",''','''  "./js/app/weekly-practice.js",
  "./js/app/live-earthquakes.js",
  "./js/app/trusted-contact.js",''');p.write_text(s)
# Add minimal CSS for readable, narrow mobile use
p=Path('public/styles.css');s=p.read_text();s+='''\n/* Optional scientific event list: do not style as an emergency alert. */\n.rp-earthquake-list{list-style:none;padding:0;margin:1rem 0;display:grid;gap:.65rem}\n.rp-earthquake-list li{padding:.75rem;border:1px solid var(--line,#d5e4dd);border-radius:12px;overflow-wrap:anywhere}\n.rp-earthquake-list small{display:block;margin-top:.35rem;color:var(--muted,#5c6c6c);font-size:.86em}\n.rp-earthquakes button:disabled{opacity:.55;cursor:progress}\n''';p.write_text(s)

# Correct release counters: compute from test output and SW rather than hard-coding.
p=Path('scripts/package-consolidated.mjs');s=p.read_text();s=s.replace("unit_tests_passed:69,offline_assets:53,", "test_source_files:readdirSync(join(root,'tests')).filter(n=>n.endsWith('.test.ts')).length,offline_assets:(readFileSync(join(root,'public/sw.js'),'utf8').match(/\"\\.\\/[^\"]+\"/g)||[]).length,");p.write_text(s)
