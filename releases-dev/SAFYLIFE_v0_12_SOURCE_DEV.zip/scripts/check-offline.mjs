import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

const worker = readFileSync("public/sw.js", "utf8");
const list = worker.match(/const ASSETS = \[([\s\S]*?)\];/);
if (!list) throw new Error("Offline asset manifest not found");
const assets = [...list[1].matchAll(/"(\.\/[^\"]+)"/g)].map((m) => m[1]);
if (assets.length < 15) throw new Error("Offline manifest is unexpectedly short");
const missing = assets.filter((file) => !existsSync(join("public", file)));
if (missing.length) throw new Error(`Missing precache assets: ${missing.join(", ")}`);
for (const path of ["./world-shapes.json", "./js/app/fr-main.js", "./js/app/fr-cards.js", "./js/app/card-core.js", "./js/app/fr-memory.js", "./js/app/memory-core.js", "./js/app/fr-tester.js", "./js/app/fr-missions.js", "./js/app/fr-secours.js", "./js/app/fr-adventure.js", "./js/app/fr-adventure-engine.js", "./js/app/fr-terrain.js", "./js/app/offline-diagnostics.js", "./js/app/position-core.js", "./js/app/sos-message-core.js", "./js/app/emergency-copy.js", "./js/app/world-practices.js", "./js/app/fr-world.js", "./js/app/world-core.js", "./js/app/drills.js", "./js/app/guide.js", "./js/engine/drills.js"]) {
  if (!assets.includes(path)) throw new Error(`${path} is not precached`);
}
console.log(`${assets.length} offline files verified in the service worker manifest.`);
