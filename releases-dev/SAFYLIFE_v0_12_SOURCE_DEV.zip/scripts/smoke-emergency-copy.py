"""Chromium test for manual emergency-text fallback across FR/EN/ES.
The test uses set_content because network/file navigation is blocked in this environment;
it is NOT a real smartphone or a PWA offline-in-airplane-mode test.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

HTML=Path(__file__).resolve().parents[2].joinpath('SAFYLIFE_autonome.html').read_text(encoding='utf-8')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
    for language, intro in [('fr',"J'AI BESOIN D'AIDE"),('en','I NEED HELP'),('es','NECESITO AYUDA')]:
        context=browser.new_context(viewport={'width':360,'height':780})
        page=context.new_page();errors=[]
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.set_content(HTML,wait_until='domcontentloaded',timeout=30000)
        page.evaluate("lang=>localStorage.setItem('resilience-pocket:language:1',lang)", language) if False else None
        # A neutral about:blank origin blocks localStorage. Use the app's actual language switch.
        if language!='fr':
            page.evaluate("location.hash='#/monde';window.dispatchEvent(new Event('hashchange'))")
            page.wait_for_selector('#rp-world-language',timeout=12000)
            page.select_option('#rp-world-language',language)
        page.evaluate("location.hash='#/terrain';window.dispatchEvent(new Event('hashchange'))")
        target='#rp-sms-copy' if language=='fr' else '#rp-int-sms-copy'
        page.wait_for_selector(target,timeout=12000)
        # Force ALL automatic copy mechanisms to fail. Manual copy must remain possible.
        page.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,get:()=>undefined});document.execCommand=()=>false;")
        page.click(target)
        page.wait_for_selector('[data-manual-emergency-copy]:not([hidden])',timeout=8000)
        text=page.locator('[data-manual-emergency-copy] textarea').input_value()
        assert intro in text,(language,text[:100])
        assert len(text)>100
        assert errors==[],(language,errors)
        print(f'PASS {language}: manually selectable emergency message ({len(text)} characters), no JS errors')
        context.close()
    browser.close()
