from pathlib import Path
from playwright.sync_api import sync_playwright
src=Path('/mnt/data/SAFYLIFE_autonome.html').read_text(encoding='utf-8')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
 page.set_content(src)
 page.wait_for_selector('.rp-weekly-world')
 page.screenshot(path='/mnt/data/SAFYLIFE_APERCU_FINAL.png',full_page=True)
 page.evaluate('window.location.hash="#/terrain";window.dispatchEvent(new Event("hashchange"))')
 page.wait_for_selector('[data-sos-sound]')
 page.screenshot(path='/mnt/data/SAFYLIFE_SOS_FINAL.png',full_page=True)
 browser.close()
