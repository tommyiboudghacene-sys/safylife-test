from playwright.sync_api import sync_playwright
import subprocess, os, time, json, sys
root='/mnt/data/safylife_v8_dev/public'
server=subprocess.Popen([sys.executable,'-m','http.server','8766','--bind','127.0.0.1','--directory',root], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
try:
    with sync_playwright() as p:
        b=p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
        ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2, permissions=['geolocation'],geolocation={'latitude':48.8566,'longitude':2.3522,'accuracy':15})
        page=ctx.new_page()
        errors=[]
        page.on('pageerror', lambda e: errors.append(str(e)))
        url='http://127.0.0.1:8766/'
        try:
            page.goto(url,wait_until='domcontentloaded',timeout=15000)
            print('PWA HTTP:',page.title())
            page.goto(url+'#/terrain',wait_until='domcontentloaded',timeout=10000)
            print('SOS select',page.locator('#rp-terrain-country').count(),'FR number',page.get_by_text('112').count())
            page.locator('#rp-terrain-country').select_option('FR')
            print('FR number after setting:',page.locator('a[href="tel:112"]').count())
            page.locator('#rp-terrain-country').select_option('JP')
            print('JP number after setting:',page.locator('a[href="tel:119"]').count(),'police',page.locator('a[href="tel:110"]').count())
            page.get_by_role('button',name='Relever ma position').click()
            print('coords present',page.locator('.rp-coordinates').count())
            page.screenshot(path='/mnt/data/safylife_v8_sos_mobile.png')
            print('pageerrors',errors)
        except Exception as e:
            print('PWA HTTP smoke failed:',repr(e))
        try:
            page.goto('file:///mnt/data/SAFYLIFE_v8_autonome.html',wait_until='domcontentloaded',timeout=15000)
            print('Stand-alone title:',page.title())
            page.goto('file:///mnt/data/SAFYLIFE_v8_autonome.html#/terrain',wait_until='domcontentloaded',timeout=15000)
            print('standalone selection',page.locator('#rp-terrain-country').count())
            print('standalone errors',errors)
        except Exception as e: print('standalone smoke failed:',repr(e))
        b.close()
finally:
    server.terminate();server.wait()
