# SAFYLIFE — livraison consolidée du 23 novembre 2026

SAFYLIFE est une application **expérimentale de préparation aux catastrophes**, distribuable comme PWA après hébergement HTTPS, et sous forme d'un fichier HTML autonome. Elle **n'est pas** un système d'alerte officiel, ni un service de sauvetage certifié.

## Réalisé et vérifié dans cette livraison

- Prévention et préparation familiale ; exercices, fiches de secours, simulations et carte générale hors connexion ; interface principale français / anglais / espagnol (les fiches détaillées restent françaises).
- Écran SOS manuel : choix du pays, appel via le téléphone selon numéros vérifiés, demande GPS avec précision / ancienneté, partage manuel et SMS proposé à un proche ; aucun envoi automatique.
- Un contact SMS peut être **enregistré facultativement sur l'appareil**, uniquement après action explicite. Il est conservé en clair dans le stockage local du navigateur (donc visible par une personne ayant accès au téléphone). Il peut être supprimé et est compris dans l'effacement complet de SAFYLIFE.
- Option dans « Monde » : récupérer **sur demande** une liste des séismes mondiaux de magnitude 4,5+ observés au cours des sept derniers jours, depuis le flux public USGS. Pas de collecte de position GPS par cette fonction, ni suivi en arrière-plan, ni cache de ces données. Les observations **ne sont ni des alertes, ni des prédictions, ni des instructions d'évacuation**. Source officielle : https://earthquake.usgs.gov/earthquakes/feed/v1.0/geojson.php.
- Recommandations de prévention dans différents pays : fiches officielles archivées, rotation hebdomadaire locale et rappel de consultation volontaire via fichier calendrier `.ics` ; aucun envoi automatique de notification.
- Service worker limité aux fichiers publics propres à l'application et vérification de complétude du cache.

## Tests effectués dans l'environnement de développement

- Compilation TypeScript : réussite.
- 84 tests unitaires : réussis.
- 57 ressources PWA listées et présentes ; politique de cache SW testée en simulation (isolation et exclusion des données personnelles).
- Fichier HTML autonome construit et vérifié.
- Tests Chromium : 17 parcours de navigation ; contacts SMS (stockage simulé), choix des pays, numéro d'urgence, protections XSS sur le flux simulé, affichage 320, 360, 390, 768, 1024 px : réussis ; aucune exception JavaScript détectée sur ces parcours.

## Vérifications non réalisées et non revendiquées

- Test réel du GPS, du bouton SMS, de l'installation depuis un navigateur mobile et de la réouverture en mode avion sur de vrais Android/iPhone.
- Test réseau direct du flux USGS depuis cet environnement (accès réseau extérieur refusé). Le **format du flux** est documenté par l'USGS ; sa récupération effective reste à essayer depuis l'application hébergée.
- Validation indépendante et exhaustive des fiches de premiers secours dans les nombreux pays (les fiches détaillées concernent surtout la France).
- Notifications push mondiales, actualités automatisées, modération des informations : **non développées en production** ; nécessitent un fournisseur de contenu, un serveur d'envoi, le consentement des utilisateurs et une maintenance.
- Aucune intégration avec les centres de secours : impossible de garantir qu'un appel, un SMS ou une géolocalisation pourra être reçu, notamment sous les décombres sans réseau.
- La livraison consolidée n'a **pas** été publiée sur l'adresse publique actuelle : aucune action de déploiement sur ChatGPT Sites n'était disponible dans cette session.

## Livrables

- `SAFYLIFE_autonome.html` : démonstration autonome en un seul fichier, ouvrable hors connexion si le navigateur autorise les fichiers locaux. Certaines fonctions de stockage/partage peuvent être limitées en `file://`.
- `SAFYLIFE_PWA.zip` : fichiers prêts à héberger sous HTTPS, `index.html` à la racine de l'archive.
- `SAFYLIFE_PROJET_COMPLET.zip` : sources TypeScript, tests, scripts, licences et documentation.
- `SAFYLIFE_CHECKSUMS.json` : hachages SHA-256 et tailles pour contrôler les archives.

**Critère de publication fiable :** tests terrain sur appareils réels, revue des contenus d'urgence, accès sans connexion confirmé ; les fonctions encore absentes doivent être explicitement signalées dans l'app.

## Suite de la reprise du projet

- Test à la demande du cache PWA disponible depuis l'accueil : 57 fichiers dans le manifeste, diagnostic de complétude transmis par service worker ; disponible en trois langues. Affichage explicite que le contrôle ne remplace pas un essai physique en mode avion.
- Compatibilité d'installation : le bouton d'installation n'est plus proposé sur un hôte HTTP distant non sécurisé.
- Tests internes relancés : 84 tests unitaires passent, compilation et contrôle des 57 fichiers requis passent, essais de l'interface en Chromium simulé passent.
- **Pas de déploiement sur ChatGPT Sites.** Le quota Work déclaré atteint par l'utilisateur ne peut pas être réinitialisé dans cette conversation ; aucun accès d'édition ChatGPT Sites utilisable ici.


## Contrôle complémentaire du 24 novembre 2026 — SOS / presse-papiers

- Ajout d’une copie de secours pour le message SOS et les coordonnées lorsque `navigator.clipboard` est absent ou refuse l’accès : sélection via le presse-papiers historique du navigateur lorsque disponible.
- Si toutes les copies automatiques échouent, le texte exact est affiché dans un champ sélectionnable ; l’utilisateur peut le copier manuellement, sans réseau et sans transmission.
- Message et accès manuels testés dans l’interface française, anglaise et espagnole.
- Correction du partage de position depuis le SOS anglais/espagnol : le message généré respecte maintenant la langue choisie.
- Tests relancés dans l’environnement : **84/84 unitaires, compilation TypeScript réussie, 57 ressources de cache présentes**, test simulé du service worker réussi, parcours Chromium de navigation et test spécifique d’échec de copie réussis.
- **Non testé sur un vrai téléphone et non publié sur le site public.** Le contrôle de la PWA depuis un serveur local reste bloqué par `ERR_BLOCKED_BY_ADMINISTRATOR` dans cet environnement.


## Version 0.11.0 — reprise par Claude (24 novembre 2026)

Détail complet : `SAFYLIFE_TESTS_ET_LIMITES.md`.

- Service worker enregistré sur toute origine sécurisée (`isSecureContext`) ; testé dans un vrai Chromium avec vrai service worker : 14/14 routes affichées hors connexion après rechargement, démarrage à froid du SOS hors connexion OK.
- Navigation, accueil et badge hors connexion traduits FR/EN/ES ; bandeau « français uniquement » + accès SOS sur les pages non traduites.
- SOS/GPS : retour « recherche en cours », message de délai dépassé, suppression de formulations ambiguës (« alertes », « fichier autonome »).
- CSP stricte sur la PWA ; 0 violation axe-core sur 6 écrans clés.
- 46 pays avec numéro d'urgence sourcé (+ Mexique, Turquie, Philippines, Suisse, Afrique du Sud, Thaïlande, Indonésie, Norvège via GOV.UK).
- 88 tests unitaires réussis ; 8 parcours Chromium existants + 2 nouveaux réussis.
- Toujours non fait : test sur vrais téléphones, validation médicale/officielle, traduction professionnelle des fiches, déploiement (aucun accès ChatGPT Sites côté Claude).
