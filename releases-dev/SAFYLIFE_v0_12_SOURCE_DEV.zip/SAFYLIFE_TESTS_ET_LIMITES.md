# SAFYLIFE v0.11.0 — journal des corrections et des tests (24 novembre 2026, reprise par Claude)

Base : `SAFYLIFE_LIVRAISON_COMPLETE_24-11-2026.zip` (SHA-256 f0995163…c84c7f), récupérée depuis Google Drive. Aucun code réécrit de zéro ; corrections ciblées.

## Corrections apportées

| # | Domaine | Défaut constaté (preuve) | Correction |
|---|---|---|---|
| 1 | Offline / PWA | Le service worker ne s'enregistrait qu'en `https:` ou sur `localhost` : sur `127.0.0.1` aucun SW → c'est la vraie cause du blocage du test PWA local signalé précédemment. | Condition remplacée par `window.isSecureContext` (règle standard du navigateur). |
| 2 | Traduction | En anglais/espagnol, barre de navigation, onglets, lien « Aller au contenu », bouton Secours, badge hors connexion restaient en français (audit navigateur). | Interface persistante traduite FR/EN/ES (`CHROME_UI`). |
| 3 | Traduction | 6 blocs de l'accueil codés en dur en français (missions, rappel « Si un danger… », « Pour aller plus loin », etc.). | Traduits (`HOME_EXTRA`) ; 0 ligne française restante sur l'accueil EN/ES. |
| 4 | Traduction / sécurité | Pages encore françaises (premiers secours, guides, simulations…) affichées sans avertissement en EN/ES et déclarées `lang="en"`. | Bandeau « disponible en français uniquement » + bouton direct vers le SOS ; contenu marqué `lang="fr"`. Les fiches de premiers secours ne sont PAS traduites automatiquement (consignes vitales : relecture professionnelle requise). |
| 5 | SOS / GPS | EN/ES : aucun retour visuel pendant la recherche GPS (jusqu'à 15 s). | Message « recherche en cours » + zone `aria-live`. |
| 6 | SOS / GPS | Délai GPS dépassé confondu avec « indisponible ». | Message dédié FR/EN/ES (se rapprocher d'une fenêtre si c'est sans danger). |
| 7 | SOS (texte) | Accueil : lien « Centre d'urgence — Secours, GPS, **alertes** » laissait penser à des alertes ; page SOS PWA disait « ce fichier autonome ». | « Numéros, position, SMS manuel » ; « SAFYLIFE ne reçoit pas d'alertes ni de notifications en temps réel ». |
| 8 | Sécurité | Aucune Content-Security-Policy. | CSP stricte sur la PWA (`script-src 'self'`, connexions limitées à soi-même + `earthquake.usgs.gov`, `object-src 'none'`, `base-uri 'none'`) + `referrer no-referrer`. Retirée automatiquement du HTML autonome (scripts intégrés). 0 violation observée. |
| 9 | Accessibilité | axe-core : `label-content-name-mismatch` (logo) sur toutes les pages ; `aria-live` sur tout `<main>` (relecture de la page entière). | Nom accessible corrigé ; `aria-live` retiré, focus déplacé sur le contenu à chaque navigation. 0 violation axe ensuite. |
| 10 | Données mondiales | 38/237 pays avec numéro sourcé, absents : Mexique, Turquie, Afrique du Sud, Indonésie, Thaïlande, Philippines, Suisse, Norvège. | 8 pays ajoutés depuis les pages officielles GOV.UK « Getting help » consultées le 24/11/2026 → **46 pays**. Agences distinctes conservées (ex. Norvège 113 ambulance, 112 police). |

## Tests réellement exécutés sur cette version

| Contrôle | Résultat |
|---|---|
| `npm run qa` (TypeScript, tests unitaires, cache, SW simulé, HTML autonome) | **88/88** tests (84 d'origine + 4 nouveaux), 57 ressources, PASS |
| `scripts/test-pwa-real.py` — **vrai** serveur HTTP + **vrai** service worker Chromium + coupure réseau | SW actif, 58 entrées en cache, **14/14 routes affichées hors connexion après rechargement**, démarrage à froid du SOS hors connexion OK, 0 erreur JS, 0 violation CSP |
| Accessibilité axe-core 4 (accueil, SOS, secours, monde, préparer, liste) | **0 violation** |
| `scripts/smoke-sos-i18n.py` — GPS simulé refusé / délai / succès en FR/EN/ES, bandeau FR-only | PASS |
| `scripts/audit-i18n.py` — détection de français en EN/ES | Accueil, navigation, SOS, Monde : 0 ligne française |
| 8 parcours Chromium existants (product, delivery, emergency-copy, final, calendar, sound, home-global, current) | 8/8 PASS |

Scripts obsolètes (visent l'ancienne `SAFYLIFE_v8_autonome.html`) : `smoke-mobile.py`, `smoke-inmemory.py`, `smoke-v8-full.py`. Non utilisés.

Pour lancer les tests navigateur : `CHROME=/chemin/vers/chrome python3 scripts/test-pwa-real.py public 8781`.

## Ce que ces tests NE prouvent PAS

- Aucun essai sur **vrai téléphone** Android/iPhone : installation, mode avion réel, GPS matériel, ouverture du composeur d'appel/SMS. Le GPS est simulé.
- Aucun appel ni SMS réel ; ne jamais tester sur un numéro d'urgence réel.
- Pas de validation médicale ni validation officielle pays par pays. 46/237 pays ont un numéro sourcé ; les autres affichent « aucun numéro vérifié ».
- **Pas de déploiement** : Claude n'a pas d'accès à ChatGPT Sites. Le dossier `SAFYLIFE_PWA.zip` doit être publié par le propriétaire sur le site de test.

## Notifications — périmètre réaliste

| Option | Fiable ? | Décision |
|---|---|---|
| Rappels `.ics` importés dans le calendrier du téléphone (déjà présent) | Oui : notifiés par le système, même hors ligne, sans serveur | **Conservé, solution principale** |
| Rappel affiché à l'ouverture (30 jours, déjà présent) | Oui, mais seulement si l'app est ouverte | Conservé |
| Notifications push Web | Exige un serveur d'envoi, des clés, le consentement ; iPhone seulement si installée sur l'écran d'accueil | Non fait (serveur = engagement externe) |
| Periodic Background Sync | Chrome Android seulement, déclenchement non garanti | Non fiable, écarté |
| Alertes officielles de catastrophe | Ne doivent venir que des autorités (FR-Alert, Cell Broadcast…) | **Hors périmètre** ; liens vers sources officielles uniquement |

Les observations sismiques USGS restent sur demande et ne sont jamais présentées comme des alertes.
