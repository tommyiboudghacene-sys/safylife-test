# SAFYLIFE — projet consolidé (23 novembre 2026)

**Objet :** application gratuite de prévention des catastrophes, préchargée pour une utilisation sans Internet après installation, avec outils d'assistance manuelle. Il s'agit d'une **version fonctionnelle testable, pas d'un système d'alerte ou de sauvetage certifié**. L'application ne peut pas géolocaliser automatiquement un utilisateur pour les autorités et ne transmet aucune alerte de façon autonome.

## Ce qui fonctionne dans cette livraison

- Écran d'accueil orienté prévention, accès au SOS, partage volontaire et aide à l'installation sur un hébergement HTTPS.
- Accueil et interface SOS essentielles traduits en **français, anglais et espagnol**. La page « Monde » est également trilingue. Les fiches détaillées de premiers secours et les simulateurs sont **encore en français** ; l'application avertit l'utilisateur en anglais et en espagnol.
- Planification familiale, estimation de réserves, guides et premiers secours contextualisés pour la France, préparation aux coupures, entraînements et jeux facultatifs.
- Choix parmi **237 pays ou territoires** dans le sélecteur ; appels proposés uniquement quand un numéro correspondant au service est vérifié dans une source explicite. La liste des pays **n'implique pas 237 services d'urgence vérifiés**.
- SOS manuel : appel téléphonique via le système, demande GPS explicite, âge et précision du relevé, effacement des coordonnées, partage manuel et ouverture du composeur SMS pour un proche choisi. Le contact n'est pas mémorisé. **Le bouton SMS ne transmet rien tant que l'utilisateur n'envoie pas le message dans son téléphone.**
- Consignes simples à destination des personnes bloquées sous des décombres, avec source CDC, sans promesse de secours automatiques.
- Informations préventives datées provenant de sources officielles de France, Japon, Nouvelle-Zélande et États-Unis, accessibles hors connexion. **Ce ne sont ni des actualités ni des alertes en temps réel.** Liens vers les organismes officiels nécessitant Internet.
- Rappel de vérification des réserves tous les 30 jours **uniquement lors de l'ouverture de l'application** ; pas de notification push en arrière-plan.
- Données du foyer et GPS conservées localement, export/import JSON et suppression volontaire sur l'appareil.

## Utilisation

- `public/` : site PWA statique à héberger sur HTTPS ; lorsqu'un navigateur compatible le permet, l'utilisateur peut ajouter l'application à l'écran d'accueil. Le service worker est prévu pour enregistrer 57 fichiers indispensables. Test sur un véritable téléphone en mode avion requis avant diffusion.
- `SAFYLIFE_autonome.html` : version HTML tout-en-un avec textes, carte et styles, sans dépendance externe pour les fonctions préchargées. Un gestionnaire de fichiers Android peut afficher le **code source** plutôt que lancer le navigateur ; utiliser la PWA hébergée pour une installation normale.
- `src/` : TypeScript ; `tests/` : tests unitaires ; `scripts/` : contrôles de compilation, cache, intégrité et navigateur.

## Tests effectués dans l'environnement

- `npm run qa` : **84 tests unitaires réussis**, compilation TypeScript, **57 ressources hors connexion présentes**, tests du service worker, production et vérification de l'HTML autonome.
- `python scripts/smoke-product.py` : Chromium, **17 routes**, scénarios SOS avec plusieurs pays, GPS **simulé**, invalidité de numéro SMS, passage de langue FR/EN/ES, fiches de prévention internationale, largeur 320/390/768/1024 px, **aucune exception JavaScript observée** et **aucun débordement détecté sur ces écrans**.
- `python scripts/test-pwa-local.py` : essai de la PWA sur `127.0.0.1` **bloqué par l'environnement** (`ERR_BLOCKED_BY_ADMINISTRATOR`). Il serait faux d'en conclure que la PWA installée est validée en mode avion.

## Points bloquants pour une diffusion mondiale en tant qu'outil de secours

1. **Appels/SMS/GPS réels et mode avion sur Android/iPhone :** essais sur appareils physiques avec permissions, batterie faible, réseaux dégradés, sous-sol et absence de connexion.
2. **Transmission automatique aux secours :** absente. Nécessiterait un mécanisme fiable, un réseau disponible et des accords avec les autorités compétentes, sans garantie universelle de réception.
3. **Notifications régulières et actualités mondiales :** pas de service de notifications push, de pipeline d'édition et de modération multilingue ; des flux officiels vérifiés, un serveur et un protocole de mise à jour sont nécessaires.
4. **Validation internationale :** couverture des numéros d'urgence incomplète, traduction professionnelle de toutes les fiches, validation des conseils de premiers secours par des spécialistes et selon les juridictions, accessibilité, audit de sécurité et protection des données.
5. **Mise en ligne :** le site public de la version précédente n'a **pas** été modifié par ce lot ; les fichiers de ce répertoire sont prêts pour un déploiement sur HTTPS.

**Sécurité :** si une personne est réellement en danger, elle doit appeler les services d'urgence locaux si possible et suivre leurs instructions. Ne jamais déclencher d'appel de test sur un numéro d'urgence réel. L'application ne se substitue pas aux alertes officielles ou à une formation de secourisme.

## Confidentialité et licences

Ni inscription ni publicité ni télémétrie dans cette livraison. Le navigateur stocke les informations saisies en local sans chiffrement applicatif ; le téléphone et les exports JSON doivent être protégés. Le partage est volontaire. Consultez `LICENSE` et `NOTICES.md` pour les attributions : moteur issu d'Outage Ready (MIT) et contours cartographiques Natural Earth (domaine public). Licence GPL de Nomad Pocket non intégrée.

## Fonctions supplémentaires vérifiées le 23 novembre 2026

- Signal SOS *sonore local* manuel (durée maximale 30 secondes), sans émission de données ; ne remplace jamais un appel aux secours.
- Rappels de préparation par fichiers calendrier `.ics` à importer volontairement sur le téléphone. Aucun push automatique.
- Huit fiches internationales vérifiées dans trois langues, avec une sélection hebdomadaire hors connexion (pas un fil d'actualité en direct).

Voir `ETAT-DU-PROJET.md` pour les limites de sécurité, les tests réalisés et la mise en ligne encore non effectuée.

## Derniers compléments de SAFYLIFE

- Contact SMS optionnel enregistré localement **après clic**, jamais envoyé automatiquement. Il est conservé en clair sur le téléphone ; bouton d'effacement dans le SOS et dans la suppression complète des données.
- Section Monde : requête USGS **uniquement après clic** pour des séismes observés, magnitude 4,5+ sur sept jours. Les résultats ne constituent pas une alerte officielle. Sans accès réseau ou si l'USGS refuse la requête, un message d'indisponibilité est affiché ; les fiches préchargées continuent de fonctionner.
- Vérifications : `npm run qa`, puis `python scripts/smoke-final.py` et `python scripts/smoke-delivery.py` (dans un environnement contenant Chromium et Playwright). Les tests Chromium utilisent un moteur réel mais simulent le GPS, le réseau et le stockage dans certains parcours : **ils ne certifient pas le mode avion sur un vrai téléphone**.
- `ETAT-DU-PROJET.md` est le bilan exact des fonctions disponibles et des validations extérieures encore nécessaires.

## Vérifications supplémentaires dans la reprise sans Work (23 novembre 2026)

- Contrôle volontaire du cache hors connexion sur l'accueil, en français / anglais / espagnol. Un compte précis des fichiers préchargés n'est **pas** une validation en mode avion sur un vrai téléphone.
- Le contrôle reste visible dans le HTML autonome, où il indique honnêtement que les guides sont intégrés au fichier.
- Correction de l'offre d'installation sur les origines HTTP non sécurisées (HTTPS et localhost seulement).
- `npm run qa` : **84 tests unitaires réussis**, compilation TypeScript, 57 ressources PWA, simulation du service worker et vérification du HTML autonome.
- `python scripts/smoke-delivery.py` : parcours de contact de secours, numéros, affichage mobile et protections basiques réussis dans Chromium simulé. Contrôle manuel automatisé du nouveau bouton à 320 px : réussi.
- Le test Chromium en réseau local est toujours bloqué par `ERR_BLOCKED_BY_ADMINISTRATOR`. **Aucun essai réel en mode avion ni aucune publication sur ChatGPT Sites n'a été réalisé.**



## Contrôle complémentaire du 24 novembre 2026 — SOS / presse-papiers

- Ajout d’une copie de secours pour le message SOS et les coordonnées lorsque `navigator.clipboard` est absent ou refuse l’accès : sélection via le presse-papiers historique du navigateur lorsque disponible.
- Si toutes les copies automatiques échouent, le texte exact est affiché dans un champ sélectionnable ; l’utilisateur peut le copier manuellement, sans réseau et sans transmission.
- Message et accès manuels testés dans l’interface française, anglaise et espagnole.
- Correction du partage de position depuis le SOS anglais/espagnol : le message généré respecte maintenant la langue choisie.
- Tests relancés dans l’environnement : **84/84 unitaires, compilation TypeScript réussie, 57 ressources de cache présentes**, test simulé du service worker réussi, parcours Chromium de navigation et test spécifique d’échec de copie réussis.
- **Non testé sur un vrai téléphone et non publié sur le site public.** Le contrôle de la PWA depuis un serveur local reste bloqué par `ERR_BLOCKED_BY_ADMINISTRATOR` dans cet environnement.


## Version 0.11.0 (24 novembre 2026)

Voir `SAFYLIFE_TESTS_ET_LIMITES.md` : corrections offline/PWA, traductions de l'interface persistante, SOS/GPS, CSP, accessibilité, 46 pays sourcés, et tests réellement exécutés. Nouveaux scripts : `scripts/test-pwa-real.py`, `scripts/smoke-sos-i18n.py`, `scripts/audit-i18n.py`.
