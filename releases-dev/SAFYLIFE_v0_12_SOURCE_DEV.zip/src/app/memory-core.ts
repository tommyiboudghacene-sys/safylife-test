/** Offline memory game using original preparedness-themed picture pairs. */
export const MEMORY_ITEMS = [
  { id: "water", icon: "💧", label: "Eau" },
  { id: "radio", icon: "📻", label: "Radio" },
  { id: "bag", icon: "🎒", label: "Sac" },
  { id: "light", icon: "🔦", label: "Lampe" },
  { id: "firstaid", icon: "🩹", label: "Secours" },
  { id: "food", icon: "🥫", label: "Nourriture" },
  { id: "battery", icon: "🔋", label: "Batterie" },
  { id: "blanket", icon: "🧣", label: "Couverture" },
  { id: "papers", icon: "📄", label: "Papiers" },
  { id: "shoes", icon: "🥾", label: "Chaussures" },
  { id: "whistle", icon: "📣", label: "Sifflet" },
  { id: "compass", icon: "🧭", label: "Boussole" },
] as const;
export type MemoryLevel = 6 | 8 | 12;
export type Tile = { id: number; pair: string; icon: string; label: string };
export type MemoryRound = {
  level: MemoryLevel;
  tiles: Tile[];
  open: number[];
  matched: number[];
  attempts: number;
  finished: boolean;
};
export type FlipOutcome = "ignored" | "first" | "match" | "miss" | "finished";

function shuffle<T>(items: T[], random: () => number): T[] {
  const shuffled = [...items];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const value = random();
    const target = Math.floor(Math.max(0, Math.min(.999999, Number.isFinite(value) ? value : .5)) * (i + 1));
    [shuffled[i], shuffled[target]] = [shuffled[target]!, shuffled[i]!];
  }
  return shuffled;
}

export function createMemoryRound(level: MemoryLevel, random: () => number = Math.random): MemoryRound {
  if (![6, 8, 12].includes(level)) throw new Error("Invalid memory level");
  const set = MEMORY_ITEMS.slice(0, level).flatMap(item => [{ ...item }, { ...item }]);
  const tiles = shuffle(set, random).map((item, id) => ({ id, pair: item.id, icon: item.icon, label: item.label }));
  return { level, tiles, open: [], matched: [], attempts: 0, finished: false };
}

export function flipMemoryTile(state: MemoryRound, tileId: number): FlipOutcome {
  if (state.finished || state.open.length >= 2 || state.open.includes(tileId) || state.matched.includes(tileId)) return "ignored";
  const tile = state.tiles[tileId];
  if (!tile || tile.id !== tileId) return "ignored";
  state.open.push(tileId);
  if (state.open.length === 1) return "first";
  state.attempts++;
  const first = state.tiles[state.open[0]!]!;
  if (first.pair !== tile.pair) return "miss";
  state.matched.push(...state.open);
  state.open = [];
  if (state.matched.length === state.tiles.length) {
    state.finished = true;
    return "finished";
  }
  return "match";
}

export function hideMismatched(state: MemoryRound): void {
  if (state.open.length === 2) state.open = [];
}
