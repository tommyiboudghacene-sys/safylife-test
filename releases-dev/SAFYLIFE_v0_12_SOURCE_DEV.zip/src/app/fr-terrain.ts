import { html, mount } from "./ui.js";
import { additionalEmergencyNumbersFor, chooseCountry, countryOptions, emergencyFor, selectedCountry } from "./fr-world.js";
import { fixQuality, fixWarning, positionText } from "./position-core.js";
import { helpRequestText, normalizeTrustedNumber, smsDraftUrl } from "./sos-message-core.js";
import { loadFix, storeFix, forgetFix } from "./position-storage.js";
import { currentLanguage } from "./fr-world.js";
import { renderInternationalSos } from "./sos-international.js";
import { attachDistressSignal } from "./distress-signal.js";
import { loadTrustedContact, saveTrustedContact, deleteTrustedContact } from "./trusted-contact.js";
import { copyEmergencyText, revealEmergencyText } from "./emergency-copy.js";
import { requestGpsFix } from "./sos-gps.js";
import { shareEmergencyText } from "./sos-share.js";

export function renderTerrain(root: HTMLElement): void {
  const lang = currentLanguage();
  if (lang !== "fr") { renderInternationalSos(root, lang); return; }
  const fix = loadFix();
  const country = selectedCountry();
  const emergency = emergencyFor(country);
  const extraNumbers = additionalEmergencyNumbersFor(country);
  mount(root, html`
    <section class="rp-page-lead"><a href="#/" class="rp-back">← Accueil</a><span class="rp-eyebrow">Outils pratiques</span>
      <h1>Mon centre d'urgence 🧭</h1><p>Des informations utiles à garder sur ton téléphone. Les données personnelles ne sont pas envoyées par l'application.</p></section>
    <section class="rp-terrain-grid">
      <article class="card rp-terrain-emergency"><span class="rp-terrain-emoji">🆘</span><h2>Appeler à l'aide</h2>
        <label for="rp-terrain-country" class="rp-sos-country-label">🌍 Pays où tu te trouves (à vérifier)</label>
        <select id="rp-terrain-country" class="rp-sos-country"><option value="">Sélectionner mon pays</option>${countryOptions().map(v => html`<option value="${v.code}" ${country === v.code ? "selected" : ""}>${v.title}</option>`)}</select>
        <p class="hint">Le pays n'est pas détecté automatiquement. En voyage, sélectionne-le ici avant d'avoir besoin d'aide.</p>
        ${country && emergency ? html`<a href="tel:${emergency.number}" class="rp-call-btn rp-terrain-call">📞 ${emergency.number} ${emergency.kind === "ambulance" ? "(ambulance)" : emergency.kind === "fire-medical" ? "(pompiers / ambulance)" : "(urgence)"}</a>
          <p class="hint">Source officielle : <a href="${emergency.url}" target="_blank" rel="noopener noreferrer">${emergency.source}</a></p>` : html`<p class="feature-note">Aucun numéro national confirmé pour le pays actuellement sélectionné. <a href="#/monde">Sélectionner un pays.</a></p>`}
        ${extraNumbers.length ? html`<div class="rp-terrain-numbers">${extraNumbers.map(v => html`<a href="tel:${v.number}">${v.number} · ${v.type === "police-mobile" ? "Police (mobile)" : v.type === "police-landline" ? "Police (ligne fixe)" : "Police"}</a>`)}</div><p class="hint">Sources : ${extraNumbers.map(v => html`<a href="${v.url}" target="_blank" rel="noopener noreferrer">${v.source} (${v.number})</a>`)}</p>` : ""}
        ${country === "FR" ? html`<div class="rp-terrain-numbers"><a href="tel:15">15 · SAMU</a><a href="tel:17">17 · Police</a><a href="tel:18">18 · Pompiers</a><a href="sms:114">114 · SMS urgence*</a></div>
        <p class="hint">*Le 114 est destiné notamment aux personnes sourdes, malentendantes ou dans l'impossibilité de parler en France.</p>` : ""}
        <p class="hint">Un appel d'urgence nécessite un réseau téléphonique disponible. En cas de danger réel, suis les consignes des autorités locales.</p></article>
      <article class="card rp-terrain-gps"><span class="rp-terrain-emoji">📍</span><h2>Où suis-je ?</h2>
        <p>Demande la position au téléphone, puis affiche les coordonnées à transmettre aux secours si nécessaire. Le GPS peut fonctionner sans Internet si ton appareil capte les satellites.</p>
        <button class="btn primary block" id="rp-terrain-locate">📍 Relever ma position</button>
        <div id="rp-terrain-status" class="rp-terrain-status" aria-live="polite">${fix ? fixWarning(fix) : "Aucune position enregistrée."}</div>
        <div id="rp-terrain-coords">${fix ? html`<div class="rp-coordinates ${fixQuality(fix) === "stale" ? "rp-fix-stale" : ""}"><strong>${fix.latitude.toFixed(5)} ; ${fix.longitude.toFixed(5)}</strong><small>Relevé du ${new Date(fix.at).toLocaleString("fr-FR")} · précision estimée ± ${Math.round(fix.accuracy)} m</small><strong class="rp-fix-warning">${fixWarning(fix)}</strong></div>
          <div class="btn-row"><button class="btn" id="rp-terrain-share">📤 Partager / copier</button><button class="btn danger" id="rp-terrain-forget">Effacer</button></div>` : ""}</div>
        <p class="hint">La géolocalisation nécessite une autorisation et peut être indisponible dans certains navigateurs ou fichiers locaux. Les coordonnées peuvent être inexactes : vérifie toujours ton environnement. Rien n'est transmis sans ton action.</p>
      </article>
      <article class="card rp-sms-help"><span class="rp-terrain-emoji">✉️</span><h2>Préparer un SMS d'aide à un proche</h2>
        <p>Si tu ne peux pas parler, prépare un message avec la dernière position disponible. Un proche peut ensuite prévenir les secours. <strong>Ce n'est pas un SOS automatique.</strong></p>
        <label for="rp-sms-number">Numéro d'un proche de confiance (avec indicatif du pays si nécessaire)</label>
        <input id="rp-sms-number" type="tel" inputmode="tel" autocomplete="off" placeholder="Ex. +33 6 12 34 56 78" value="${loadTrustedContact() ?? ""}" aria-describedby="rp-sms-note">
        <p id="rp-sms-note" class="hint">Tu peux mémoriser volontairement ce numéro sur CE téléphone pour gagner du temps en urgence. Attention : il restera lisible par une personne ayant accès à ton appareil. SAFYLIFE ne l'envoie pas à un serveur. Tu dois vérifier et envoyer chaque SMS toi-même (réseau mobile nécessaire).</p>
        <div class="btn-row"><button type="button" class="btn" id="rp-sms-save-contact">Enregistrer sur ce téléphone</button><button type="button" class="btn danger" id="rp-sms-clear-contact">Effacer le numéro mémorisé</button></div>
        <div class="btn-row"><button class="btn primary" id="rp-sms-open">✉️ Ouvrir le SMS</button><button class="btn" id="rp-sms-copy">📋 Copier le message</button></div>
        <p id="rp-sms-status" class="hint" role="status" aria-live="polite"></p>
        <div data-manual-emergency-copy hidden class="rp-manual-copy"><label for="rp-manual-copy-text">Texte à copier manuellement</label><textarea id="rp-manual-copy-text" rows="6" readonly></textarea></div>
        <details class="rp-sms-preview"><summary>Voir le texte qui sera proposé</summary><pre id="rp-sms-preview-text" class="rp-message-preview">${helpRequestText(fix)}</pre></details>
      </article>
      <article class="card rp-sound-help"><span class="rp-terrain-emoji">🔊</span><h2>Signal sonore SOS · sans réseau</h2>
        <p>Si tu ne peux pas appeler, un son codé « SOS » peut aider à signaler ta présence à proximité. Monte le volume, puis déclenche le son volontairement. Il s'arrête au bout de 30 secondes pour économiser la batterie.</p>
        <button type="button" class="btn primary block" data-sos-sound>🔊 Émettre SOS sonore</button>
        <p data-sos-sound-status role="status" aria-live="polite" class="hint"></p>
        <p class="hint"><strong>Limite :</strong> ce son local ne transmet ni position, ni alerte, et peut être inaudible sous des décombres. Appelle les secours si possible. Arrête le son si cela te met en danger.</p>
      </article>
      <article class="card rp-trapped-advice"><span class="rp-terrain-emoji">🧱</span><h2>Coincé sous des décombres ?</h2>
        <p>Si tu es blessé ou bloqué après un séisme, évite de déplacer des éléments instables. Mets si possible un tissu devant ton nez et ta bouche pour limiter l'inhalation de poussière. Essaie de contacter les secours si le téléphone fonctionne ; sinon, signale ta présence en tapant sur une paroi ou un tuyau, ou avec un sifflet. Évite de crier constamment.</p>
        <p class="hint">L'appareil peut perdre le GPS et le réseau sous des débris. SAFYLIFE ne peut ni te retrouver toute seule, ni garantir l'arrivée des secours. <a href="https://www.cdc.gov/earthquakes/safety/stay-safe-after-an-earthquake.html" target="_blank" rel="noopener noreferrer">Source : CDC (États-Unis, Internet)</a>.</p>
      </article>
      <article class="card rp-terrain-info"><span class="rp-terrain-emoji">🔔</span><h2>Alertes officielles</h2>
        <p>Quand le réseau fonctionne, consulte directement les sources officielles. SAFYLIFE <strong>ne reçoit pas</strong> d'alertes ni de notifications en temps réel.</p>
        <div class="rp-terrain-linklist">${country === "FR" ? html`<a href="https://vigilance.meteofrance.fr/fr" target="_blank" rel="noopener noreferrer">🌦️ Vigilance Météo-France (France) <span>↗</span></a>
          <a href="https://www.fr-alert.gouv.fr/" target="_blank" rel="noopener noreferrer">📱 FR-Alert (France) <span>↗</span></a>` : ""}
          <a href="https://www.gdacs.org/" target="_blank" rel="noopener noreferrer">🌍 Catastrophes mondiales (GDACS) <span>↗</span></a></div>
      </article>
      <article class="card rp-terrain-info"><span class="rp-terrain-emoji">🗺️</span><h2>Carte et orientation</h2>
        <p>La <a href="#/monde">carte générale des pays</a> fonctionne hors connexion, mais <strong>ne montre ni routes, ni sentiers</strong>. Pour des cartes détaillées téléchargeables et un itinéraire sans réseau, un module séparé reste nécessaire.</p>
        <a class="btn block" href="https://www.openstreetmap.org/" target="_blank" rel="noopener noreferrer">🗺️ Ouvrir OpenStreetMap (Internet)</a>
        <p class="hint">Ne pas utiliser une carte non actualisée pour déterminer si une route ou une zone est sûre. Respecte les indications des autorités.</p>
      </article>
    </section>
    <section class="rp-terrain-next"><span>💚</span><div><h2>Déjà utilisable sans réseau</h2><p>Les <a href="#/secours">gestes de secours</a>, les <a href="#/guide">guides</a>, les <a href="#/simulations">simulations</a> et <a href="#/aventures">les aventures 72 heures</a> restent accessibles sans réseau une fois SAFYLIFE installé et ouvert au moins une fois en ligne.</p></div></section>`);

  attachDistressSignal(root, "fr");
  root.querySelector<HTMLSelectElement>("#rp-terrain-country")?.addEventListener("change", event => {
    chooseCountry((event.target as HTMLSelectElement).value);
    renderTerrain(root);
  });
  root.querySelector<HTMLButtonElement>("#rp-terrain-locate")?.addEventListener("click", async event => {
    const button = event.currentTarget as HTMLButtonElement;
    const status = root.querySelector<HTMLElement>("#rp-terrain-status")!;
    if (button.disabled) return; // Avoid overlapping device geolocation requests.
    button.disabled = true;
    status.textContent = "Recherche de ta position… Accepte l'autorisation si elle apparaît.";
    const result = await requestGpsFix(navigator.geolocation);
    // A navigation or country change replaces the button: never overwrite another screen.
    if (!button.isConnected || !root.contains(button)) return;
    button.disabled = false;
    if (result.ok) {
      if (!storeFix(result.fix)) { status.textContent = "Position non fiable ou invalide. Réessaie."; return; }
      renderTerrain(root);
    } else {
      status.textContent = result.reason === "unsupported" ? "Ce navigateur ne propose pas la géolocalisation."
        : result.reason === "denied" ? "Accès à la position refusé. Tu peux modifier l'autorisation du navigateur."
        : result.reason === "timeout" ? "Aucune position GPS en 15 secondes. Rapproche-toi d'une fenêtre ou de l'extérieur si c'est sans danger, puis réessaie."
        : "Position indisponible pour le moment. Réessaie à l'extérieur si nécessaire.";
    }
  });
  root.querySelector<HTMLButtonElement>("#rp-sms-save-contact")?.addEventListener("click",()=>{
    const input=root.querySelector<HTMLInputElement>("#rp-sms-number")!;
    const status=root.querySelector<HTMLElement>("#rp-sms-status")!;
    status.textContent=saveTrustedContact(input.value) ? "Contact enregistré uniquement sur cet appareil. Aucun SMS envoyé." : "Numéro invalide ou stockage indisponible.";
  });
  root.querySelector<HTMLButtonElement>("#rp-sms-clear-contact")?.addEventListener("click",()=>{
    const ok=deleteTrustedContact();
    if (ok) root.querySelector<HTMLInputElement>("#rp-sms-number")!.value="";
    root.querySelector<HTMLElement>("#rp-sms-status")!.textContent=ok ? "Contact supprimé de cet appareil." : "Impossible d'effacer le contact ici.";
  });
  root.querySelector<HTMLButtonElement>("#rp-sms-open")?.addEventListener("click", () => {
    const number = root.querySelector<HTMLInputElement>("#rp-sms-number")!.value;
    const status = root.querySelector<HTMLElement>("#rp-sms-status")!;
    if (!normalizeTrustedNumber(number)) { status.textContent = "Entre le numéro d'un proche (au moins 7 chiffres), jamais celui des secours."; return; }
    const ios = /iPhone|iPad|iPod/i.test(navigator.userAgent);
    const draft = smsDraftUrl(number, helpRequestText(loadFix()), ios);
    if (!draft) { status.textContent = "Impossible de préparer le SMS. Vérifie le numéro."; return; }
    status.textContent = "Ouverture de l'application SMS… Vérifie le destinataire et appuie sur Envoyer toi-même. L'envoi n'est jamais automatique.";
    window.location.href = draft;
  });
  root.querySelector<HTMLButtonElement>("#rp-sms-copy")?.addEventListener("click", async () => {
    const status = root.querySelector<HTMLElement>("#rp-sms-status")!;
    const message = helpRequestText(loadFix());
    if (await copyEmergencyText(message)) status.textContent = "Message copié. Colle-le dans un SMS ou une messagerie et vérifie le destinataire avant de l'envoyer.";
    else { revealEmergencyText(root, message, "Texte à copier manuellement"); status.textContent = "La copie automatique a échoué : sélectionne le texte affiché et copie-le manuellement."; }
  });
  root.querySelector<HTMLButtonElement>("#rp-terrain-forget")?.addEventListener("click", () => { forgetFix(); renderTerrain(root); });
  root.querySelector<HTMLButtonElement>("#rp-terrain-share")?.addEventListener("click", async event => {
    const button = event.currentTarget as HTMLButtonElement;
    const current = loadFix();
    if (!current || button.disabled) return;
    const text = positionText(current);
    const status = root.querySelector<HTMLElement>("#rp-terrain-status")!;
    button.disabled = true;
    const result = await shareEmergencyText(text, navigator.share?.bind(navigator));
    if (!button.isConnected || !root.contains(button)) return;
    button.disabled = false;
    if (result === "shared") status.textContent = "Partage demandé : vérifie le texte, la date et le destinataire avant l'envoi.";
    else if (result === "copied") status.textContent = "Coordonnées copiées. Tu peux les coller dans un message.";
    else if (result === "manual") { revealEmergencyText(root, text, "Coordonnées à copier manuellement"); status.textContent = "Le partage et la copie automatiques sont indisponibles : sélectionne le texte affiché."; }
    else status.textContent = "Partage annulé. Les coordonnées restent affichées.";
  });
}
