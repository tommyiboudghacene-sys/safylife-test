import { html, mount } from "./ui.js";
import { FICHES } from "./fr-secours.js";

/** Short, static preparedness cards; available without any network request. */
const CARDS = [
  {
    id: "before", icon: "🎒", title: "Avant toute crise",
    points: [
      "Conservez un plan familial sur papier : contacts, lieux de rendez-vous et besoins particuliers.",
      "Vérifiez vos réserves, médicaments personnels, lampes et batteries de secours.",
      "Téléchargez les informations nécessaires avant une coupure et mettez-les à jour régulièrement.",
    ],
    source: "Ready.gov — Make a Plan", url: "https://www.ready.gov/plan",
  },
  {
    id: "power", icon: "🔦", title: "Panne électrique",
    points: [
      "Utilisez une lampe à piles ou rechargeable et économisez la batterie du téléphone.",
      "Gardez le réfrigérateur et le congélateur fermés autant que possible.",
      "Ne faites jamais fonctionner un groupe électrogène, barbecue ou réchaud à combustible dans un lieu fermé : danger de monoxyde de carbone.",
    ],
    source: "Ready.gov — Power Outages", url: "https://www.ready.gov/power-outages",
  },
  {
    id: "water", icon: "💧", title: "Eau et hygiène",
    points: [
      "Stockez de l'eau potable avant une coupure. Les besoins varient selon les personnes, le climat et la durée.",
      "En cas d'alerte sur la qualité de l'eau, suivez les consignes des autorités locales.",
      "N'utilisez pas une eau suspecte pour boire ou préparer les aliments sans instructions fiables de traitement.",
    ],
    source: "Ready.gov — Water", url: "https://www.ready.gov/water",
  },
  {
    id: "flood", icon: "🌧️", title: "Inondation ou tempête",
    points: [
      "Écoutez les alertes officielles lorsque les réseaux fonctionnent.",
      "Ne marchez pas et ne conduisez pas dans l'eau de crue.",
      "Si une évacuation est ordonnée, suivez les itinéraires indiqués par les autorités.",
    ],
    source: "Ready.gov — Floods", url: "https://www.ready.gov/floods",
  },
  {
    id: "comms", icon: "📻", title: "Plus de réseau",
    points: [
      "Convenez à l'avance d'un point de rencontre et d'un contact extérieur à votre zone.",
      "Gardez les coordonnées importantes sur papier.",
      "Une radio à piles peut fournir des informations officielles si les autres réseaux sont interrompus.",
    ],
    source: "Ready.gov — Communication Plan", url: "https://www.ready.gov/plan",
  },
  {
    id: "conflict", icon: "🛡️", title: "Conflit armé : protéger les civils",
    points: [
      "Préparez à l'avance vos documents, moyens de communication, médicaments personnels et un lieu de regroupement familial.",
      "En cas d'alerte, les consignes de mise à l'abri ou d'évacuation des autorités compétentes priment sur cette application.",
      "Une simulation de réserves ne permet jamais de déterminer si un lieu est à l'abri des violences ou si un trajet est sûr.",
    ],
    source: "Ministère de l'Intérieur — Guide Tous responsables", url: "https://www.interieur.gouv.fr/documentation/ressources/guide-tous-responsables.html",
  },
  {
    id: "quake", icon: "🏚️", title: "Séisme : les premières secondes",
    points: [
      "À l'intérieur, baissez-vous, protégez votre tête et votre cou et abritez-vous sous un meuble solide si possible. Ne courez pas vers la sortie pendant les secousses.",
      "À l'extérieur, éloignez-vous des bâtiments et des fils électriques si vous pouvez le faire sans danger.",
      "Après les secousses, attendez-vous à des répliques. N'entrez pas dans un bâtiment endommagé et suivez les instructions des autorités.",
    ],
    source: "FEMA / Ready.gov — Earthquakes", url: "https://www.ready.gov/earthquakes",
  },
  {
    id: "wildfire", icon: "🔥", title: "Incendie de forêt : partir à temps",
    points: [
      "Repérez à l'avance les consignes locales, les itinéraires d'évacuation et les moyens de recevoir une alerte.",
      "Si les autorités ordonnent l'évacuation, partez selon leurs indications. N'improvisez pas un trajet à travers la fumée ou les flammes.",
      "Ne revenez qu'après autorisation ; les braises, arbres fragilisés et débris peuvent encore être dangereux.",
    ],
    source: "FEMA / Ready.gov — Wildfires", url: "https://www.ready.gov/wildfires",
  },
  {
    id: "pets", icon: "🐕", title: "Protéger les animaux",
    points: [
      "Prévoyez une cage ou une laisse adaptée, de l'eau, des aliments, les traitements habituels et les coordonnées du vétérinaire.",
      "Ajoutez des photos récentes, l'identification et les documents utiles à votre plan d'urgence.",
      "Pendant une alerte, rentrez les animaux à l'abri sans vous mettre en danger et suivez les consignes officielles.",
    ],
    source: "FEMA / Ready.gov — Prepare your pets", url: "https://www.ready.gov/pets",
  },
];

const normalize = (value: string): string => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("fr-FR");

export function renderGuide(root: HTMLElement): void {
  mount(root, html`
    <section class="feature-intro">
      <div class="feature-kicker">Bibliothèque locale · v0.5</div>
      <h1>Les essentiels, même sans réseau</h1>
      <p class="muted">Ces fiches sont incluses dans le fichier HTML. Tu peux les lire sans connexion.</p>
      <p class="feature-note">Ce ne sont pas des alertes en temps réel ni un substitut aux consignes locales des secours. Les liens sources nécessitent Internet.</p>
    </section>
    <section class="rp-guide-search"><label for="rp-guide-filter">🔎 Rechercher un conseil sans Internet</label>
      <input type="search" id="rp-guide-filter" placeholder="Ex. eau, séisme, brûlure, guerre…" autocomplete="off" aria-controls="rp-guide-results">
      <p id="rp-guide-count" role="status">${CARDS.length} guides de préparation et ${FICHES.length} fiches de secours.</p>
      <small>Recherche par mots dans les fiches enregistrées, sans IA ni connexion.</small></section>
    <section class="guide-grid" id="rp-guide-results">
      ${CARDS.map((card) => html`
        <article class="card guide-card" id="guide-${card.id}" data-guide-search="${normalize([card.title, ...card.points].join(" "))}">
          <div class="guide-icon" aria-hidden="true">${card.icon}</div>
          <h2>${card.title}</h2>
          <ul>${card.points.map((point) => html`<li>${point}</li>`)}</ul>
          <p class="hint">Source : <a href="${card.url}" target="_blank" rel="noopener noreferrer">${card.source}</a></p>
        </article>`)}
      ${FICHES.map(f => html`<a class="rp-aid-search-card" href="#/secours/${f.id}" data-guide-search="${normalize(`${f.title} ${f.signal} ${f.audience} ${f.steps.join(" ")}`)}"><span aria-hidden="true">${f.icon}</span><strong>${f.title}</strong><small>Fiche de premiers secours →</small></a>`)}
    </section>`);
  root.querySelector<HTMLInputElement>("#rp-guide-filter")?.addEventListener("input", event => {
    const query = normalize((event.target as HTMLInputElement).value).trim().split(/\s+/).filter(Boolean);
    let guides = 0;
    let secours = 0;
    root.querySelectorAll<HTMLElement>("[data-guide-search]").forEach(item => {
      const match = query.every(word => (item.dataset.guideSearch ?? "").includes(word));
      item.hidden = !match;
      if (match && item.classList.contains("guide-card")) guides++;
      else if (match) secours++;
    });
    root.querySelector<HTMLElement>("#rp-guide-count")!.textContent = `${guides} guide(s) et ${secours} fiche(s) de secours trouvé(s).`;
  });
}
