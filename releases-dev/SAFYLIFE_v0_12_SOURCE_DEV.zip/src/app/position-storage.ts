import { type Fix, validFix } from "./position-core.js";
/** Local GPS store shared by localized SOS screens; no network request. */
const KEY = "resilience-pocket:last-position:1"; // preserves legacy users
let transient: Fix | null = null;
export function loadFix(): Fix | null {
  if (transient) return transient;
  try { const value: unknown = JSON.parse(localStorage.getItem(KEY) ?? "null"); return validFix(value) ? value : null; }
  catch { return null; }
}
export function storeFix(fix: Fix): boolean {
  if (!validFix(fix)) return false;
  transient = fix;
  try { localStorage.setItem(KEY, JSON.stringify(fix)); } catch { /* session only */ }
  return true;
}
export function forgetFix(): void {
  transient = null;
  try { localStorage.removeItem(KEY); } catch { /* session only */ }
}
