import { SCENARIOS, runScenario, samplePlan, type Plan } from "../engine/index.js";
import { hasSetup, savePlan } from "./store.js";
import { html, mount } from "./ui.js";

type Mission = { id: string; icon: string; title: string; instruction: string; clue: string; urgent: boolean };
const IDS = ["mission:water", "mission:light", "mission:info", "mission:food", "mission:contact", "mission:bag"] as const;

/** The same home simulation that powers the crisis screens prioritizes these real-world checks. */
function buildMissions(plan: Plan): Mission[] {
  const needs = new Set(SCENARIOS.flatMap(s => runScenario(plan, s.id).result.unmetNeeds.map(n => n.id)));
  const i = plan.inventory;
  const waterRisk = needs.has("need:hydration");
  const foodRisk = needs.has("need:food");
  const infoRisk = needs.has("need:information") || needs.has("need:communication");
  const lightRisk = needs.has("need:light");
  const missions: Mission[] = [
    { id: "mission:water", icon: "💧", title: "La mission eau",
      instruction: "Avec un adulte, compte les bouteilles ou les réserves d'eau potable. Vérifiez où elles se trouvent.",
      clue: waterRisk ? "Des exemples de crise montrent un possible manque d'eau." : "Vérifie que l'eau reste accessible.", urgent: waterRisk },
    { id: "mission:light", icon: "🔦", title: "La chasse à la lampe",
      instruction: "Trouve une lampe qui marche sans prise. Avec un adulte, teste-la et vérifie les piles.",
      clue: i.flashlights === 0 ? "Aucune lampe n'est indiquée dans les réserves." : lightRisk ? "L'éclairage peut manquer dans certaines simulations." : "Connaître sa place peut faire gagner du temps.", urgent: lightRisk || i.flashlights === 0 },
    { id: "mission:info", icon: "📻", title: "Le message important",
      instruction: "Demande à un adulte comment écouter les consignes officielles si Internet et le téléphone ne fonctionnent plus.",
      clue: !i.batteryRadio ? "Aucune radio autonome n'est indiquée." : infoRisk ? "Les réseaux peuvent tomber en panne." : "Une radio peut être utile quand les réseaux s'arrêtent.", urgent: infoRisk || !i.batteryRadio },
    { id: "mission:food", icon: "🥫", title: "Le placard malin",
      instruction: "Avec un adulte, repère la nourriture qui se conserve et qui peut se manger sans cuisson.",
      clue: foodRisk ? "Certains exemples montrent un manque possible de nourriture." : "Il est utile de savoir où sont les provisions.", urgent: foodRisk },
    { id: "mission:contact", icon: "🤝", title: "Le rendez-vous secret",
      instruction: "En famille, choisissez un lieu de rendez-vous et une personne à joindre si vous êtes séparés. Notez-les sur papier.",
      clue: "Un plan familial aide quand les téléphones ne marchent pas.", urgent: !i.contacts.length },
    { id: "mission:bag", icon: "🎒", title: "Mon petit sac prêt",
      instruction: "Avec un adulte, rassemblez les affaires indispensables et adaptez le sac aux besoins de chacun.",
      clue: "Le sac permet de partir plus facilement si les autorités le demandent.", urgent: true },
  ];
  return missions.sort((a, b) => Number(b.urgent) - Number(a.urgent));
}

export function missionProgress(plan: Plan): { done: number; total: number } {
  const completed = new Set(plan.completedTasks);
  return { done: IDS.filter(id => completed.has(id)).length, total: IDS.length };
}

export function renderMissions(root: HTMLElement, actual: Plan): void {
  const demo = !hasSetup(actual);
  const plan = demo ? samplePlan() : actual;
  const missions = buildMissions(plan);
  const { done, total } = missionProgress(actual);
  mount(root, html`
    <section class="rp-mission-hero"><a class="rp-back" href="#/">← Accueil</a><span class="rp-eyebrow">Des petites actions, de vrais apprentissages</span><h1>Les missions de ma famille 🌟</h1><p>Un adulte t'accompagne. Fais les défis dans la vraie maison, puis coche ceux que vous avez vérifiés ensemble.</p>
      <div class="rp-mission-progress"><span class="rp-mission-progress-number">${done} <small>/ ${total} missions vérifiées</small></span><div class="rp-mission-track"><span style="width:${Math.round(done / total * 100)}%"></span></div></div>
      ${done === total && !demo ? html`<p class="rp-mission-win">🏅 Bravo ! Vous avez vérifié les six missions. Pensez à recommencer régulièrement.</p>` : ""}
    </section>
    ${demo ? html`<section class="feature-note">Ceci est un exemple avec un foyer imaginaire. <a href="#/setup">Ajoute les réserves de ta famille</a> avec un adulte pour enregistrer vos missions.</section>` : ""}
    <div class="rp-mission-grid">${missions.map(m => {
      const checked = actual.completedTasks.includes(m.id);
      return html`<article class="rp-mission-card ${checked ? "is-done" : ""}"><div class="rp-mission-card-top"><span class="rp-mission-icon" aria-hidden="true">${m.icon}</span><span class="rp-mission-state">${checked ? "✓ Vérifiée" : "À faire ensemble"}</span></div><h2>${m.title}</h2><p>${m.instruction}</p><div class="rp-mission-clue">💡 ${m.clue}</div><button class="rp-mission-check" type="button" data-mission="${m.id}" aria-pressed="${checked}" ${demo ? "disabled" : ""}>${checked ? "↶ Refaire cette mission" : "✓ Fait avec un adulte"}</button></article>`;
    })}</div>
    <section class="rp-mission-next"><span aria-hidden="true">📦</span><div><h2>Vous avez ajouté quelque chose à la maison ?</h2><p>Modifie ensuite tes réserves pour que les simulations utilisent les nouvelles quantités.</p><a class="btn primary" href="#/setup">Mettre à jour mes réserves →</a></div></section>
    <p class="rp-small-print">Une mission cochée signifie seulement que la famille déclare l'avoir vérifiée. Cela ne prouve pas qu'elle est prête ni en sécurité. En cas de danger réel, les consignes des autorités et des secours priment.</p>`);
  root.querySelectorAll<HTMLButtonElement>("[data-mission]").forEach(button => button.addEventListener("click", async () => {
    if (demo) return;
    const id = button.dataset.mission!;
    const doneSet = new Set(actual.completedTasks);
    if (doneSet.has(id)) doneSet.delete(id); else doneSet.add(id);
    actual.completedTasks = [...doneSet];
    await savePlan(actual);
    renderMissions(root, actual);
  }));
}
