/** Geolocation adapter for a user-initiated SOS action. Never sends or uploads position. */
import { type Fix, validFix } from "./position-core.js";

export type GpsResult = { ok: true; fix: Fix } | { ok: false; reason: "unsupported" | "denied" | "timeout" | "unavailable" };

export function requestGpsFix(geolocation: Pick<Geolocation, "getCurrentPosition"> | null | undefined): Promise<GpsResult> {
  if (!geolocation || typeof geolocation.getCurrentPosition !== "function")
    return Promise.resolve({ ok: false, reason: "unsupported" });
  return new Promise(resolve => {
    try {
      geolocation.getCurrentPosition(
        position => {
          const fix: Fix = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            at: position.timestamp,
          };
          resolve(validFix(fix) ? { ok: true, fix } : { ok: false, reason: "unavailable" });
        },
        error => resolve({ ok: false, reason: error.code === 1 ? "denied" : error.code === 3 ? "timeout" : "unavailable" }),
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 },
      );
    } catch {
      resolve({ ok: false, reason: "unavailable" });
    }
  });
}
