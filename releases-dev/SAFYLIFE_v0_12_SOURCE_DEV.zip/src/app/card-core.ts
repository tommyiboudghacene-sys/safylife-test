/**
 * Duel des éléments — a self-contained, original matching-card game.
 * No network, account or proprietary card artwork is required.
 */
export const ELEMENTS = [
  { id: "water", name: "Eau", icon: "💧", color: "#276fcd" },
  { id: "energy", name: "Énergie", icon: "⚡", color: "#bb6819" },
  { id: "nature", name: "Nature", icon: "🌱", color: "#27794f" },
  { id: "care", name: "Secours", icon: "🩹", color: "#bd475c" },
] as const;

export type ElementId = typeof ELEMENTS[number]["id"];
export type CardKind = "number" | "pause" | "plus2" | "wild";
export type Player = "human" | "bot";
export type Winner = Player | "draw";
export type Card = {
  id: number;
  element: ElementId | null;
  kind: CardKind;
  value: number;
};
export type Match = {
  deck: Card[];
  discard: Card[];
  hands: Record<Player, Card[]>;
  activeElement: ElementId;
  turn: Player;
  winner: Winner | null;
  turns: number;
  note: string;
};

const isElement = (value: string): value is ElementId =>
  ELEMENTS.some(item => item.id === value);

function shuffle<T>(items: T[], random: () => number): T[] {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const value = random();
    const j = Math.floor(Math.min(.99999999, Math.max(0, Number.isFinite(value) ? value : .5)) * (i + 1));
    [result[i], result[j]] = [result[j]!, result[i]!];
  }
  return result;
}

export function deckOfCards(): Card[] {
  let nextId = 0;
  const cards: Card[] = [];
  for (const element of ELEMENTS) {
    cards.push({ id: ++nextId, element: element.id, kind: "number", value: 0 });
    for (let number = 1; number <= 9; number++) {
      for (let copy = 0; copy < 2; copy++) cards.push({ id: ++nextId, element: element.id, kind: "number", value: number });
    }
    for (const kind of ["pause", "plus2"] as const) {
      for (let copy = 0; copy < 2; copy++) cards.push({ id: ++nextId, element: element.id, kind, value: 0 });
    }
  }
  for (let wild = 0; wild < 8; wild++) cards.push({ id: ++nextId, element: null, kind: "wild", value: 0 });
  return cards;
}

export function createMatch(random: () => number = Math.random): Match {
  const deck = shuffle(deckOfCards(), random);
  const human = deck.splice(0, 9);
  const bot = deck.splice(0, 9);
  const first = deck.findIndex(card => card.kind === "number");
  if (first < 0) throw new Error("The card deck has no numeric opening card");
  const starting = deck.splice(first, 1)[0]!;
  return {
    deck, discard: [starting], hands: { human, bot },
    activeElement: starting.element!, turn: "human", winner: null, turns: 0,
    note: "À toi ! Pose une carte de même couleur, de même numéro, ou un joker.",
  };
}

export function topCard(state: Match): Card {
  return state.discard[state.discard.length - 1]!;
}

export function cardName(card: Card): string {
  const element = ELEMENTS.find(e => e.id === card.element)?.name ?? "Multicolore";
  if (card.kind === "wild") return "Joker multicolore";
  if (card.kind === "pause") return "Pause " + element;
  if (card.kind === "plus2") return "+2 " + element;
  return String(card.value) + " " + element;
}

export function isPlayable(state: Match, card: Card): boolean {
  const top = topCard(state);
  return card.kind === "wild" || card.element === state.activeElement ||
    (card.kind === top.kind && (card.kind !== "number" || card.value === top.value));
}

function other(player: Player): Player { return player === "human" ? "bot" : "human"; }
function label(player: Player): string { return player === "human" ? "Tu" : "Le rival"; }

function pull(state: Match, count: number, random: () => number): number {
  let pulled = 0;
  for (let i = 0; i < count; i++) {
    if (!state.deck.length && state.discard.length > 1) {
      const top = state.discard.pop()!;
      state.deck = shuffle(state.discard, random);
      state.discard = [top];
    }
    const card = state.deck.pop();
    if (!card) break;
    state.hands[state.turn].push(card);
    pulled++;
  }
  return pulled;
}

function countTurn(state: Match): void {
  state.turns++;
  if (state.turns >= 600 && !state.winner) {
    const h = state.hands.human.length;
    const b = state.hands.bot.length;
    state.winner = h === b ? "draw" : h < b ? "human" : "bot";
    state.note = "La manche se termine après de nombreux tours.";
  }
}

export function playCard(state: Match, player: Player, cardId: number, chosenElement?: ElementId, random: () => number = Math.random): boolean {
  if (state.winner || state.turn !== player) return false;
  const index = state.hands[player].findIndex(c => c.id === cardId);
  if (index < 0) return false;
  const card = state.hands[player][index]!;
  if (!isPlayable(state, card) || (card.kind === "wild" && (!chosenElement || !isElement(chosenElement)))) return false;
  state.hands[player].splice(index, 1);
  state.discard.push(card);
  state.activeElement = card.kind === "wild" ? chosenElement! : card.element!;
  let note = label(player) + (player === "human" ? " poses " : " pose ") + cardName(card) + ".";
  if (state.hands[player].length === 0) {
    state.winner = player;
    state.note = player === "human" ? "🎉 Tu as gagné la manche !" : "Le rival gagne cette manche. Retente ta chance !";
    return true;
  }
  if (card.kind === "plus2") {
    state.turn = other(player);
    const drawn = pull(state, 2, random);
    state.turn = player;
    note += " " + (player === "human" ? `Le rival pioche ${drawn} cartes. À toi de rejouer.` : `Tu pioches ${drawn} cartes. Le rival rejoue.`);
  } else if (card.kind === "pause") {
    note += " Ton adversaire passe son tour !";
    state.turn = player;
  } else {
    state.turn = other(player);
    if (card.kind === "wild") note += " Nouvelle couleur : " + ELEMENTS.find(e => e.id === state.activeElement)!.name + ".";
  }
  state.note = note;
  countTurn(state);
  return true;
}

export function drawAndPass(state: Match, player: Player, random: () => number = Math.random): boolean {
  if (state.winner || state.turn !== player) return false;
  const drawn = pull(state, 1, random);
  state.note = label(player) + (player === "human" ? (drawn ? " pioches une carte et passes ton tour." : " ne peux plus piocher et passes ton tour.")
    : (drawn ? " pioche une carte et passe son tour." : " ne peut plus piocher et passe son tour."));
  state.turn = other(player);
  countTurn(state);
  return true;
}

function preferredElement(cards: Card[], random: () => number): ElementId {
  const counts = ELEMENTS.map(e => ({ id: e.id, n: cards.filter(card => card.element === e.id).length }));
  const max = Math.max(...counts.map(c => c.n));
  const options = counts.filter(c => c.n === max);
  return options[Math.floor(Math.min(.999999, Math.max(0, random())) * options.length)]!.id;
}

/** A deterministic local opponent; never calls a server. */
export function botAction(state: Match, random: () => number = Math.random): boolean {
  if (state.turn !== "bot" || state.winner) return false;
  const playable = state.hands.bot.filter(card => isPlayable(state, card));
  if (!playable.length) return drawAndPass(state, "bot", random);
  const score = (card: Card): number => {
    if (card.kind === "wild") return -100;
    if (card.kind === "plus2") return 25;
    if (card.kind === "pause") return 18;
    return card.value;
  };
  playable.sort((a, b) => score(b) - score(a));
  const choice = playable[0]!;
  const nextElement = choice.kind === "wild" ? preferredElement(state.hands.bot.filter(card => card.id !== choice.id), random) : undefined;
  return playCard(state, "bot", choice.id, nextElement, random);
}
