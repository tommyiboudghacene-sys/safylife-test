/** Human-triggered sharing of SOS text with a safe clipboard fallback.
 * A native sharing sheet can be dismissed without sending anything.
 * Never assumes that a recipient actually received the message.
 */
import { copyEmergencyText } from "./emergency-copy.js";

export type ShareResult = "shared" | "copied" | "manual" | "cancelled";
export async function shareEmergencyText(
  text: string,
  share: ((data: { text: string }) => Promise<void>) | undefined,
  copy: (text: string) => Promise<boolean> = copyEmergencyText,
): Promise<ShareResult> {
  if (!text.trim()) return "manual";
  if (share) {
    try {
      // Call the native API immediately within the click activation window.
      await share({ text });
      return "shared";
    } catch (error) {
      // A cancelled dialog is an explicit user choice; do not copy behind their back.
      if (error instanceof Error && error.name === "AbortError") return "cancelled";
      // Unsupported / denied native share: make the text available for manual sharing.
    }
  }
  try { return await copy(text) ? "copied" : "manual"; }
  catch { return "manual"; }
}
