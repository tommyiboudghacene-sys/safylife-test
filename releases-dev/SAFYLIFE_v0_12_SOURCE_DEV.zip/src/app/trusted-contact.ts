import { normalizeTrustedNumber } from "./sos-message-core.js";

/** An optional emergency contact, stored ONLY on this device when the user saves it.
 * It is not synced, encrypted or sent to any SAFYLIFE server. */
export const TRUSTED_CONTACT_KEY = "resilience-pocket:trusted-sms-number:1";
export function loadTrustedContact(storage?: Pick<Storage,"getItem">): string | null {
  try {
    const source = storage ?? localStorage;
    return normalizeTrustedNumber(source.getItem(TRUSTED_CONTACT_KEY) ?? "");
  } catch { return null; }
}
export function saveTrustedContact(phone: string, storage?: Pick<Storage,"setItem">): boolean {
  const valid = normalizeTrustedNumber(phone);
  if (!valid) return false;
  try { (storage ?? localStorage).setItem(TRUSTED_CONTACT_KEY, valid); return true; }
  catch { return false; }
}
export function deleteTrustedContact(storage?: Pick<Storage,"removeItem">): boolean {
  try { (storage ?? localStorage).removeItem(TRUSTED_CONTACT_KEY); return true; }
  catch { return false; }
}
