/** Optional, local-only calendar reminders for preventive habits.
 * SAFYLIFE never subscribes the user, sends email or schedules a background push.
 * A calendar entry exists only if the user imports the downloaded .ics file.
 */
import type { PracticeLanguage } from './world-practices.js';

export type ReminderKind = 'supplies' | 'world';

type ReminderText = { title: string; description: string };

const COPY: Record<PracticeLanguage, Record<ReminderKind, ReminderText>> = {
  fr: {
    supplies: { title: 'SAFYLIFE — Vérifier mes réserves', description: 'Contrôler eau, alimentation, médicaments, batteries et documents. Mettre à jour le kit familial. Ce rappel ne constitue pas une alerte officielle.' },
    world: { title: 'SAFYLIFE — Découvrir la prévention dans le monde', description: 'Consulter les ressources officielles récentes et apprendre comment se préparent différents pays. Pas d’alerte d’urgence ni d’information en temps réel provenant de SAFYLIFE.' },
  },
  en: {
    supplies: { title: 'SAFYLIFE — Review emergency supplies', description: 'Check water, food, medicines, batteries and documents. Update your family emergency kit. This is not an official alert.' },
    world: { title: 'SAFYLIFE — Learn from global preparedness', description: 'Review current official sources and discover preparedness practices worldwide. SAFYLIFE does not provide a real-time warning in this reminder.' },
  },
  es: {
    supplies: { title: 'SAFYLIFE — Revisar mis reservas', description: 'Revisar agua, alimentos, medicamentos, baterías y documentos. Actualizar el kit familiar. Esto no es una alerta oficial.' },
    world: { title: 'SAFYLIFE — Aprender prevención internacional', description: 'Consultar fuentes oficiales actuales y conocer la prevención en distintos países. Este recordatorio no es una alerta en tiempo real.' },
  },
};

/** RFC 5545 text escaping (CR/LF, comma, semicolon, backslash). */
export function escapeCalendarText(input: string): string {
  return input.replace(/\\/g, '\\\\').replace(/\r\n|\r|\n/g, '\\n').replace(/;/g, '\\;').replace(/,/g, '\\,');
}

/** RFC 5545 content lines must be folded after at most 75 UTF-8 octets. */
export function foldCalendarLine(line: string): string {
  const parts: string[] = [];
  let current = '';
  let bytes = 0;
  const encoder = new TextEncoder();
  for (const char of line) {
    const len = encoder.encode(char).length;
    if (bytes + len > 75 && current) { parts.push(current); current = ' '; bytes = 1; }
    current += char; bytes += len;
  }
  parts.push(current);
  return parts.join('\r\n');
}

function stampUtc(date: Date): string {
  const n = (v: number) => String(v).padStart(2, '0');
  return `${date.getUTCFullYear()}${n(date.getUTCMonth()+1)}${n(date.getUTCDate())}T${n(date.getUTCHours())}${n(date.getUTCMinutes())}${n(date.getUTCSeconds())}Z`;
}
function dateFloating(date: Date): string {
  const n = (v: number) => String(v).padStart(2, '0');
  return `${date.getFullYear()}${n(date.getMonth()+1)}${n(date.getDate())}T090000`;
}
function firstOccurrence(now: Date, kind: ReminderKind): Date {
  const next = new Date(now.getTime());
  next.setHours(12, 0, 0, 0);
  if (kind === 'world') next.setDate(next.getDate()+7);
  else {
    const date = next.getDate();
    next.setDate(1);
    next.setMonth(next.getMonth()+1);
    const lastDay = new Date(next.getFullYear(), next.getMonth()+1, 0).getDate();
    next.setDate(Math.min(date, lastDay));
  }
  return next;
}

/** Compatible with standard calendar apps that support .ics recurring VEVENT. */
export function calendarReminder(kind: ReminderKind, lang: PracticeLanguage, now = new Date()): string {
  if (!(now instanceof Date) || Number.isNaN(now.getTime())) throw new Error('Invalid date');
  const copy = COPY[lang][kind];
  const start = firstOccurrence(now, kind);
  // No personal identifiers or location in the exported file.
  const id = `safylife-${kind}-${stampUtc(now)}@offline.safylife.invalid`;
  const fields = [
    'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//SAFYLIFE//Preventive Calendar Reminder//EN', 'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH', 'BEGIN:VEVENT', `UID:${id}`, `DTSTAMP:${stampUtc(now)}`,
    `DTSTART:${dateFloating(start)}`, 'DURATION:PT15M',
    `RRULE:FREQ=${kind === 'world' ? 'WEEKLY' : 'MONTHLY'}`,
    `SUMMARY:${escapeCalendarText(copy.title)}`, `DESCRIPTION:${escapeCalendarText(copy.description)}`,
    'BEGIN:VALARM', 'ACTION:DISPLAY', `DESCRIPTION:${escapeCalendarText(copy.title)}`, 'TRIGGER:PT0M',
    'END:VALARM', 'END:VEVENT', 'END:VCALENDAR',
  ];
  return fields.map(foldCalendarLine).join('\r\n') + '\r\n';
}

/** Only called in response to a user click. Never initiates notification permission. */
export function downloadCalendarReminder(kind: ReminderKind, lang: PracticeLanguage): boolean {
  try {
    const blob = new Blob([calendarReminder(kind, lang)], {type:'text/calendar;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `SAFYLIFE-rappel-${kind}.ics`;
    document.body.append(a); a.click(); a.remove();
    // Revoke in a future task, not synchronously (iOS/Android download may start later).
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return true;
  } catch { return false; }
}
