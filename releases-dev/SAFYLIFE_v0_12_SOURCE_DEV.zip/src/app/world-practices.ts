/** Carefully selected, dated OFFLINE summaries of national guidance.
 * These are educational examples of preparedness, NOT live alerts.
 * For urgent safety, locally competent authorities always take precedence.
 */
export type PracticeLanguage = "fr" | "en" | "es";
export type WorldPractice = {
  region: string;
  icon: string;
  source: string;
  url: string;
  title: Record<PracticeLanguage, string>;
  detail: Record<PracticeLanguage, string>;
};

export const WORLD_PRACTICES_REVIEWED = "2026-11-23";
export const WORLD_PRACTICES: readonly WorldPractice[] = [
  {
    region: "FR", icon: "🎒", source: "Sécurité civile — France",
    url: "https://www.securite-civile.interieur.gouv.fr/reagir/comment-se-preparer-face-aux-risques/kit-durgence",
    title: { fr: "France : préparer un kit 72 heures", en: "France: prepare a 72-hour emergency kit", es: "Francia: preparar un kit de 72 horas" },
    detail: { fr: "Le kit conseillé réunit notamment eau, aliments sans cuisson, radio, éclairage, médicaments et copies des documents. Prépare-le avant la crise.", en: "The recommended kit includes water, shelf-stable food, radio, lighting, medications and copies of important documents. Prepare it before a crisis.", es: "El kit recomendado incluye agua, alimentos no perecederos, radio, luz, medicamentos y copias de documentos importantes. Prepáralo antes de una crisis." },
  },
  {
    region: "JP", icon: "🏠", source: "Cabinet du Premier ministre — Japon",
    url: "https://www.kantei.go.jp/jp/headline/bousai/sonae.html",
    title: { fr: "Japon : fixer les meubles avant un séisme", en: "Japan: secure furniture before an earthquake", es: "Japón: fijar los muebles antes de un terremoto" },
    detail: { fr: "Les consignes japonaises encouragent à fixer les meubles, prévoir eau et aliments et décider à l'avance comment la famille se contactera après une catastrophe.", en: "Japan's guidance recommends securing furniture, storing food and water, and agreeing in advance how family members will reconnect after a disaster.", es: "Las recomendaciones japonesas incluyen fijar los muebles, guardar agua y alimentos, y acordar de antemano cómo comunicarse con la familia después del desastre." },
  },
  {
    region: "NZ", icon: "🌊", source: "Get Ready — Défense civile, Nouvelle-Zélande",
    url: "https://getready.govt.nz/emergency/earthquakes",
    title: { fr: "Nouvelle-Zélande : s'entraîner au séisme", en: "New Zealand: practice earthquake drills", es: "Nueva Zelanda: practicar simulacros de terremoto" },
    detail: { fr: "Les autorités recommandent de s'entraîner à se baisser, s'abriter et s'agripper, et de préparer son plan familial. Les consignes en zone côtière dépendent notamment du risque de tsunami.", en: "Authorities recommend practicing Drop, Cover and Hold, and making a household plan. In coastal areas, local tsunami evacuation guidance is also crucial.", es: "Las autoridades recomiendan practicar agacharse, cubrirse y sujetarse, además de preparar un plan familiar. En zonas costeras también son esenciales las instrucciones locales sobre tsunamis." },
  },
  {
    region: "US", icon: "📍", source: "CDC — États-Unis",
    url: "https://www.cdc.gov/earthquakes/safety/stay-safe-after-an-earthquake.html",
    title: { fr: "États-Unis : se signaler sous des décombres", en: "United States: signal your location if trapped", es: "Estados Unidos: señalar tu ubicación si quedas atrapado" },
    detail: { fr: "Si tu es coincé sous des débris, protège-toi de la poussière. Si possible, envoie un message, frappe une surface ou utilise un sifflet pour te signaler aux sauveteurs.", en: "If trapped beneath debris, protect yourself from dust. If possible, send a text, tap on a wall or pipe, or use a whistle to help rescuers find you.", es: "Si quedas atrapado bajo escombros, protégete del polvo. Si es posible, envía un mensaje, golpea una pared o usa un silbato para que los rescatistas te encuentren." },
  },
  {
    region: "CA", icon: "🍁", source: "Sécurité publique Canada — Gouvernement du Canada",
    url: "https://www.canada.ca/fr/services/police/urgences/protection/preparez-vous/kits-urgence/obtenir-kit.html",
    title: { fr: "Canada : prévoir 72 heures d’autonomie", en: "Canada: prepare for 72 hours", es: "Canadá: prepararse para 72 horas" },
    detail: { fr: "Le Canada conseille de préparer progressivement une trousse pour au moins trois jours, en tenant compte des besoins du foyer si l’on doit évacuer ou rester chez soi.", en: "Canada advises building an emergency kit for at least three days, considering household needs for either sheltering at home or evacuating.", es: "Canadá recomienda preparar un kit para al menos tres días, considerando las necesidades del hogar tanto en una evacuación como al quedarse en casa." },
  },
  {
    region: "GB", icon: "📋", source: "Prepare — Gouvernement britannique",
    url: "https://prepare.campaign.gov.uk/",
    title: { fr: "Royaume-Uni : écrire son plan familial", en: "United Kingdom: make a household emergency plan", es: "Reino Unido: crear un plan familiar" },
    detail: { fr: "Le programme britannique Prepare propose un plan familial à télécharger et invite chacun à connaître les risques locaux, les contacts et les mesures à prendre avant une urgence.", en: "The UK Prepare programme offers a downloadable household plan and encourages people to identify local risks, contacts and steps to take before emergencies.", es: "El programa británico Prepare ofrece un plan familiar descargable y recomienda identificar riesgos locales, contactos y medidas antes de una emergencia." },
  },
  {
    region: "AU", icon: "🌧️", source: "NSW State Emergency Service — Australie",
    url: "https://www.ses.nsw.gov.au/plan-and-prepare/emergency-kit",
    title: { fr: "Australie : prévoir les départs rapides", en: "Australia: prepare a grab-and-go kit", es: "Australia: preparar un kit para salir rápido" },
    detail: { fr: "En Nouvelle-Galles du Sud, le service des urgences recommande de garder un kit prêt pour un départ rapide ou une coupure d’eau ou d’électricité, avec les besoins médicaux et les documents utiles.", en: "In New South Wales, the emergency service recommends keeping a kit ready for a quick evacuation or loss of water or power, including medical needs and key documents.", es: "En Nueva Gales del Sur, el servicio de emergencias recomienda tener un kit listo para evacuar o afrontar cortes de agua o luz, con necesidades médicas y documentos importantes." },
  },
  {
    region: "CL", icon: "🌋", source: "SENAPRED — Chili",
    url: "https://www.senapred.cl/kit-emergencia/",
    title: { fr: "Chili : adapter son kit aux risques et à sa famille", en: "Chile: tailor the emergency kit to your family", es: "Chile: adaptar el kit a los riesgos familiares" },
    detail: { fr: "Le SENAPRED chilien recommande un kit facile à trouver, contenant eau, aliments, lampe, radio et documents, à adapter aux nourrissons, aux besoins particuliers et aux animaux.", en: "Chile's SENAPRED recommends an easy-to-reach kit with water, food, light, radio and documents, adapted for babies, individual needs and pets.", es: "SENAPRED de Chile recomienda un kit accesible con agua, alimentos, luz, radio y documentos, adaptado a bebés, necesidades particulares y mascotas." },
  },

];
