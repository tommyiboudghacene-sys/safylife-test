import {
  SCENARIOS, formatHours, runScenario, samplePlan,
  type Plan, type ScenarioId, type SimulationResult,
} from "../engine/index.js";
import { renderProfil } from "./fr-profile.js";
import { renderJeux, renderChrono, renderKit, renderDecisions, exportGameScores, importGameScores } from "./fr-games.js";
import { renderCardDuel } from "./fr-cards.js";
import { renderMemory } from "./fr-memory.js";
import { renderGuide } from "./guide.js";
import { renderSecours } from "./fr-secours.js";
import { renderAdventures, renderAdventure, exportAdventureProgress, importAdventureProgress } from "./fr-adventure.js";
import { renderTerrain } from "./fr-terrain.js";
import { renderWorld } from "./fr-world.js";
import { renderTester } from "./fr-tester.js";
import { missionProgress, renderMissions } from "./fr-missions.js";
import { loadPlan, savePlan, hasSetup, normalizePlan, clearPlan } from "./store.js";
import { html, mount, toast } from "./ui.js";
import { initInstallSharing, setupInstallSharing } from "./install-share.js";
import { currentLanguage } from "./fr-world.js";
import { HOME_UI, HOME_EXTRA, CHROME_UI, FRENCH_ONLY_ROUTES } from "./home-i18n.js";
import { reviewDue, reviewDate, REVIEW_KEY } from "./review-core.js";
import { downloadCalendarReminder } from "./calendar-reminders.js";
import { currentWeeklyPractice } from "./weekly-practice.js";
import { parseOfflineCacheInventory } from "./offline-diagnostics.js";

const SCENE: Record<ScenarioId, { icon: string; title: string; detail: string; group: string }> = {
  power: { icon: "⚡", title: "Panne d'électricité", detail: "Plus de courant : des lumières et des appareils s'arrêtent.", group: "quotidien" },
  water: { icon: "💧", title: "Coupure d'eau", detail: "Le robinet ne donne plus d'eau pendant plusieurs jours.", group: "quotidien" },
  comms: { icon: "📵", title: "Téléphone et Internet coupés", detail: "Impossible d'utiliser le réseau mobile et Internet.", group: "quotidien" },
  "heat-power": { icon: "☀️", title: "Très forte chaleur", detail: "Il fait très chaud, sans électricité ni climatisation.", group: "quotidien" },
  storm: { icon: "🌊", title: "Tempête et inondation", detail: "Le vent et l'eau peuvent aussi couper des services.", group: "quotidien" },
  evacuation: { icon: "🚗", title: "Quitter la maison", detail: "Que préparer si les autorités demandent de partir ?", group: "quotidien" },
  "conflict-services": { icon: "🛡️", title: "Guerre : services coupés", detail: "Et si l'eau, le courant et les magasins ne fonctionnaient plus ?", group: "guerre" },
  "conflict-evac": { icon: "🧳", title: "Guerre : partir sur ordre", detail: "Comment préparer ses affaires si les autorités demandent de partir ?", group: "guerre" },
};

const NEEDS: Record<string, string> = {
  "need:hydration": "Eau potable pour le foyer",
  "need:food": "Nourriture suffisante",
  "need:food-safety": "Conservation des aliments au frais",
  "need:communication": "Communiquer avec ses proches et les secours",
  "need:information": "Recevoir des informations fiables",
  "need:light": "S'éclairer après la tombée de la nuit",
  "need:cooking": "Préparer un repas chaud",
  "need:cooling": "Se protéger de la chaleur",
  "need:mobility": "Se déplacer pour évacuer",
  "need:medical-device": "Alimenter un dispositif médical électrique",
};

const STOCKS: Record<string, string> = {
  "stored-water": "Eau stockée", "nonperishable-food": "Aliments non périssables",
  "perishable-food": "Aliments au réfrigérateur", "power-banks": "Batteries externes",
  "phone-battery": "Batterie des téléphones", "generator-fuel": "Carburant du générateur",
  "light-batteries": "Piles des lampes", cash: "Argent liquide", "fridge-cold": "Froid résiduel du réfrigérateur",
  "cooking-fuel": "Carburant du réchaud", "vehicle-fuel": "Carburant du véhicule",
};

function frHours(hours: number): string {
  if (!Number.isFinite(hours) || hours < 0) return "inconnu";
  const h = Math.round(hours);
  if (h === 0) return "immédiatement";
  const d = Math.floor(h / 24);
  const r = h % 24;
  return d ? `${d} j${r ? ` et ${r} h` : ""}` : `${h} h`;
}

function needName(id: string, plan: Plan): string {
  if (NEEDS[id]) return NEEDS[id];
  if (id.startsWith("need:med:")) {
    const med = plan.inventory.medications.find(m => id === `need:med:${m.id}`);
    return med ? `Traitement : ${med.label}` : "Réserve de traitement";
  }
  if (id.startsWith("need:cold:")) return "Conservation d'un traitement au froid";
  return "Autre besoin du foyer";
}

function preview(plan: Plan): Plan { return hasSetup(plan) ? plan : samplePlan(); }
function isWar(id: ScenarioId): boolean { return id.startsWith("conflict-"); }

type Action = { id: string; title: string; detail: string; level: "priorite" | "preparation" | "pendant" };

function makeActions(plan: Plan, id: ScenarioId, result: SimulationResult): Action[] {
  const h = plan.household.home;
  const inv = plan.inventory;
  const scenario = SCENARIOS.find(s => s.id === id)!;
  const down = (need: string) => result.unmetNeeds.some(n => n.id === need);
  const actions: Action[] = [];
  const add = (key: string, title: string, detail: string, level: Action["level"] = "preparation") => actions.push({ id: `fr:${key}`, title, detail, level });
  const people = plan.household.people.length;
  const days = result.durationHours / 24;
  const waterNeed = result.dailyWaterLiters * days;
  if (scenario.hazards.includes("tap-water") || (scenario.hazards.includes("grid-power") && h.waterSupply === "electric-pump")) {
    const deficit = Math.max(0, Math.ceil(waterNeed - inv.waterLiters));
    if (deficit) add("water", `Prévoir environ ${deficit} litre(s) d'eau potable supplémentaires`, `Calcul de travail pour ${people} personne(s), sur ${frHours(result.durationHours)}. Les besoins réels dépendent de la situation.`, "priorite");
    else add("water-check", "Contrôler la qualité et l'état des réserves d'eau", "Les quantités déclarées sont suffisantes selon cette hypothèse, pas nécessairement en pratique.");
  }
  if (down("need:food") || inv.foodPersonDays < people * days && scenario.hazards.includes("shops-closed")) {
    add("food", "Compléter la réserve d'aliments sans cuisson", "Vérifier les dates et les besoins des enfants, bébés et personnes ayant une alimentation particulière.", "priorite");
  }
  if (scenario.hazards.includes("grid-power")) {
    add("phone", "Recharger téléphones et batteries avant une coupure annoncée", "Prévoir de quoi rester informé et limiter la consommation d'énergie.");
    if (h.hasFridge) add("fridge", "Maintenir les appareils frigorifiques fermés", "La durée de conservation dépend de la température réelle. Respecter les recommandations sanitaires.", "pendant");
    if (inv.flashlights === 0) add("light", "Prévoir une lampe autonome", "Privilégier une lampe à piles ou rechargeable à une flamme nue.");
  }
  if (scenario.hazards.includes("mobile-network")) {
    add("family", "Définir deux points de rendez-vous et un contact hors zone", "Écrire ces informations sur papier.", "priorite");
    if (!inv.batteryRadio) add("radio", "Prévoir une radio autonome", "Permet de suivre des consignes quand les réseaux mobiles ne fonctionnent plus.");
  }
  if (scenario.shelter === "evacuate") {
    add("bag", "Préparer un kit d'urgence facilement transportable", "Papiers, médicaments personnels, eau, alimentation, vêtements et besoins spécifiques.", "priorite");
    if (!inv.vehicle.present) add("travel", "Préparer un moyen de déplacement autorisé", "En cas d'ordre d'évacuation, suivre exclusivement les instructions et itinéraires officiels.");
  }
  if (isWar(id)) {
    add("official", "Identifier les canaux d'alerte officiels", "La mise à l'abri et l'évacuation dépendent du danger et des consignes locales. Le modèle ne détermine pas la sécurité physique.", "priorite");
    add("papers", "Conserver les documents et contacts essentiels", "Préparer à l'avance les informations familiales et les besoins particuliers.");
  }
  if (!inv.firstAidKit) add("aid", "Composer une trousse de premiers secours", "L'adapter au foyer et vérifier régulièrement son contenu.");
  return actions;
}

function actionHtml(action: Action, plan: Plan, disabled: boolean) {
  const done = plan.completedTasks.includes(action.id);
  return html`<label class="rp-action ${done ? "done" : ""}"><input type="checkbox" data-task="${action.id}" ${done ? "checked" : ""} ${disabled ? "disabled" : ""}><span><strong>${action.title}</strong><small>${action.detail}</small></span></label>`;
}

function bindActions(root: HTMLElement, plan: Plan): void {
  root.querySelectorAll<HTMLInputElement>("[data-task]").forEach(input => input.addEventListener("change", async () => {
    const set = new Set(plan.completedTasks);
    if (input.checked) set.add(input.dataset.task!); else set.delete(input.dataset.task!);
    plan.completedTasks = [...set];
    await savePlan(plan);
    input.closest(".rp-action")?.classList.toggle("done", input.checked);
  }));
}

function renderAccueil(root: HTMLElement, actual: Plan): void {
  const demo = !hasSetup(actual);
  const progress = missionProgress(actual);
  const lang = currentLanguage();
  const t = HOME_UI[lang];
  const x = HOME_EXTRA[lang];
  const weekly = currentWeeklyPractice();
  let lastReview: number | null = null;
  try { const val = Number(localStorage.getItem(REVIEW_KEY)); lastReview = val > 0 ? val : null; } catch { /* blocked storage */ }
  const reviewNeeded = reviewDue(lastReview);
  mount(root, html`
    <section class="rp-welcome rp-safety-hero">
      <div class="rp-welcome-copy">
        <span class="rp-eyebrow"><span class="rp-sparkle" aria-hidden="true">✦</span> ${t.eyebrow}</span>
        <h1>${t.first} <em>${t.emphasis}</em></h1>
        <p>${t.desc}</p>
        <div class="rp-safety-hero-actions">
          <a class="rp-safety-primary" href="#/setup">🎒 ${t.prepare} <span aria-hidden="true">→</span></a>
          <a class="rp-safety-sos" href="#/terrain">🆘 ${t.sos} <span aria-hidden="true">→</span></a>
        </div>
        <small class="rp-safety-sos-note">${t.note}</small>
      </div>
      <div class="rp-welcome-art" aria-hidden="true"><div class="rp-art-sun">✦</div><div class="rp-art-cloud">☁</div><div class="rp-art-bag"><span>🎒</span></div></div>
    </section>
    <section class="rp-choices-section" aria-labelledby="rp-choices-title">
      <div class="rp-choices-heading"><div><span class="rp-eyebrow">${t.essential}</span><h2 id="rp-choices-title">${t.how}</h2></div></div>
      <div class="rp-main-choices">
        <a class="rp-main-choice rp-main-choice--bag" href="#/setup"><span class="rp-choice-icon" aria-hidden="true">🎒</span><span class="rp-main-choice-copy"><strong>${t.home}</strong><small>${t.homeSub}</small></span><span class="rp-choice-arrow" aria-hidden="true">↗</span></a>
        <a class="rp-main-choice rp-main-choice--discover" href="#/simulations"><span class="rp-choice-icon" aria-hidden="true">🌦️</span><span class="rp-main-choice-copy"><strong>${t.dangers}</strong><small>${t.dangersSub}</small></span><span class="rp-choice-arrow" aria-hidden="true">↗</span></a>
        <a class="rp-main-choice rp-main-choice--play" href="#/secours"><span class="rp-choice-icon" aria-hidden="true">🩹</span><span class="rp-main-choice-copy"><strong>${t.aid}</strong><small>${t.aidSub}</small></span><span class="rp-choice-arrow" aria-hidden="true">↗</span></a>
        <a class="rp-main-choice rp-main-choice--discover" href="#/monde"><span class="rp-choice-icon" aria-hidden="true">🌍</span><span class="rp-main-choice-copy"><strong>${t.world}</strong><small>${t.worldSub}</small></span><span class="rp-choice-arrow" aria-hidden="true">↗</span></a>
      </div>
    </section>
    <p class="rp-global-language-link"><a href="#/monde">🌐 ${t.lang} · Français / English / Español</a></p>
    <section class="card rp-weekly-world" aria-labelledby="rp-weekly-title">
      <div><span class="rp-eyebrow">🌍 ${t.weeklyEyebrow}</span><h2 id="rp-weekly-title">${weekly.icon} ${weekly.title[lang]}</h2><p>${weekly.detail[lang]}</p>
        <a href="#/monde" class="btn">${t.weeklyLink} →</a><p class="hint">${t.weeklyDisclaimer}</p></div>
    </section>
    ${currentLanguage() !== "fr" ? html`<p class="feature-note rp-locale-warning">${t.advanced}</p>` : ""}
    <section class="rp-share-prompt" aria-labelledby="rp-share-title">
      <div><span class="rp-eyebrow">${x.shareEyebrow}</span><h2 id="rp-share-title">${t.loved}</h2>
      <p>${t.lovedSub}</p>
      <div class="btn-row"><button class="btn primary" type="button" id="rp-app-share">📤 ${t.share}</button>
      <button class="btn" type="button" id="rp-app-install">📲 ${t.install}</button></div>
      <p id="rp-app-install-state" class="hint" role="status" aria-live="polite"></p></div>
    </section>
    <section class="card rp-offline-check" aria-label="${t.offlineCheck}">
      <div><h2>🔍 ${t.offlineCheck}</h2><p id="rp-check-offline-state" class="hint" role="status" aria-live="polite">${t.offlineInitial}</p></div>
      <div class="btn-row"><button class="btn" type="button" id="rp-check-offline">${t.offlineCheck}</button></div>
    </section>
    <section class="rp-monthly-review card" aria-labelledby="rp-review-title">
      <div class="rp-review-icon" aria-hidden="true">📆</div>
      <div><h2 id="rp-review-title">${t.reviewTitle}</h2><p>${reviewNeeded ? t.reviewDue : `${t.reviewOk} ${reviewDate(lastReview, lang === "fr" ? "fr-FR" : lang === "es" ? "es-ES" : "en-GB")}.`}</p>
      <small>${t.reviewNote}</small><div class="btn-row"><button class="btn" id="rp-review-done">✅ ${t.reviewDone}</button><a class="btn quiet" href="#/setup">${t.reviewEdit}</a></div></div>
    </section>
    <section class="card rp-calendar-reminders" aria-labelledby="rp-reminders-title">
      <div><span class="rp-eyebrow">📅 ${t.calendarEyebrow}</span><h2 id="rp-reminders-title">${t.calendarTitle}</h2><p>${t.calendarDetail}</p></div>
      <div class="btn-row"><button class="btn" type="button" id="rp-remind-supplies">📦 ${t.calendarSupplies}</button><button class="btn" type="button" id="rp-remind-world">🌍 ${t.calendarWorld}</button></div>
      <p id="rp-reminder-feedback" class="hint" role="status" aria-live="polite">${t.calendarNote}</p>
    </section>
    <section class="rp-mission-teaser"><span class="rp-mission-teaser-icon" aria-hidden="true">🌟</span><div><span class="rp-eyebrow">${x.missionEyebrow}</span><h2>${x.missionTitle}</h2><p>${x.missionDesc}</p><span class="rp-mission-mini-progress">${demo ? x.missionStart : x.missionDone.replace("{done}", String(progress.done)).replace("{total}", String(progress.total))}</span></div><a href="#/missions" class="rp-mission-teaser-link">${x.discover}</a></section>
    <section class="rp-gentle-reminder"><span class="rp-reminder-icon" aria-hidden="true">💛</span><div><strong>${x.realTitle}</strong><p>${x.realDesc}</p></div></section>
    <section class="rp-more-section" aria-label="${x.more}"><h2>${x.more}</h2><div class="rp-mini-grid">
      <a href="#/guide"><span aria-hidden="true">📖</span><strong>${x.reflexes}</strong><small>${x.reflexesSub}</small></a>
      <a href="#/setup"><span aria-hidden="true">🏠</span><strong>${x.supplies}</strong><small>${x.suppliesSub}</small></a>
      <a href="#/checklist"><span aria-hidden="true">✅</span><strong>${x.list}</strong><small>${x.listSub}</small></a>
      <a href="#/terrain"><span aria-hidden="true">🧭</span><strong>${x.center}</strong><small>${x.centerSub}</small></a>
      <a href="#/monde"><span aria-hidden="true">🌍</span><strong>${x.world}</strong><small>${x.worldSub}</small></a>
    </div></section>
    <section class="rp-adventure-teaser"><span class="rp-adventure-teaser-icon" aria-hidden="true">🎮</span><div><span class="rp-eyebrow">${x.trainEyebrow}</span><h2>${x.trainTitle}</h2><p>${x.trainDesc}</p></div><a href="#/drill" class="rp-adventure-teaser-link">${x.trainLink}</a></section>
    <a class="rp-test-invite" href="#/essai"><span aria-hidden="true">🎯</span><span><strong>${x.testTitle}</strong><small>${x.testSub}</small></span><span aria-hidden="true">→</span></a>
    ${demo ? html`<p class="rp-demo-note rp-demo-simple">${x.demoNote} <a href="#/setup">${x.demoLink}</a> ${x.demoTail}</p>` : ""}
    <p class="rp-small-print">${x.smallPrint}</p>`);
  setupInstallSharing(root);
  root.querySelector<HTMLButtonElement>("#rp-check-offline")?.addEventListener("click", async () => {
    const feedback = root.querySelector<HTMLElement>("#rp-check-offline-state");
    if (!feedback) return;
    if (document.body.dataset.mode === "standalone" || location.protocol === "file:") {
      feedback.textContent = t.offlineStandalone ?? ""; return;
    }
    if (!("serviceWorker" in navigator) || typeof MessageChannel === "undefined") {
      feedback.textContent = t.offlineUnavailable ?? ""; return;
    }
    feedback.textContent = t.offlineChecking ?? "";
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      const worker = navigator.serviceWorker.controller ?? registration?.active;
      if (!worker) { feedback.textContent = t.offlineUnavailable ?? ""; return; }
      const channel = new MessageChannel();
      let finished = false;
      const timeout = window.setTimeout(() => {
        if (finished) return;
        finished = true;
        feedback.textContent = t.offlineTimeout ?? "";
        channel.port1.close();
      }, 5000);
      channel.port1.onmessage = event => {
        if (finished) return;
        const status = parseOfflineCacheInventory(event.data);
        if (!status) return;
        finished = true;
        window.clearTimeout(timeout);
        const message = (status.ready ? t.offlineReady : t.offlinePartial) ?? "";
        feedback.textContent = message.replace("{count}", String(status.count)).replace("{total}", String(status.total));
        channel.port1.close();
      };
      try { worker.postMessage({ type:"SAFYLIFE_OFFLINE_STATUS" },[channel.port2]); }
      catch { finished = true; window.clearTimeout(timeout); channel.port1.close(); feedback.textContent = t.offlineUnavailable ?? ""; }
    } catch { feedback.textContent = t.offlineUnavailable ?? ""; }
  });
  for (const kind of ["supplies", "world"] as const) {
    root.querySelector<HTMLButtonElement>(`#rp-remind-${kind}`)?.addEventListener("click", () => {
      const ok = downloadCalendarReminder(kind, lang);
      const feedback = root.querySelector<HTMLElement>("#rp-reminder-feedback");
      if (feedback) feedback.textContent = (ok ? t.calendarDownloaded : t.calendarFailed) ?? "";
    });
  }
  root.querySelector<HTMLButtonElement>("#rp-review-done")?.addEventListener("click", () => {
    try { localStorage.setItem(REVIEW_KEY, String(Date.now())); }
    catch { toast(lang === "fr" ? "Enregistrement local indisponible" : "Local storage unavailable"); return; }
    renderAccueil(root, actual);
  });
}

function renderDangers(root: HTMLElement, actual: Plan): void {
  const demo = !hasSetup(actual);
  const plan = preview(actual);
  const summaries = SCENARIOS.map(s => ({ id: s.id, ...runScenario(plan, s.id).result }));
  const cards = (group: string) => summaries.filter(s => SCENE[s.id].group === group).map(r => {
    const scene = SCENE[r.id];
    const p = Math.max(0, Math.min(100, Math.round(r.sustainableHours / r.durationHours * 100)));
    return html`<a class="card rp-scenario-card ${scene.group === "guerre" ? "war" : ""}" href="#/scenario/${r.id}">
      <div class="rp-card-head"><span class="rp-scene-icon">${scene.icon}</span><span class="rp-tag">${frHours(r.durationHours)}</span></div>
      <h3>${scene.title}</h3><p>${scene.detail}</p>
      <div class="rp-meter-line"><span>${r.holdsFullDuration ? "Réserves suffisantes dans le calcul" : `Un manque possible après ${frHours(r.sustainableHours)}`}</span></div>
      <div class="meter ${r.holdsFullDuration ? "" : "danger"}"><i style="width:${p}%"></i></div>
      <div class="rp-card-link">Découvrir <span aria-hidden="true">→</span></div>
    </a>`;
  });
  mount(root, html`
    <section class="rp-page-lead"><a href="#/" class="rp-back">← Accueil</a><span class="rp-eyebrow">Découvrir et comprendre</span><h1>Et si ça arrivait&nbsp;?</h1><p>Choisis une situation pour voir ce qui pourrait manquer à la maison.</p></section>
    ${demo ? html`<p class="feature-note rp-demo-note">Exemple avec une famille imaginaire. <a href="#/setup">Ajouter mes réserves</a> avec un adulte.</p>` : ""}
    <section class="rp-section"><div class="rp-section-head"><div><div class="feature-kicker">6 situations</div><h2>Météo et coupures</h2></div></div><div class="rp-scenario-grid">${cards("quotidien")}</div></section>
    <section class="rp-section"><div class="rp-section-head"><div><div class="feature-kicker">2 situations</div><h2>Guerre et évacuation</h2></div></div><p class="feature-note">Ces exemples parlent des réserves en cas de conflit. Ils ne disent pas où il serait sûr de se mettre à l'abri. Suis toujours les autorités et les secours.</p><div class="rp-scenario-grid">${cards("guerre")}</div></section>`);
}

function renderSimulation(root: HTMLElement, actual: Plan, id: ScenarioId): void {
  const plan = preview(actual);
  const demo = !hasSetup(actual);
  const scene = SCENE[id];
  const { result } = runScenario(plan, id);
  const needs = [...result.unmetNeeds].sort((a,b) => b.severity - a.severity || (a.failsAt ?? 0)-(b.failsAt ?? 0));
  const actions = makeActions(plan, id, result);
  const stocks = result.stocks.filter(s => s.initial > 0 && STOCKS[s.id]);
  mount(root, html`
    <section class="rp-game-top"><a href="#/simulations">← Tous les dangers</a><span class="rp-tag">${isWar(id) ? "Guerre · Réserves" : "Exemple"}</span></section>
    <section class="rp-result-hero ${isWar(id) ? "war" : ""}"><div class="rp-scene-icon">${scene.icon}</div><h1>${scene.title}</h1><p>${scene.detail}</p><div class="rp-result-label">🔎 Ce que montre notre exemple</div><div class="rp-result-value">${result.holdsFullDuration ? "Pas de manque important dans le calcul" : `Un besoin pourrait manquer après ${frHours(result.sustainableHours)}`}</div><span class="hint">Exemple sur ${frHours(result.durationHours)}. Ce n'est pas une prévision réelle.</span></section>
    ${isWar(id) ? html`<section class="feature-note"><strong>Important :</strong> ces chiffres concernent les réserves du foyer, jamais la protection contre des attaques, des tirs ou des déplacements dangereux. En situation réelle, suivre les autorités et les secours.</section>` : ""}
    ${demo ? html`<p class="feature-note">Résultat sur un foyer de démonstration. <a href="#/setup">Personnaliser les données</a>.</p>` : ""}
    <section class="card"><h2>💧 Qu'est-ce qui pourrait manquer ?</h2><p class="muted">Cela dépend de ce que tu as à la maison.</p>
      ${needs.length ? html`<div class="rp-needs">${needs.slice(0, 3).map(n => html`<div class="rp-need"><span class="rp-need-time">${frHours(n.failsAt ?? 0)}</span><div><strong>${needName(n.id, plan)}</strong><small>${n.severity >= 4 ? "Très important" : "À surveiller"}</small></div></div>`)}</div>${needs.length > 3 ? html`<details class="rp-sim-options"><summary>Voir les ${Math.min(needs.length, 12) - 3} autres besoins</summary><div class="rp-needs">${needs.slice(3,12).map(n => html`<div class="rp-need"><span class="rp-need-time">${frHours(n.failsAt ?? 0)}</span><div><strong>${needName(n.id,plan)}</strong></div></div>`)}</div></details>` : ""}` : html`<p class="rp-good">Aucun manque détecté pour cet exemple. Ce n'est pas une garantie de sécurité.</p>`}
    </section>
    <section class="card"><h2>✅ Que peut-on préparer ?</h2><div class="rp-actions">${actions.slice(0, 3).map(a => actionHtml(a, plan, demo))}</div>${actions.length > 3 ? html`<details class="rp-sim-options"><summary>Voir les ${actions.length - 3} autres idées</summary><div class="rp-actions">${actions.slice(3).map(a => actionHtml(a,plan,demo))}</div></details>` : ""}</section>
    <section class="card rp-sim-options"><details><summary>⚙️ Changer la durée et voir les détails</summary><h3>Combien de jours pour notre exemple ?</h3><div class="rp-duration"><input id="rp-duration" type="range" min="24" max="336" step="24" value="${result.durationHours}" aria-label="Durée de l'exemple" ${demo ? "disabled" : ""}><output id="rp-duration-output">${frHours(result.durationHours)}</output></div><p class="hint">Modifier la durée ne prédit pas combien de temps durerait une crise réelle.</p><h3>Réserves dans le calcul</h3><div class="rp-stocks">${stocks.map(s => html`<div><span>${STOCKS[s.id]}</span><strong>${s.depletedAt === null ? "Tient sur la durée étudiée" : `Épuisée à ${frHours(s.depletedAt)}`}</strong></div>`)}</div></details></section>
    <div class="btn-row"><a class="btn primary" href="#/game/chrono/${id}">🎮 M'entraîner sur cette crise</a><a class="btn" href="#/setup">Modifier mes ressources</a></div>`);
  const duration = root.querySelector<HTMLInputElement>("#rp-duration");
  duration?.addEventListener("input", () => { root.querySelector<HTMLOutputElement>("#rp-duration-output")!.value = frHours(Number(duration.value)); });
  duration?.addEventListener("change", async () => {
    actual.durations[id] = Number(duration.value);
    await savePlan(actual);
    void route();
  });
  if (!demo) bindActions(root, actual);
}

function renderListe(root: HTMLElement, actual: Plan): void {
  const plan = preview(actual);
  const demo = !hasSetup(actual);
  const unique = new Map<string, Action>();
  for (const s of SCENARIOS) for (const action of makeActions(plan, s.id, runScenario(plan, s.id).result)) unique.set(action.id, action);
  const actions = [...unique.values()].sort((a,b) => ({priorite:0,preparation:1,pendant:2}[a.level] - {priorite:0,preparation:1,pendant:2}[b.level]));
  const done = actions.filter(a => plan.completedTasks.includes(a.id)).length;
  mount(root, html`
    <section class="feature-intro"><div class="feature-kicker">Liste personnelle</div><h1>Mon plan d'action</h1><p class="muted">${done} / ${actions.length} actions cochées. Liste établie selon les simulations ; les instructions locales en temps réel restent prioritaires.</p></section>
    ${demo ? html`<p class="feature-note">Liste de démonstration. <a href="#/setup">Configurer mes réserves</a> pour l'enregistrer.</p>` : ""}
    <section class="card"><div class="rp-actions">${actions.map(a => actionHtml(a, plan, demo))}</div></section>
    <section class="card"><h2>Sauvegarder mon plan</h2><p>Un fichier HTML autonome peut ne pas conserver tes données après fermeture, selon le navigateur. Exporte régulièrement un fichier de sauvegarde.</p><div class="btn-row"><a class="btn primary" href="#/data">Sauvegarde et import</a><a class="btn" href="#/print">Plan imprimable</a></div></section>`);
  if (!demo) bindActions(root, actual);
}

function renderImpression(root: HTMLElement, plan: Plan): void {
  const p = preview(plan);
  const inv = p.inventory;
  mount(root, html`
    <section class="print-plan"><h1>Plan familial de préparation</h1><p>Document personnel à garder aussi sur papier. Mis à jour : ${hasSetup(plan) ? new Date(plan.updatedAt).toLocaleDateString("fr-FR") : "démonstration"}</p>
      <h2>Foyer</h2><p>${p.household.people.length} personne(s) · Eau stockée : ${inv.waterLiters} L · Nourriture sans cuisson : ${inv.foodPersonDays} journée(s)-personnes</p>
      <h2>Moyens</h2><p>${inv.flashlights} lampe(s) · ${inv.powerBanks.length} batterie(s) externe(s) · Radio autonome : ${inv.batteryRadio ? "oui" : "non"}</p>
      <h2>Personnes à contacter</h2>${inv.contacts.length ? html`<ul>${inv.contacts.map(c => html`<li>${c.name} : ${c.phone}</li>`)}</ul>` : html`<p>À compléter : _________________________</p>`}
      <h2>Points de rendez-vous</h2><p>À proximité : _________________________</p><p>Hors du quartier : _________________________</p>
      <h2>Traitements</h2><p>${inv.medications.length ? inv.medications.map(m => `${m.label} (${Math.floor(m.dosesOnHand / Math.max(1,m.dosesPerDay))} jours de réserve)`).join(", ") : "Aucun traitement renseigné"}</p>
      <h2>Rappel</h2><p>En cas d'alerte réelle, écouter les autorités compétentes. Ce document ne donne aucune instruction sur la sûreté d'un itinéraire, d'un abri ou d'une zone de combat.</p>
    </section><div class="btn-row no-print"><button class="btn primary" id="rp-print">Imprimer / enregistrer en PDF</button><a class="btn" href="#/data">Exporter mes données</a></div>`);
  root.querySelector("#rp-print")?.addEventListener("click", () => window.print());
}

function renderSauvegarde(root: HTMLElement, plan: Plan): void {
  mount(root, html`
    <section class="feature-intro"><div class="feature-kicker">Mes données</div><h1>Sauvegarde et confidentialité</h1><p>Tout est stocké localement quand ton navigateur l'autorise. Un fichier HTML ouvert depuis les téléchargements peut perdre ses données après fermeture.</p></section>
    <section class="card"><h2>Exporter</h2><p>Crée une sauvegarde JSON du foyer, de ta liste, des scores et des aventures 72 heures.</p><button class="btn primary" id="rp-export">Télécharger ma sauvegarde</button></section>
    <section class="card"><h2>Importer</h2><p>Récupère une sauvegarde de SAFYLIFE, de Résilience Pocket ou d'Outage Ready. Le fichier reste sur ton téléphone.</p><input type="file" id="rp-import" accept="application/json,.json"><p class="hint" id="rp-import-status" role="status"></p></section>
    <section class="card"><h2>Effacer les données du foyer</h2><p>Supprime la configuration actuellement stockée dans ce navigateur. Cela ne supprime pas tes sauvegardes téléchargées.</p><button class="btn danger" id="rp-clear">Réinitialiser le foyer</button></section>
    <section class="card"><h2>Effacer toutes mes données de SAFYLIFE</h2><p>Efface sur cet appareil le foyer, les coordonnées GPS enregistrées, les pays et langues choisis, les scores et les aventures. Les guides hors connexion restent disponibles. Cette action est irréversible sans sauvegarde.</p><button class="btn danger" id="rp-wipe-all">Tout effacer sur cet appareil</button></section>`);
  root.querySelector("#rp-export")?.addEventListener("click", () => {
    const content = JSON.stringify({ app: "safylife", version: 4, exportedAt: new Date().toISOString(), plan, games: exportGameScores(), adventures: exportAdventureProgress() }, null, 2);
    const blob = new Blob([content], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url; anchor.download = "safylife-sauvegarde.json";
    document.body.append(anchor); anchor.click(); anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Sauvegarde préparée");
  });
  root.querySelector<HTMLInputElement>("#rp-import")?.addEventListener("change", async e => {
    const input = e.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    const status = root.querySelector<HTMLElement>("#rp-import-status")!;
    try {
      if (file.size > 2_000_000) throw new Error("Fichier trop volumineux (limite 2 Mo).");
      const parsed = JSON.parse(await file.text()) as { plan?: unknown; games?: unknown; adventures?: unknown };
      const source = parsed.plan ?? parsed;
      if (!source || typeof source !== "object" || !("household" in source) || !("inventory" in source)) throw new Error("Ce fichier n'est pas une sauvegarde reconnue.");
      const imported = normalizePlan(source);
      if (!Array.isArray(imported.household.people) || !imported.household.people.length) throw new Error("Le fichier ne contient aucun membre du foyer.");
      await savePlan(imported);
      if (parsed.games) importGameScores(parsed.games);
      if (parsed.adventures) importAdventureProgress(parsed.adventures);
      status.textContent = "Sauvegarde importée. Retour aux simulations…";
      location.hash = "#/";
    } catch (error) { status.textContent = `Import impossible : ${error instanceof Error ? error.message : "fichier non valide"}`; }
  });
  root.querySelector("#rp-wipe-all")?.addEventListener("click", async () => {
    if (!window.confirm("Tout effacer : foyer, position GPS, pays, scores et aventures sur cet appareil ? Pense à exporter avant.")) return;
    await clearPlan();
    try {
      const keys: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith("resilience-pocket:")) keys.push(key);
      }
      for (const key of keys) localStorage.removeItem(key);
    } catch { /* storage may be unavailable, e.g. file:// */ }
    location.hash = "#/";
    location.reload(); // reinitialize session-only caches as well as persistent state
  });
  root.querySelector("#rp-clear")?.addEventListener("click", async () => {
    if (!window.confirm("Supprimer la configuration de ton foyer sur cet appareil ?")) return;
    await clearPlan();
    location.hash = "#/";
    void route();
  });
}

let offlineMessageKey = "";
function applyChrome(page: string): void {
  const c = CHROME_UI[currentLanguage()];
  const setText = (sel: string, text: string) => { const el = document.querySelector<HTMLElement>(sel); if (el) el.textContent = text; };
  setText(".skip", c.skip);
  document.querySelector(".brand")?.setAttribute("aria-label", c.brand);
  const top: Record<string, string> = { "#/": c.home, "#/terrain": c.sos, "#/setup": c.prepare, "#/simulations": c.dangers, "#/monde": c.world, "#/drill": c.drill, "#/secours": `🩹 ${c.aid}` };
  for (const link of document.querySelectorAll<HTMLAnchorElement>(".topnav a")) { const v = top[link.getAttribute("href") ?? ""]; if (v) link.textContent = v; }
  const tabs: Record<string, string> = { "#/": c.home, "#/terrain": c.sos, "#/setup": c.prepareShort, "#/monde": c.world };
  for (const link of document.querySelectorAll<HTMLAnchorElement>(".tabbar a")) {
    const label = link.querySelector<HTMLElement>("span:not(.rp-tab-emoji)"); const v = tabs[link.getAttribute("href") ?? ""];
    if (label && v) label.textContent = v;
  }
  for (const nav of document.querySelectorAll("nav.topnav, nav.tabbar")) nav.setAttribute("aria-label", c.navLabel);
  const fab = document.querySelector<HTMLElement>(".rp-aid-fab");
  if (fab) { fab.setAttribute("aria-label", c.aidAria); const span = fab.querySelector("span"); if (span) span.textContent = c.aid; }
  if (!offlineMessageKey) setText("#offline-badge", c.offline);
  else setText("#offline-badge", (c as Record<string, string>)[offlineMessageKey] ?? c.offline);
  void page;
}

function selectNav(page: string): void {
  const key = page === "game" ? "drill" : page === "scenario" ? "simulations" : page === "missions" ? "" : page;
  for (const link of document.querySelectorAll<HTMLAnchorElement>("nav a")) {
    const current = link.getAttribute("href") === (key ? `#/${key}` : "#/");
    if (current) link.setAttribute("aria-current", "page"); else link.removeAttribute("aria-current");
  }
}

let testerSessionActive = false;
async function route(): Promise<void> {
  const plan = await loadPlan();
  const [page = "", a, b] = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean);
  const previous = document.getElementById("main")!;
  const root = previous.cloneNode(false) as HTMLElement;
  previous.replaceWith(root);
  if (typeof window.scrollTo === "function") window.scrollTo({ top: 0 });
  if (page === "essai") testerSessionActive = true;
  selectNav(page);
  document.documentElement.lang = currentLanguage();
  applyChrome(page);
  switch (page) {
    case "": renderAccueil(root, plan); break;
    case "simulations": renderDangers(root, plan); break;
    case "missions": renderMissions(root, plan); break;
    case "aventures": renderAdventures(root); break;
    case "aventure": renderAdventure(root, preview(plan), a ?? "", !hasSetup(plan)); break;
    case "terrain": renderTerrain(root); break;
    case "monde": renderWorld(root); break;
    case "essai": renderTester(root, () => { testerSessionActive = false; location.hash = "#/"; void route(); }); break;
    case "secours": renderSecours(root, a); break;
    case "setup": renderProfil(root, plan); break;
    case "drill": renderJeux(root, !hasSetup(plan)); break;
    case "game":
      if (a === "chrono") renderChrono(root, preview(plan), b);
      else if (a === "kit") renderKit(root);
      else if (a === "decision") renderDecisions(root, b);
      else if (a === "cards") renderCardDuel(root);
      else if (a === "memory") renderMemory(root);
      else location.hash = "#/drill";
      break;
    case "scenario":
      if (a && SCENARIOS.some(s => s.id === a)) renderSimulation(root, plan, a as ScenarioId);
      else location.hash = "#/";
      break;
    case "guide": renderGuide(root); break;
    case "checklist": renderListe(root, plan); break;
    case "print": renderImpression(root, plan); break;
    case "data": renderSauvegarde(root, plan); break;
    default: location.hash = "#/";
  }
  if (testerSessionActive && page !== "essai") {
    const returnLink = document.createElement("a");
    returnLink.href = "#/essai";
    returnLink.className = "rp-tester-return";
    returnLink.textContent = CHROME_UI[currentLanguage()].testReturn;
    root.prepend(returnLink);
  }
  const chrome = CHROME_UI[currentLanguage()];
  if (chrome.frOnly && FRENCH_ONLY_ROUTES.has(page)) {
    const notice = document.createElement("div");
    notice.className = "feature-note rp-locale-warning rp-fr-only";
    notice.setAttribute("lang", currentLanguage());
    notice.setAttribute("role", "note");
    const p = document.createElement("p"); p.textContent = chrome.frOnly;
    const a = document.createElement("a"); a.href = "#/terrain"; a.className = "btn"; a.textContent = `🆘 ${chrome.frOnlySos}`;
    notice.append(p, a);
    root.prepend(notice);
    root.setAttribute("lang", "fr");
  }
}

initInstallSharing();
window.addEventListener("hashchange", () => { void route().then(() => document.getElementById("main")?.focus({ preventScroll: true })); });
document.querySelector<HTMLAnchorElement>(".skip")?.addEventListener("click", e => {
  e.preventDefault();
  document.getElementById("main")?.focus();
});
void route();

const offline = document.getElementById("offline-badge");
function offlineBadge(key: string): void {
  offlineMessageKey = key;
  const message = (CHROME_UI[currentLanguage()] as Record<string, string>)[key] ?? key;
  if (offline) { offline.textContent = message; offline.hidden = false; }
}
/** Ask the ACTIVE worker to verify every required file is stored locally. */
function verifyOfflineCache(registration: ServiceWorkerRegistration): void {
  const worker = navigator.serviceWorker.controller ?? registration.active;
  if (!worker || typeof MessageChannel === "undefined") {
    offlineBadge("badgeCheck");
    return;
  }
  const channel = new MessageChannel();
  let done = false;
  const timeout = window.setTimeout(() => {
    if (!done) offlineBadge("badgeCheck");
    channel.port1.close();
  }, 5000);
  channel.port1.onmessage = event => {
    if (event.data?.type !== "SAFYLIFE_OFFLINE_STATUS") return;
    done = true;
    window.clearTimeout(timeout);
    offlineBadge(event.data.ready
      ? (navigator.onLine ? "badgeReadyOnline" : "badgeReadyOffline")
      : "badgePartial");
    channel.port1.close();
  };
  try { worker.postMessage({ type: "SAFYLIFE_OFFLINE_STATUS" }, [channel.port2]); }
  catch { window.clearTimeout(timeout); offlineBadge("badgeCheck"); }
}
if (document.body.dataset.mode === "standalone" || location.protocol === "file:") {
  offlineBadge("badgeBundled");
} else if ("serviceWorker" in navigator && window.isSecureContext) {
  offlineBadge("badgeInstalling");
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js")
      .then(async registration => {
        await navigator.serviceWorker.ready;
        verifyOfflineCache(registration);
        navigator.serviceWorker.addEventListener("controllerchange", () => verifyOfflineCache(registration));
        window.addEventListener("online", () => { void registration.update().catch(() => {}); verifyOfflineCache(registration); });
      })
      .catch(() => offlineBadge("badgeFailed"));
  });
} else {
  offlineBadge("badgeUnverified");
}
