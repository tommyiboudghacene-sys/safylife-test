/** Local-only maintenance reminder. It is shown WHEN THE APP IS OPEN,
 * and must never be described as a background push notification. */
export const REVIEW_KEY = "resilience-pocket:preparedness-review:1";
export const REVIEW_DAYS = 30;
export function reviewDue(last: unknown, now = Date.now()): boolean {
  if (typeof last !== "number" || !Number.isFinite(last) || last <= 0 || last > now + 60_000) return true;
  return now - last >= REVIEW_DAYS * 86400_000;
}
export function reviewDate(last: unknown, locale = "fr-FR"): string | null {
  if (typeof last !== "number" || !Number.isFinite(last) || last <= 0 || last > Date.now() + 60_000) return null;
  return new Date(last).toLocaleDateString(locale, { year: "numeric", month: "long", day: "numeric" });
}
