/** User-activated *local* Morse SOS sound. NOT a digital distress beacon.
 * No location, audio, network request or personal data leaves the device.
 * The signal may not be audible through debris and should never replace an emergency call.
 */
import type { PracticeLanguage } from './world-practices.js';

export type DistressTone = { at: number; duration: number };
export const DISTRESS_MAX_MS = 30_000;
export const DISTRESS_UNIT_MS = 200;

/** International Morse: ... --- ... with proper inter-letter gaps. */
export function morseSosTones(unit = DISTRESS_UNIT_MS): readonly DistressTone[] {
  if (!Number.isFinite(unit) || unit < 50 || unit > 1_000) throw new Error('Invalid Morse unit');
  const sequence: number[][] = [[1,1,1], [3,3,3], [1,1,1]];
  const tones: DistressTone[] = [];
  let at = 0;
  sequence.forEach((letter, idx) => {
    letter.forEach((length, i) => {
      tones.push({at, duration:length*unit}); at += length*unit;
      if (i < letter.length - 1) at += unit;
    });
    if (idx < sequence.length - 1) at += 3*unit;
  });
  return tones;
}
const activeByRoot = new WeakMap<HTMLElement, () => void>();

const COPIES: Record<PracticeLanguage, {on:string;off:string;expired:string;unsupported:string;error:string;hidden:string}> = {
  fr: {on:'Arrêter le signal', off:'Émettre SOS sonore', expired:'Signal arrêté après 30 secondes pour préserver la batterie.', unsupported:'Le son SOS n’est pas disponible dans ce navigateur.',error:'Impossible de produire le signal. Essaie d’appeler les secours si possible.',hidden:'Signal arrêté lorsque l’application a quitté l’écran.'},
  en: {on:'Stop sound', off:'Sound an SOS', expired:'Signal stopped after 30 seconds to save battery.', unsupported:'SOS sound is unavailable in this browser.',error:'Could not play the signal. Call emergency services if possible.',hidden:'Signal stopped when the app went into the background.'},
  es: {on:'Detener sonido', off:'Emitir SOS sonoro', expired:'Sonido detenido después de 30 segundos para ahorrar batería.',unsupported:'Sonido SOS no disponible en este navegador.', error:'No se pudo emitir el sonido. Llama a emergencias si es posible.',hidden:'Sonido detenido al salir de la aplicación.'},
};

export function attachDistressSignal(root: HTMLElement, lang: PracticeLanguage): void {
  activeByRoot.get(root)?.();
  const button = root.querySelector<HTMLButtonElement>('[data-sos-sound]');
  const status = root.querySelector<HTMLElement>('[data-sos-sound-status]');
  if (!button || !status) return;
  const t = COPIES[lang];
  let audio: AudioContext | null = null;
  let timeouts: number[] = [];
  let playing = false;
  let tornDown = false;
  let scheduled: OscillatorNode[] = [];
  const stop = (message = '') => {
    if (!playing && !audio) return;
    playing = false;
    for (const id of timeouts) clearTimeout(id);
    timeouts = [];
    for (const oscillator of scheduled) { try {oscillator.stop();} catch {/* already ended */} }
    scheduled = [];
    const oldAudio = audio; audio = null;
    if (oldAudio) void oldAudio.close().catch(() => {});
    button.textContent = `🔊 ${t.off}`;
    status.textContent = message;
  };
  const hidden = () => { if (document.hidden) stop(t.hidden); };
  const leave = () => { stop(); removeListeners(); activeByRoot.delete(root); };
  const removeListeners = () => {
    if (tornDown) return;
    tornDown = true;
    document.removeEventListener('visibilitychange', hidden);
    window.removeEventListener('hashchange', leave);
  };
  activeByRoot.set(root, leave);
  document.addEventListener('visibilitychange', hidden);
  window.addEventListener('hashchange', leave, { once:true });
  button.addEventListener('click', async () => {
    if (playing) { stop(); return; }
    const Audio = window.AudioContext;
    if (!Audio) { status.textContent = t.unsupported; return; }
    try {
      const ctx = new Audio();
      audio = ctx; playing = true;
      await ctx.resume();
      if (!playing) return;
      const pattern = morseSosTones();
      const cycleLength = pattern[pattern.length - 1]!.at + pattern[pattern.length - 1]!.duration + 7 * DISTRESS_UNIT_MS;
      const startTime = ctx.currentTime + 0.08;
      for (let start = 0; start + cycleLength <= DISTRESS_MAX_MS; start += cycleLength) {
        for (const tone of pattern) {
          const oscillator = ctx.createOscillator();
          const gain = ctx.createGain();
          oscillator.type = 'sine'; oscillator.frequency.value = 920;
          oscillator.connect(gain); gain.connect(ctx.destination);
          const t0 = startTime + (start + tone.at)/1000;
          const t1 = t0 + tone.duration/1000;
          gain.gain.setValueAtTime(0,t0);
          gain.gain.linearRampToValueAtTime(0.35,t0+0.012);
          gain.gain.setValueAtTime(0.35,Math.max(t0+0.012,t1-0.02));
          gain.gain.linearRampToValueAtTime(0,t1);
          oscillator.start(t0); oscillator.stop(t1+0.03);
          scheduled.push(oscillator);
        }
      }
      button.textContent = `🔇 ${t.on}`;
      status.textContent = lang === 'fr' ? 'Signal audible local uniquement ; volume du téléphone requis.' : lang === 'es' ? 'Solo sonido local; sube el volumen del teléfono.' : 'Local sound only; turn up your phone volume.';
      timeouts.push(window.setTimeout(() => stop(t.expired),DISTRESS_MAX_MS));
    } catch { stop(t.error); status.textContent = t.error; }
  });
}
