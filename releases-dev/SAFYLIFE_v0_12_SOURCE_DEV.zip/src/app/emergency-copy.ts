/** Copy an emergency message with an offline/file:// compatible fallback.
 * No network calls, no logging and no persistence of personal data.
 */
export async function copyEmergencyText(text: string, nav: Pick<Navigator, 'clipboard'> | null = typeof navigator === 'undefined' ? null : navigator, doc: Document | null = typeof document === 'undefined' ? null : document): Promise<boolean> {
  if (!text.trim()) return false;
  try {
    if (nav?.clipboard?.writeText) {
      await nav.clipboard.writeText(text);
      return true;
    }
  } catch { /* Clipboard permission blocked: try local copy below. */ }
  if (!doc?.body || typeof doc.execCommand !== 'function') return false;
  const field = doc.createElement('textarea');
  field.value = text;
  field.setAttribute('readonly', '');
  field.setAttribute('aria-hidden', 'true');
  field.style.position = 'fixed';
  field.style.top = '0';
  field.style.left = '-9999px';
  const previousFocus = doc.activeElement as HTMLElement | null;
  try {
    doc.body.appendChild(field);
    field.focus();
    field.select();
    return doc.execCommand('copy');
  } catch {
    return false;
  } finally {
    field.remove();
    try { previousFocus?.focus?.(); } catch { /* ignore */ }
  }
}

/** Present the text for manual long-press / selection if every clipboard method fails. */
export function revealEmergencyText(root: ParentNode, text: string, label: string): void {
  const section = root.querySelector<HTMLElement>('[data-manual-emergency-copy]');
  if (!section) return;
  section.hidden = false;
  const field = section.querySelector<HTMLTextAreaElement>('textarea');
  const heading = section.querySelector<HTMLElement>('label');
  if (heading) heading.textContent = label;
  if (field) {
    field.value = text;
    field.focus();
    field.select();
  }
}
