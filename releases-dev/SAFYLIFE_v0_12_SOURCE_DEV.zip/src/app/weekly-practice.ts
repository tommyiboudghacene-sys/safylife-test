/** Rotates already-reviewed OFFLINE official summaries each ISO week.
 * This is not news, a risk forecast or a real-time alert.
 */
import { WORLD_PRACTICES } from './world-practices.js';
export function weeklyPracticeIndex(now = new Date()): number {
  if (!Number.isFinite(now.getTime())) throw new Error('Invalid date');
  const midnight = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  midnight.setUTCDate(midnight.getUTCDate() - (midnight.getUTCDay() + 6) % 7);
  const week = Math.floor(midnight.getTime() / 604_800_000);
  return ((week % WORLD_PRACTICES.length) + WORLD_PRACTICES.length) % WORLD_PRACTICES.length;
}
export function currentWeeklyPractice(now = new Date()) {
  return WORLD_PRACTICES[weeklyPracticeIndex(now)]!;
}
