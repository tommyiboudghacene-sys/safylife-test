import { expect, test } from "@playwright/test";

test("accueil français : huit crises dont deux scénarios de guerre", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /Prêts si une catastrophe/ })).toBeVisible();
  await page.goto("/#/simulations");
  await expect(page.locator(".rp-scenario-card")).toHaveCount(8);
  await expect(page.locator(".rp-scenario-card.war")).toHaveCount(2);
  await page.locator("a[href='#/scenario/conflict-services']").click();
  await expect(page.getByRole("heading", { name: "Guerre : services coupés" })).toBeVisible();
  await expect(page.getByText(/ne prédisent ni une guerre|réserves du foyer/).first()).toBeVisible();
});

test("jeu du sac : une partie jouée jusqu'au résultat", async ({ page }) => {
  await page.goto("/#/drill");
  await expect(page.locator(".rp-game-card")).toHaveCount(3);
  await expect(page.locator(".rp-big-game")).toHaveCount(2);
  await page.goto("/#/game/kit");
  for (const id of ["water", "radio", "food", "light", "meds", "papers", "aid", "clothes"]) {
    await page.locator(`[data-kit='${id}']`).click();
  }
  await page.getByRole("button", { name: "Valider mon sac" }).click();
  await expect(page.getByRole("heading", { name: /Score : 100\/100/ })).toBeVisible();
});

test("duel de cartes local : joker, tours et pioches", async ({ page }) => {
  await page.goto("/#/game/cards");
  await expect(page.locator(".rp-duel-hand .rp-duel-card")).toHaveCount(9);
  await page.locator(".rp-duel-card.is-playable").first().click();
  if (await page.locator(".rp-duel-color-picker").isVisible()) {
    await page.locator("[data-duel-element='water']").click();
  }
  await expect(page.locator(".rp-duel-message")).not.toBeEmpty();
  await expect(page.locator(".rp-duel-opponent")).toBeVisible();
});

test("mémoire locale : niveaux, essais et redémarrage", async ({ page }) => {
  await page.goto("/#/game/memory");
  await expect(page.locator("[data-memory-tile]")).toHaveCount(12);
  await page.locator("[data-memory-tile='0']").click();
  await page.locator("[data-memory-tile='1']").click();
  await expect(page.locator(".rp-memory-score")).toContainText("1");
  await page.locator("[data-memory-level='12']").click();
  await expect(page.locator("[data-memory-tile]")).toHaveCount(24);
  await page.locator("#rp-memory-again").click();
  await expect(page.locator(".rp-memory-score")).toContainText("0 / 12");
});

test("parcours guerre : trois décisions et un score final", async ({ page }) => {
  await page.goto("/#/game/decision/conflict");
  for (const answer of [1, 0, 2]) {
    await page.locator(`[data-decision='${answer}']`).click();
    await page.locator("#decision-next").click();
  }
  await expect(page.locator(".rp-final-score")).toHaveText("60 / 60 points");
});

test("profil, sauvegarde et bibliothèque accessibles", async ({ page }) => {
  await page.goto("/#/setup");
  await page.locator("[name=adults]").fill("2");
  await page.locator("[name=water]").fill("45");
  await page.getByRole("button", { name: "Enregistrer ma maison" }).click();
  await expect(page.locator(".rp-demo-note")).toHaveCount(0);
  await page.goto("/#/guide");
  await expect(page.locator(".guide-card")).toHaveCount(9);
  await expect(page.locator(".rp-aid-search-card")).toHaveCount(7);
  await page.goto("/#/data");
  await expect(page.getByRole("button", { name: "Télécharger ma sauvegarde" })).toBeVisible();
});

test("bibliothèque et jeux accessibles après coupure réseau", async ({ page, context, browserName }) => {
  test.skip(browserName !== "chromium", "Vérification service worker sous Chromium uniquement");
  await page.goto("/");
  await page.waitForFunction(() => navigator.serviceWorker?.controller !== null, null, { timeout: 15_000 });
  await context.setOffline(true);
  await page.reload();
  await page.goto("/#/guide");
  await expect(page.locator(".guide-card")).toHaveCount(9);
  await page.goto("/#/game/kit");
  await expect(page.locator("[data-kit]")).toHaveCount(12);
  await page.goto("/#/game/cards");
  await expect(page.locator(".rp-duel-hand .rp-duel-card")).toHaveCount(9);
  await page.goto("/#/game/memory");
  await expect(page.locator("[data-memory-tile]")).toHaveCount(12);
  await page.goto("/#/aventures");
  await expect(page.locator(".rp-adventure-tile")).toHaveCount(3);
  await context.setOffline(false);
});

test("aventure 72 heures : choix, progression et bilan", async ({ page }) => {
  await page.goto("/#/aventure/blackout");
  for (let step = 0; step < 4; step++) {
    await expect(page.locator("[data-adventure-choice]")).toHaveCount(3);
    await page.locator("[data-adventure-choice='0']").click();
  }
  await expect(page.locator(".rp-adventure-end")).toContainText("100 / 100");
  await page.reload();
  await expect(page.locator(".rp-adventure-end")).toBeVisible();
});

test("centre d'urgence : numéros et GPS sur demande uniquement", async ({ page }) => {
  await page.goto("/#/monde");
  await page.locator("#rp-world-country").selectOption("FR");
  await page.goto("/#/terrain");
  await expect(page.locator("a[href='tel:112']")).toBeVisible();
  await expect(page.locator("#rp-terrain-status")).toContainText("Aucune position enregistrée");
  await expect(page.locator("#rp-terrain-locate")).toBeVisible();
});

test("parcours découverte et avis à partager sur téléphone", async ({ page }) => {
  await page.goto("/");
  await page.locator(".rp-test-invite").click();
  await expect(page.locator(".rp-tester-step")).toHaveCount(3);
  await page.locator("[data-test-rate='simple:oui']").click();
  await page.locator("[data-test-rate='amusant:oui']").click();
  await page.locator("[data-test-rate='joli:moyen']").click();
  await expect(page.locator("[data-test-rate][aria-pressed='true']")).toHaveCount(3);
  await page.locator("#rp-test-comment").fill("Le test était facile.");
  await expect(page.locator("#rp-tester-report")).toHaveValue(/Le test était facile/);
  await page.locator(".rp-tester-step[href='#/game/kit']").click();
  await expect(page.locator(".rp-kit-icon")).toHaveCount(12);
});
