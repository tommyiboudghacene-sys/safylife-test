# Attributions et périmètre des licences

## Code inclus

La base de l'application (moteur de simulation, interfaces de configuration, stockage local, scénarios et outils de tests) provient de [Outage Ready](https://github.com/kennethkimbrough/outage-ready), de Kenneth Kimbrough (2026), sous **MIT**. Le texte intégral de cette licence figure dans `LICENSE` et doit rester inclus lors de toute distribution.

Les modules `src/engine/drills.ts`, `src/app/drills.ts`, `src/app/guide.ts`, ainsi que les adaptations de navigation et de style ont été ajoutés dans ce prototype.

## Référence non intégrée

[Nomad Pocket](https://github.com/franlindebl/nomad-pocket) a été examiné afin de comprendre les fonctions pertinentes et l'architecture possible d'une application mobile hors réseau. Son code est sous **GPL-3.0-or-later**. Aucun fichier de ce dépôt ni de ses contenus n'a été incorporé dans l'application.

L'éventuelle intégration future de bibliothèques, données OpenStreetMap, archives Kiwix et modèles d'IA devra être examinée séparément, licence par licence, en tenant compte des obligations d'attribution et de redistribution.

## Références additionnelles pour les cartes mondiales (vérifiées le 23 novembre 2026)

- Canada, Sécurité publique — https://www.canada.ca/fr/services/police/urgences/protection/preparez-vous/kits-urgence/obtenir-kit.html
- Royaume-Uni, campagne officielle Prepare — https://prepare.campaign.gov.uk/
- Australie, NSW State Emergency Service — https://www.ses.nsw.gov.au/plan-and-prepare/emergency-kit
- Chili, SENAPRED — https://www.senapred.cl/kit-emergencia/

Les textes sont des synthèses originales hors connexion. Les sources nécessitent Internet pour s'ouvrir ; un lien valide aujourd'hui ne garantit pas sa disponibilité future.

## Flux mondial consulté à la demande (fonction facultative)

Données sismologiques publiques USGS : https://earthquake.usgs.gov/earthquakes/feed/v1.0/geojson.php et https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson.
Ce flux décrit des événements observés ; il n'est pas une source de prévision, de consignes de protection, ni un système d'alerte régional.
Les données ne sont chargées qu'après un clic volontaire et ne sont pas conservées dans le cache PWA.

## Confidentialité, hébergement et limites techniques (version de développement, 24/11/2026)

- Les numéros de personnes de confiance, la dernière position GPS et les préférences
  sont conservés localement dans le stockage du navigateur, lorsque celui-ci l'autorise.
  Ils ne sont pas envoyés par le code de SAFYLIFE vers un serveur applicatif.
  Une personne ayant accès à ce navigateur ou à ses sauvegardes peut néanmoins
  consulter certaines informations. La suppression du stockage peut aussi les effacer.
- Le site de test est hébergé sur GitHub Pages. Comme tout hébergeur web, GitHub
  peut traiter des données de connexion techniques ; l'affirmation « aucune donnée
  n'est jamais traitée par un tiers » ne serait donc pas exacte.
- Les informations sismiques USGS sont consultées uniquement après une action
  explicite de l'utilisateur ; elles ne constituent ni une alerte officielle, ni une
  prévision, ni un dispositif de secours.
- Le partage de position et la composition d'un appel ou SMS exigent une action
  utilisateur. Le partage natif peut être annulé, et l'ouverture d'un SMS ne prouve
  pas son envoi. En cas d'échec, une copie ou un affichage manuel est proposé.
- Les numéros répertoriés ne couvrent pas tous les pays. Le code affiche une absence
  d'information vérifiée plutôt que d'inventer un numéro. La présence d'un lien
  officiel ne certifie pas que le numéro est toujours à jour : une vérification et
  une maintenance périodiques restent nécessaires.
- Les contenus de santé, premiers secours et évacuation n'ont pas de validation
  professionnelle globale, et l'application n'est pas homologuée comme système
  d'alerte ou de secours.
