/* SAFYLIFE offline assets only. No personal data or arbitrary GET responses are cached. */
const BUILD = "mwu0obvd";
const CACHE_PREFIX = `safylife-${encodeURIComponent(new URL(self.registration.scope).pathname)}-`;
const CACHE = `${CACHE_PREFIX}${BUILD}`;
const ASSETS = [
  "./",
  "./index.html",
  "./styles.css",
  "./world-shapes.json",
  "./manifest.webmanifest",
  "./icons/icon.svg",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./js/app/main.js",
  "./js/app/fr-main.js",
  "./js/app/home-i18n.js",
  "./js/app/offline-diagnostics.js",
  "./js/app/calendar-reminders.js",
  "./js/app/distress-signal.js",
  "./js/app/weekly-practice.js",
  "./js/app/live-earthquakes.js",
  "./js/app/trusted-contact.js",
  "./js/app/review-core.js",
  "./js/app/install-share.js",
  "./js/app/fr-profile.js",
  "./js/app/fr-games.js",
  "./js/app/fr-cards.js",
  "./js/app/card-core.js",
  "./js/app/fr-memory.js",
  "./js/app/memory-core.js",
  "./js/app/fr-secours.js",
  "./js/app/fr-adventure.js",
  "./js/app/fr-adventure-engine.js",
  "./js/app/fr-terrain.js",
  "./js/app/position-storage.js",
  "./js/app/sos-international.js",
  "./js/app/sos-message-core.js",
  "./js/app/emergency-copy.js",
  "./js/app/position-core.js",
  "./js/app/fr-world.js",
  "./js/app/world-practices.js",
  "./js/app/world-core.js",
  "./js/app/fr-tester.js",
  "./js/app/fr-missions.js",
  "./js/app/store.js",
  "./js/app/ui.js",
  "./js/app/wizard.js",
  "./js/app/dashboard.js",
  "./js/app/timeline.js",
  "./js/app/plan-print.js",
  "./js/app/assumptions.js",
  "./js/app/drills.js",
  "./js/app/guide.js",
  "./js/engine/index.js",
  "./js/engine/types.js",
  "./js/engine/format.js",
  "./js/engine/assumptions.js",
  "./js/engine/scenarios.js",
  "./js/engine/graph.js",
  "./js/engine/simulate.js",
  "./js/engine/prioritize.js",
  "./js/engine/sample.js",
  "./js/engine/drills.js",
];
const SCOPE_URL = new URL(self.registration.scope);
const RESOURCE_PATHS = new Set(ASSETS.map(path => new URL(path, SCOPE_URL).pathname));
const OFFLINE_HOME = new URL("./index.html", SCOPE_URL).href;

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE)
      .then(cache => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  // Another site sharing this domain must not lose its own cached resources.
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key => key.startsWith(CACHE_PREFIX) && key !== CACHE)
        .map(key => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener("message", event => {
  if (event.data?.type !== "SAFYLIFE_OFFLINE_STATUS") return;
  const port = event.ports?.[0];
  if (!port) return;
  event.waitUntil(
    caches.open(CACHE).then(async cache => {
      const checks = await Promise.all(ASSETS.map(asset => cache.match(new URL(asset, SCOPE_URL).href)));
      const count = checks.filter(Boolean).length;
      port.postMessage({ type: "SAFYLIFE_OFFLINE_STATUS", ready: count === ASSETS.length, count, total: ASSETS.length });
    }).catch(() => port.postMessage({ type: "SAFYLIFE_OFFLINE_STATUS", ready: false, count: 0, total: ASSETS.length }))
  );
});

self.addEventListener("fetch", event => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== SCOPE_URL.origin || !url.pathname.startsWith(SCOPE_URL.pathname)) return;
  // Do not intercept API calls, query-driven endpoints, user files, auth requests,
  // or any resource not explicitly shipped with the application.
  if (url.search || !RESOURCE_PATHS.has(url.pathname)) return;
  event.respondWith(
    caches.open(CACHE).then(async cache => {
      const cached = await cache.match(url.href);
      if (cached) return cached;
      try { return await fetch(req); }
      catch {
        if (req.mode === "navigate") return await cache.match(OFFLINE_HOME) ?? Response.error();
        return new Response("Ressource SAFYLIFE indisponible hors connexion.", { status: 503 });
      }
    })
  );
});
