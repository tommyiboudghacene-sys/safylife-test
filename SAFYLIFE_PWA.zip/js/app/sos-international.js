import { html, mount } from "./ui.js";
import { attachDistressSignal } from "./distress-signal.js";
import { loadTrustedContact, saveTrustedContact, deleteTrustedContact } from "./trusted-contact.js";
import { additionalEmergencyNumbersFor, chooseCountry, countryOptions, emergencyFor, selectedCountry } from "./fr-world.js";
import { fixQuality } from "./position-core.js";
import { helpRequestText, normalizeTrustedNumber, smsDraftUrl } from "./sos-message-core.js";
import { loadFix, storeFix, forgetFix } from "./position-storage.js";
import { copyEmergencyText, revealEmergencyText } from "./emergency-copy.js";
const UI = {
    en: {
        back: "Home", title: "Emergency assistance", note: "SAFYLIFE does not automatically notify responders, transmit your location or guarantee rescue.",
        country: "Choose your current country", choose: "Select a country", uncertainty: "Check the country manually. Numbers may differ between police, ambulance and fire services.",
        call: "Call", police: "Police", ambulance: "Ambulance only", fire: "Fire / ambulance only", general: "General emergency number", official: "Official source", unknown: "No national number has been reliably checked for this country. Consult local authorities.", countryHint: "An emergency call needs available telephone service.",
        position: "Your GPS coordinates", geoIntro: "Ask your phone for its position, then read or share the coordinates if useful. This may not work under rubble or without satellite reception.", locate: "Get my position", noFix: "No GPS position recorded.", received: "Position retrieved. Check its accuracy and timestamp.", denied: "Location permission denied. Check your browser settings.", failed: "Location unavailable. Try again if safe.", searching: "Looking for your position… Accept the permission prompt if it appears. This can take up to 15 seconds.", timedOut: "No GPS fix within 15 seconds. Move near a window or outdoors if it is safe, then try again.", accuracy: "Estimated accuracy", older: "Older than 30 minutes — it may no longer match your location", imprecise: "Old or imprecise — verify", fresh: "Recent GPS reading — verify your surroundings", clear: "Delete position", share: "Share / copy coordinates", shared: "Open the share dialog and confirm the recipient yourself.", copied: "Coordinates copied. Paste into a message and confirm the recipient.", aborted: "Sharing unavailable or cancelled.",
        smsTitle: "Text a trusted person", smsIntro: "If you cannot speak, prepare an SMS with your last GPS position. Your trusted person can contact local emergency services. This is NOT an automated distress call.", phone: "Trusted person's phone number", phoneHelp: "You may optionally save the number on THIS device. Anyone with access to your device may see it. SAFYLIFE does not send it to a server. Every SMS requires your confirmation and mobile coverage.", saveContact: "Save on this device", deleteContact: "Forget saved number", savedContact: "Saved locally; no SMS sent.", deletedContact: "Saved number deleted.", saveFailed: "Invalid number or local storage unavailable.", deleteFailed: "Could not delete local number.", openSms: "Open SMS draft", copy: "Copy help message", invalid: "Enter a trusted person's phone number (at least 7 digits); do not enter the emergency number.", opening: "SMS app requested. Check the recipient and send manually.", copiedMessage: "Message copied; paste it into your messaging app and send manually.", copyFail: "Copy the message displayed below.", preview: "Preview proposed message", trappedTitle: "Trapped under debris?", trapped: "Avoid unstable debris. Cover your nose and mouth from dust if possible. Try calling emergency services or texting a trusted person. Tap on a pipe or wall or use a whistle to signal your location. Avoid continuous shouting.", trappedNote: "GPS and mobile service may be unavailable beneath rubble. This app cannot locate or rescue you by itself.", source: "Source (online)", links: "Official global disaster information (Internet)", french: "The detailed first-aid cards remain written for France. Follow instructions from local responders."
    },
    es: {
        back: "Inicio", title: "Asistencia de emergencia", note: "SAFYLIFE no avisa automáticamente a los servicios de rescate, no transmite tu ubicación y no garantiza el rescate.",
        country: "Elige el país donde estás", choose: "Seleccionar país", uncertainty: "Comprueba el país manualmente. Los números de policía, ambulancia y bomberos pueden ser diferentes.",
        call: "Llamar", police: "Policía", ambulance: "Solo ambulancia", fire: "Bomberos / ambulancia", general: "Número general de emergencias", official: "Fuente oficial", unknown: "No hay un número nacional suficientemente verificado para este país. Consulta las autoridades locales.", countryHint: "Las llamadas de emergencia necesitan cobertura telefónica.",
        position: "Tus coordenadas GPS", geoIntro: "Solicita la posición al teléfono y después lee o comparte las coordenadas. Bajo escombros o sin recepción de satélites puede fallar.", locate: "Obtener mi posición", noFix: "No hay ubicación GPS guardada.", received: "Posición obtenida. Comprueba la precisión y la hora.", denied: "Permiso de ubicación denegado. Revisa la configuración del navegador.", failed: "Ubicación no disponible. Vuelve a intentarlo si es seguro.", searching: "Buscando tu posición… Acepta el permiso si aparece. Puede tardar hasta 15 segundos.", timedOut: "Sin posición GPS en 15 segundos. Acércate a una ventana o sal al exterior si es seguro y vuelve a intentarlo.", accuracy: "Precisión estimada", older: "Hace más de 30 minutos: puede no coincidir con tu posición actual", imprecise: "Antigua o imprecisa: compruébala", fresh: "Ubicación reciente: verifica tu entorno", clear: "Borrar posición", share: "Compartir / copiar coordenadas", shared: "Abre el menú para compartir y confirma personalmente el destinatario.", copied: "Coordenadas copiadas. Pégalas en un mensaje y confirma el destinatario.", aborted: "No se pudo compartir o se canceló.",
        smsTitle: "Enviar SMS a alguien de confianza", smsIntro: "Si no puedes hablar, prepara un SMS con tu última ubicación GPS. Esa persona puede contactar a emergencias locales. NO es una llamada de socorro automática.", phone: "Teléfono de alguien de confianza", phoneHelp: "Puedes guardar voluntariamente el número SOLO en este dispositivo. Otra persona con acceso al teléfono podría verlo. SAFYLIFE no lo envía a un servidor. Cada SMS requiere confirmación y cobertura móvil.", saveContact: "Guardar en este dispositivo", deleteContact: "Borrar número guardado", savedContact: "Guardado localmente; sin enviar SMS.", deletedContact: "Número guardado borrado.", saveFailed: "Número inválido o almacenamiento no disponible.", deleteFailed: "No se pudo borrar el número.", openSms: "Abrir borrador SMS", copy: "Copiar mensaje de ayuda", invalid: "Introduce un teléfono de confianza (7 cifras o más), no un número de emergencias.", opening: "Se solicita abrir SMS. Comprueba destinatario y envíalo manualmente.", copiedMessage: "Mensaje copiado; pégalo en la aplicación de mensajes y envíalo manualmente.", copyFail: "Copia el mensaje mostrado abajo.", preview: "Ver mensaje propuesto", trappedTitle: "¿Atrapado bajo escombros?", trapped: "Evita mover escombros inestables. Si es posible, cúbrete la boca y la nariz frente al polvo. Intenta contactar con emergencias o enviar un mensaje. Golpea una pared o tubo, o utiliza un silbato para señalar tu posición. No grites continuamente.", trappedNote: "Puede que no haya GPS ni señal móvil bajo escombros. Esta aplicación no puede localizarte ni rescatarte por sí sola.", source: "Fuente (Internet)", links: "Información oficial de desastres (Internet)", french: "Las fichas detalladas de primeros auxilios siguen en francés y se basan en Francia. Sigue las instrucciones de los servicios de emergencia locales."
    },
};
export function renderInternationalSos(root, lang) {
    const t = UI[lang];
    const country = selectedCountry();
    const emergency = emergencyFor(country);
    const extras = additionalEmergencyNumbersFor(country);
    const fix = loadFix();
    const statusFix = fix ? fixQuality(fix) : null;
    const qualityText = !fix ? t.noFix : statusFix === "stale" ? t.older : statusFix === "review" ? t.imprecise : t.fresh;
    const callType = (e) => e.kind === "ambulance" ? t.ambulance : e.kind === "fire-medical" ? t.fire : t.general;
    mount(root, html `
    <section class="rp-page-lead"><a href="#/" class="rp-back">← ${t.back}</a><span class="rp-eyebrow">🆘 SAFYLIFE</span><h1>${t.title}</h1><p class="feature-note">${t.note}</p></section>
    <section class="card rp-terrain-emergency"><label for="rp-int-country"><strong>🌍 ${t.country}</strong></label>
      <select id="rp-int-country" class="rp-sos-country"><option value="">${t.choose}</option>${countryOptions(lang).map(c => html `<option value="${c.code}" ${country === c.code ? "selected" : ""}>${c.title}</option>`)}</select>
      <p class="hint">${t.uncertainty}</p>
      ${emergency ? html `<a class="rp-call-btn rp-terrain-call" href="tel:${emergency.number}">📞 ${t.call} ${emergency.number} (${callType(emergency)})</a><p class="hint">${t.official}: <a href="${emergency.url}" target="_blank" rel="noopener noreferrer">${emergency.source}</a></p>` : html `<p class="feature-note">${t.unknown}</p>`}
      ${extras.length ? html `<div class="rp-terrain-numbers">${extras.map(x => html `<a href="tel:${x.number}">📞 ${t.police} ${x.number}</a>`)}</div>` : ""}
      <p class="hint">${t.countryHint}</p>
    </section>
    <section class="card rp-terrain-gps"><h2>📍 ${t.position}</h2><p>${t.geoIntro}</p>
      <button id="rp-int-locate" class="btn primary block">📍 ${t.locate}</button>
      ${fix ? html `<div class="rp-coordinates ${statusFix === "stale" ? "rp-fix-stale" : ""}"><strong>${fix.latitude.toFixed(5)}, ${fix.longitude.toFixed(5)}</strong><small>${t.accuracy}: ± ${Math.round(fix.accuracy)} m · ${new Date(fix.at).toLocaleString(lang)}</small><strong class="rp-fix-warning">${qualityText}</strong></div>
        <div class="btn-row"><button class="btn" id="rp-int-share">${t.share}</button><button class="btn danger" id="rp-int-forget">${t.clear}</button></div>` : html `<p>${t.noFix}</p>`}
      <p id="rp-int-location-status" class="hint" role="status" aria-live="polite">${fix ? qualityText : ""}</p>
    </section>
    <section class="card rp-sms-help"><h2>✉️ ${t.smsTitle}</h2><p>${t.smsIntro}</p>
      <label for="rp-int-sms-number">${t.phone}</label><input id="rp-int-sms-number" type="tel" inputmode="tel" autocomplete="off" value="${loadTrustedContact() ?? ""}" placeholder="+33 6 12 34 56 78">
      <p class="hint">${t.phoneHelp}</p><div class="btn-row"><button type="button" class="btn" id="rp-int-sms-save">${t.saveContact}</button><button type="button" class="btn danger" id="rp-int-sms-delete">${t.deleteContact}</button></div><div class="btn-row"><button class="btn primary" id="rp-int-sms-open">${t.openSms}</button><button class="btn" id="rp-int-sms-copy">${t.copy}</button></div>
      <p id="rp-int-sms-status" class="hint" role="status"></p>
      <div data-manual-emergency-copy hidden class="rp-manual-copy"><label for="rp-int-manual-copy-text">${lang === "en" ? "Text to copy manually" : "Texto para copiar manualmente"}</label><textarea id="rp-int-manual-copy-text" rows="6" readonly></textarea></div>
      <details><summary>${t.preview}</summary><pre class="rp-message-preview">${helpRequestText(fix, Date.now(), lang)}</pre></details>
    </section>
    <section class="card rp-sound-help"><h2>🔊 ${lang === "en" ? "Offline audible SOS" : "SOS sonoro sin conexión"}</h2>
      <p>${lang === "en" ? "A voluntary Morse SOS sound may help nearby people hear you when phone coverage is absent. Turn up your volume; it stops after 30 seconds to save battery." : "Un sonido SOS en código Morse puede ayudar a que alguien cercano te oiga sin cobertura. Sube el volumen. Se detiene tras 30 segundos para ahorrar batería."}</p>
      <button type="button" class="btn primary block" data-sos-sound>🔊 ${lang === "en" ? "Sound an SOS" : "Emitir SOS sonoro"}</button>
      <p data-sos-sound-status class="hint" role="status" aria-live="polite"></p>
      <p class="hint">${lang === "en" ? "LOCAL sound only. Does not send coordinates or an alert. May be inaudible beneath rubble. Stop if sounding it is unsafe." : "Solo sonido LOCAL. No envía coordenadas ni alertas. Puede ser inaudible bajo escombros. Detenlo si es peligroso."}</p>
    </section>
    <section class="card rp-trapped-advice"><h2>🧱 ${t.trappedTitle}</h2><p>${t.trapped}</p><p class="hint">${t.trappedNote} <a href="https://www.cdc.gov/earthquakes/safety/stay-safe-after-an-earthquake.html" target="_blank" rel="noopener noreferrer">CDC — ${t.source}</a></p></section>
    <section class="card"><p>${t.french}</p><a href="https://www.gdacs.org/" target="_blank" rel="noopener noreferrer">🌍 ${t.links}</a></section>`);
    attachDistressSignal(root, lang);
    const status = () => root.querySelector("#rp-int-sms-status");
    root.querySelector("#rp-int-country")?.addEventListener("change", e => { chooseCountry(e.target.value); renderInternationalSos(root, lang); });
    root.querySelector("#rp-int-locate")?.addEventListener("click", () => {
        const feedback = root.querySelector("#rp-int-location-status");
        if (!navigator.geolocation) {
            feedback.textContent = t.failed;
            return;
        }
        feedback.textContent = t.searching;
        navigator.geolocation.getCurrentPosition(pos => {
            if (!root.isConnected)
                return;
            const next = { latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy: pos.coords.accuracy, at: pos.timestamp };
            if (!storeFix(next)) {
                feedback.textContent = t.failed;
                return;
            }
            renderInternationalSos(root, lang);
        }, e => { if (root.isConnected)
            feedback.textContent = e.code === 1 ? t.denied : e.code === 3 ? t.timedOut : t.failed; }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
    });
    root.querySelector("#rp-int-forget")?.addEventListener("click", () => { forgetFix(); renderInternationalSos(root, lang); });
    root.querySelector("#rp-int-share")?.addEventListener("click", async () => {
        const f = loadFix();
        if (!f)
            return;
        const message = helpRequestText(f, Date.now(), lang);
        const feedback = root.querySelector("#rp-int-location-status");
        try {
            if (typeof navigator.share === "function") {
                await navigator.share({ text: message });
                feedback.textContent = t.shared;
            }
            else if (await copyEmergencyText(message))
                feedback.textContent = t.copied;
            else {
                revealEmergencyText(root, message, lang === "en" ? "Text to copy manually" : "Texto para copiar manualmente");
                feedback.textContent = t.copyFail;
            }
        }
        catch {
            feedback.textContent = t.aborted;
        }
    });
    root.querySelector("#rp-int-sms-save")?.addEventListener("click", () => {
        const phone = root.querySelector("#rp-int-sms-number").value;
        status().textContent = saveTrustedContact(phone) ? t.savedContact : t.saveFailed;
    });
    root.querySelector("#rp-int-sms-delete")?.addEventListener("click", () => {
        const ok = deleteTrustedContact();
        if (ok)
            root.querySelector("#rp-int-sms-number").value = "";
        status().textContent = ok ? t.deletedContact : t.deleteFailed;
    });
    root.querySelector("#rp-int-sms-open")?.addEventListener("click", () => {
        const phone = root.querySelector("#rp-int-sms-number").value;
        if (!normalizeTrustedNumber(phone)) {
            status().textContent = t.invalid;
            return;
        }
        const url = smsDraftUrl(phone, helpRequestText(loadFix(), Date.now(), lang), /iPhone|iPad|iPod/i.test(navigator.userAgent));
        if (!url) {
            status().textContent = t.invalid;
            return;
        }
        status().textContent = t.opening;
        location.href = url;
    });
    root.querySelector("#rp-int-sms-copy")?.addEventListener("click", async () => {
        const message = helpRequestText(loadFix(), Date.now(), lang);
        if (await copyEmergencyText(message))
            status().textContent = t.copiedMessage;
        else {
            revealEmergencyText(root, message, lang === "en" ? "Text to copy manually" : "Texto para copiar manualmente");
            status().textContent = t.copyFail;
        }
    });
}
